/**
 * Copyright 2014 SPeCS Research Group.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package pt.up.fe.specs.util.collections;

import java.io.Serial;
import java.util.Collection;
import java.util.HashSet;

public class HashSetString extends HashSet<String> {

    @Serial
    private static final long serialVersionUID = 1L;

    public HashSetString() {
        super();
    }

    public HashSetString(Collection<? extends String> c) {
        super(c);
    }

    /**
     * Helper method which accepts an enum and compares with its name.
     *
     */
    @SuppressWarnings("unlikely-arg-type")
    public boolean contains(Enum<?> anEnum) {
        return anEnum != null ? contains(anEnum.name()) : super.contains(anEnum);
    }

}
