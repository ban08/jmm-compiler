/*
 * Copyright 2009 SPeCS Research Group.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package pt.up.fe.specs.util.collections.pushingqueue;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Stream;

/**
 * "Pushing Queue" of fixed size.
 *
 * <p>
 * Elements can only be added at the head of the queue. Every time an element is
 * added, every other elements gets "pushed" (its index increments by one). If
 * an element is added when the queue is full, the last element in the queue
 * gets dropped.
 *
 * TODO: remove capacity, replace with size
 * 
 * 
 * @author Joao Bispo
 */
public class ArrayPushingQueue<T> implements PushingQueue<T> {

    /**
     * INSTANCE VARIABLES
     */
    private final ArrayList<T> queue;

    private final int maxSize;

    /**
     * Creates a PushingQueue with the specified size.
     *
     * @param capacity
     *                 the size of the queue
     */
    public ArrayPushingQueue(int capacity) {
        this.maxSize = capacity;
        this.queue = new ArrayList<>(capacity);

    }

    /**
     * Inserts an element at the head of the queue, pushing all other elements one
     * position forward. If the queue is full, the last element is dropped.
     *
     * @param element an element to insert in the queue
     */
    @Override
    public void insertElement(T element) {
        // Insert element at the head
        this.queue.add(0, element);

        // If size exceed capacity, remove last element
        while (this.queue.size() > this.maxSize) {
            this.queue.remove(this.queue.size() - 1);
        }

    }

    /**
     * Returns the element at the specified position in this queue.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this queue
     */
    @Override
    public T getElement(int index) {
        if (index < 0 || index >= this.queue.size()) {
            return null;
        }

        return this.queue.get(index);
    }

    /**
     * Returns the capacity of the queue.
     *
     * @return the capacity of the queue
     */
    @Override
    public int size() {
        return this.maxSize;
    }

    /**
     * 
     * @return the number of inserted elements
     */
    @Override
    public int currentSize() {
        return this.queue.size();
    }

    @Override
    public Iterator<T> iterator() {
        return this.queue.iterator();
    }

    @Override
    public Stream<T> stream() {
        return this.queue.stream();
    }

    @Override
    public String toString() {
        return toString(Object::toString);
    }

}
