grammar Ollir;
/*
 * Copyright (c) 2026, FEUP, Compilers Course
 * All rights reserved.
 *
 * This is a ANTLR grammar for OLLIR v1.0 code.
 *
 * This version of the grammar is in some parts permissive for clearity
 * and accepts OLLIR code that would need a semantic analysis to check validity.
 * We note, however, that the OLLIR code is expected to be generated from compilers and
 * that code will not have the possible semantic errors.
 *
 * Author: Tiago Carvalho, João Bispo, João M. P. Cardoso
 * Email: tdrc@fe.up.pt
 * February 2026
 */

@header {
    package org.specs.comp.ollir;
    import org.specs.comp.ollir.type.BuiltinKind;
    import org.specs.comp.ollir.inst.Instruction;
    import org.specs.comp.ollir.Element;
    import org.specs.comp.ollir.Operand;
    import org.specs.comp.ollir.type.Type;
}

CLASS : 'class' ;
I32: 'i32';
BOOLEAN: 'bool';
VOID: 'V';
ARRAY: 'array';
//STRING: 'String';
FINAL: 'final';
GOTO: 'goto';
IF: 'if';
IMPORT: 'import';
INTERFACE: 'interface';
NEW: 'new';
//NULL: 'null';
PACKAGE: 'package';
PRIVATE: 'private';
PROTECTED: 'protected';
PUBLIC: 'public';
RETURN: 'ret';
STATIC: 'static';
THIS: 'this';
LDC: 'ldc';
INVOKESPECIAL: 'invokespecial';
//INVOKEDYNAMIC: 'invokedynamic';
INVOKEVIRTUAL: 'invokevirtual';
//INVOKEINTERFACE: 'invokeinterface';
INVOKESTATIC: 'invokestatic';
ARRAYLENGTH: 'arraylength';
GETFIELD: 'getfield';
PUTFIELD: 'putfield';
GETSTATIC: 'getstatic';
PUTSTATIC: 'putstatic';
METHOD: '.method';
CONSTRUCT: '.construct';
FIELD: '.field';
EXTENDS: 'extends';
VARARGS: 'varargs';

/* IDENTIFIERS */
IDENTIFIER : [a-zA-Z$_][a-zA-Z$_0-9]* ;
INTEGER_LITERAL : '0' | [1-9][0-9]* ;
// String Literal
//STRING_LITERAL : '"' (~["\\] | '\\' .)* '"' ;
STRING_LITERAL: '"' StringCharacters? '"';
fragment StringCharacters: StringCharacter+;
fragment StringCharacter: ~["\\\r\n] | EscapeSequence;
fragment EscapeSequence:
    '\\' [btnfr"'\\]
    | OctalEscape
    | UnicodeEscape // This is not in the spec but prevents having to preprocess the input
;

fragment OctalEscape:
    '\\' OctalDigit
    | '\\' OctalDigit OctalDigit
    | '\\' ZeroToThree OctalDigit OctalDigit
;
fragment UnicodeEscape: '\\' 'u'+ HexDigit HexDigit HexDigit HexDigit;

fragment OctalDigit: [0-7];
fragment ZeroToThree: [0-3];
fragment HexDigit: [0-9a-fA-F];

/* SEPARATORS */
LPAREN: '(';
RPAREN: ')';
LBRACE: '{';
RBRACE: '}';
LBRACKET: '[';
RBRACKET: ']';
SEMICOLON: ';';
COMMA: ',';
DOT: '.';
/* OPERATORS */
ASSIGN: ':=';
LT: '<';
COLON: ':';
EQ: '==';
LE: '<=';
GE: '>=';
NE: '!=';
SC_OR: '||';
SC_AND: '&&';
SC_NOT: '!';
BIT_NOT: '~';
PLUS: '+';
MINUS: '-';
MUL: '*';
DIV: '/';
BIT_AND: '&';
BIT_OR: '|';
BIT_XOR: '^';
REM: '%';
GT: '>';
LSHIFT: '<<';
RSHIFT: '>>';
RRSHIFT: '>>>';


/** Escape characters (e.g. whitespaces **/
WS : [ \t\n\r\f]+ -> skip ;

/** COMMENTS **/
SINGLE_COMMENT: '//' ~[\r\n]*-> skip;
BLOCK_COMMENT : '/*' .*? '*/' -> skip;

/*****************************************
 * THE OLLIR GRAMMAR STARTS HERE *
 *****************************************/
classUnit:
    packageDeclaration (importDeclaration)*
    classDeclaration
    EOF
    ;

packageDeclaration:
    PACKAGE path+=id (DOT path+=id)* SEMICOLON
    ;

importDeclaration locals [boolean isStaticImport = false]:
    IMPORT (STATIC {$isStaticImport = true;})?
        packageName+=id (DOT packageName+=id)+
//            (DOT packageName+=MUL)? // for this version of Java-- we don't need the "static" and the option to end with a ".*"
    SEMICOLON
    ;

classDeclaration:
    modifiers
    name=className
    (EXTENDS superName=id)?
    LBRACE
    	(field)*
    	(method)*
    RBRACE
    ;

field:
    FIELD modifiers name=id type
    (initializer)?
    SEMICOLON
    ;

initializer:
    ASSIGN sign=(PLUS | MINUS)? value=INTEGER_LITERAL
    ;

method locals [boolean isConstructor=false]:
    (METHOD | CONSTRUCT {$isConstructor=true;})
    modifiers
    name=id? '(' params ')'
    type
    LBRACE
        instructions
    RBRACE
    ;

params:
    (param (COMMA param)*)?
    ;

param:
    name=id
    type
    ;

instructions:
    (labelledInstruction)*
    ;

labelledInstruction:
    label* instruction
    ;

label:
    id  COLON
    ;

instruction returns [Instruction instr]:
    newExpression SEMICOLON #NewInstr
    | invokeExpression SEMICOLON #InvokeInstr
    | PUTFIELD LPAREN o1=objectRef COMMA o2=objectRef COMMA o3=arg RPAREN type SEMICOLON #PutField
    | id  ( (arrayType=type)? arrayIndices)? lhsType=type ASSIGN assignType=type i2=expression SEMICOLON #Assignment
    | IF LPAREN cond=expression RPAREN GOTO labelName=id SEMICOLON #If
    | GOTO id SEMICOLON #Goto
    | RETURN type (o1=operand)? SEMICOLON #Return
    ;

newExpression returns [Instruction instr] locals [boolean hasArgs=false]:
    NEW (LPAREN (ARRAY |id) (COMMA arg)* RPAREN {$hasArgs=true;})? type
    ;

invokeExpression returns [Instruction instr]:
    INVOKESTATIC LPAREN o1=id COMMA o2=STRING_LITERAL (COMMA arg)* RPAREN type #InvokeStatic
    | INVOKEVIRTUAL LPAREN o1=objectRef COMMA o2=STRING_LITERAL (COMMA arg)* RPAREN type #InvokeVirtual
    | INVOKESPECIAL LPAREN o1=objectRef COMMA o2=STRING_LITERAL (invokeSpecialClass=STRING_LITERAL)? (COMMA arg)* RPAREN type #InvokeSpecial
    ;

expression returns [Instruction instr]:
    GETFIELD LPAREN o1=objectRef COMMA o2=objectRef RPAREN type #GetFieldExpr
    | newExpression #NewExpr
    | invokeExpression #InvokeExpr
    | LDC LPAREN literal RPAREN type #LdcExpr
    | ARRAYLENGTH LPAREN o1=objectRef RPAREN type #ArrayLengthExpr
    | o1=operand #SingleOpExpr
    | o1=operand
        op=(MUL | DIV | REM | PLUS | MINUS | LT | GT | LE | GE | EQ | NE | SC_AND | SC_OR | BIT_AND | BIT_OR | BIT_XOR | LSHIFT | RSHIFT | RRSHIFT | BIT_NOT)
        opType=type
        o2=operand
        #BinaryOpExpr
    | op=(SC_NOT| BIT_NOT) opType=type o1=operand #UnaryOpExpr
    ;

operand returns [Element element]:
      arg #ScalarOperand
    | id (arrayType=type)? arrayIndices elType=type #ArrayAccessOperand
    ;

arrayIndices:
    (LBRACKET arrayIndex RBRACKET)+
    ;

arrayIndex returns [Element element]:
    var | literal
    ;

var returns [Operand op]:
    id type
    ;

arg returns [Element element]:
    id type #IdArg
    | THIS type #ThisArg
    | literal #LiteralArg
    ;

objectRef locals [Operand op]:
    id type #InstRef
    | THIS (type)? #ThisClassRef
    | ARRAY #ArrayRef
    ;

//ref:
//    id type #IdRef
//    | THIS (type)? #ThisRef
//    ;

literal returns[LiteralElement element] locals [String sign=""]:
    (PLUS|MINUS{$sign="-";})? value=INTEGER_LITERAL type #IntegerLiteral
    | value=STRING_LITERAL type #StringLiteral
    ;

//used to encapsulate class name so it is easier to know it is the class name during listener visit
className returns [String name]: id;

id returns [String name]:
    ident=(IDENTIFIER | STRING_LITERAL)
    ;

modifiers locals[boolean isFinal=false, boolean isStatic=false, boolean isVarArgs=false]:
    (
        visibility=PUBLIC | visibility=PRIVATE | visibility=PROTECTED
        | FINAL {$isFinal=true;}
        | STATIC {$isStatic=true;}
        | VARARGS {$isVarArgs=true;}
    )*
    ;
type returns[Type ollirType] locals[int dims = 0, boolean isArray=false, BuiltinKind primitive]:
    (DOT ARRAY {$dims++; $isArray=true;} (DOT ARRAY {$dims++;})*)?
    (DOT
        (
          I32     {$primitive=BuiltinKind.INT32;}
        | BOOLEAN {$primitive=BuiltinKind.BOOLEAN;}
        | VOID    {$primitive=BuiltinKind.VOID;}
        //| STRING {$primitive=BuiltinType.STRING;}
        | name=id
        )) //why allow multiple??
    ;

