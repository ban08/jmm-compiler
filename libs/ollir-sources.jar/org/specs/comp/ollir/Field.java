/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.Type;

import java.io.PrintStream;
import java.util.List;

/**
 * Class representing the fields of an OLLIR class.
 */
public class Field extends TreeNode {

    AccessModifier fieldAccessModifier = AccessModifier.DEFAULT;

    boolean staticField = false;

    boolean finalField = false;

    String fieldName;

    boolean isInitialized = false;

    int initialValue;

    Type fieldType;

    public Field() {
        super(List.of());
    }

    public void setFieldType(Type type1) {
        this.fieldType = type1;
    }

    public Type getFieldType() {
        return this.fieldType;
    }

    public void setInitialValue(int val) {
        this.initialValue = val;
        this.isInitialized = true;
    }

    public int getInitialValue() {
        return this.initialValue;
    }

    public boolean isInitialized() {
        return this.isInitialized;
    }

    public void setFieldName(String name) {
        this.fieldName = name;
    }

    public String getFieldName() {
        return this.fieldName;
    }

    public void setFieldAccessModifier(AccessModifier fieldAccessModifier) {
        if (this.fieldAccessModifier != AccessModifier.DEFAULT)
            System.out.println("Warning: field access modifier previously set to: " + this.fieldAccessModifier);
        else
            this.fieldAccessModifier = fieldAccessModifier;
    }

    public AccessModifier getFieldAccessModifier() {
        return this.fieldAccessModifier;
    }

    public boolean isStaticField() {
        return this.staticField;
    }

    public void setStaticField() {
        this.staticField = true;
    }

    public boolean isFinalField() {
        return this.finalField;
    }

    public void setFinalField() {
        this.finalField = true;
    }

    public void show() {
        show(System.out);
    }

    public void show(PrintStream out) {
        out.println("*** Name of the field: " + this.fieldName);
        out.println("\tAccess modifier: " + this.fieldAccessModifier);
        out.println("\tStatic field: " + this.staticField);
        out.println("\tFinal field: " + this.finalField);
        if (this.isInitialized)
            out.println("\tInitial value: " + this.initialValue);
        this.fieldType.show(out);
    }


}
