package org.specs.comp.ollir.tree;

import org.specs.comp.ollir.inst.Instruction;

public interface InstructionNode extends TreeNode {
    public Instruction toInstruction();
}
