package org.specs.comp.ollir.tree;

import org.specs.comp.ollir.Element;

public interface ElementNode extends TreeNode {
    Element toElement();
}
