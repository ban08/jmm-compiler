package org.specs.comp.ollir.tree;

import pt.up.fe.specs.util.treenode.ATreeNode;

import java.util.Collection;

/**
 * Represents a node in the OLLIR tree.
 */
public abstract class TreeNode extends ATreeNode<TreeNode> {

    public TreeNode(Collection<? extends TreeNode> children) {
        super(children);
    }


    @Override
    public String toContentString() {
        return getNodeName();
    }

    @Override
    protected TreeNode copyPrivate() {
        throw new RuntimeException("Copy not implemented for " + getClass());
    }

    /**
     * @return the children of this OLLIR node
     */
    /*
    default List<OllirNode> getChildren() {
        return Collections.emptyList();
    }

    default List<OllirNode> getDescendants() {
        return getDescendantsStream().collect(Collectors.toList());
    }

    default Stream<OllirNode> getDescendantsStream() {
        return getChildrenStream().flatMap(c -> c.getDescendantsAndSelfStream());
    }

    default Stream<OllirNode> getChildrenStream() {
        return getChildren().stream();
    }

    default Stream<OllirNode> getDescendantsAndSelfStream() {
        return Stream.concat(Stream.of(this), getDescendantsStream());
    }


    default boolean hasChildren() {
        if (getChildren().isEmpty()) {
            return false;
        }

        return true;
    }

*/
    // public static <K extends TreeNode<E, K>, E extends Enum<E>> String toString(K token, String prefix) {

    String toTree(String prefix) {
        StringBuilder builder = new StringBuilder();

        builder.append(prefix);

        builder.append(toString());

        builder.append("\n");

        if (hasChildren()) {
            for (var child : getChildren()) {
                if (child == null) {
                    System.out.println("NULL CHILD IN " + getClass());
                }
                builder.append(child.toTree(prefix + "  "));
            }
        }

        return builder.toString();
    }

    @Override
    public String toTree() {
        return toTree("");
    }

    /**
     * @return the OLLIR code corresponding to this node
     */
    public String code() {
        throw new RuntimeException("Code generation not implemented for " + getClass());
    }
}
