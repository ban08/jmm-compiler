package org.specs.comp.ollir.tree;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Represents a node in the OLLIR tree.
 */
public interface TreeNode {

    /**
     * @return the children of this OLLIR node
     */
    default List<TreeNode> getChildren() {
        return Collections.emptyList();
    }

    default List<TreeNode> getDescendants() {
        return getDescendantsStream().collect(Collectors.toList());
    }

    default Stream<TreeNode> getDescendantsStream() {
        return getChildrenStream().flatMap(c -> c.getDescendantsAndSelfStream());
    }

    default Stream<TreeNode> getChildrenStream() {
        return getChildren().stream();
    }

    default Stream<TreeNode> getDescendantsAndSelfStream() {
        return Stream.concat(Stream.of(this), getDescendantsStream());
    }


    default boolean hasChildren() {
        if (getChildren().isEmpty()) {
            return false;
        }

        return true;
    }


    // public static <K extends TreeNode<E, K>, E extends Enum<E>> String toString(K token, String prefix) {
    default String toTree(String prefix) {
        StringBuilder builder = new StringBuilder();

        builder.append(prefix);

        builder.append(toString());

        builder.append("\n");

        if (hasChildren()) {
            for (var child : getChildren()) {
                if (child == null) {
                    System.out.println("NULL CHILD IN " + getClass());
                }
                builder.append(child.toTree(prefix + "  "));
            }
        }

        return builder.toString();
    }

    default String toTree() {
        return toTree("");
    }
}
