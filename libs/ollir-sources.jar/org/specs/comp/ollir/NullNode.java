package org.specs.comp.ollir;

/**
 * Marker interface to indicate placeholder nodes.
 */
public interface NullNode {
}
