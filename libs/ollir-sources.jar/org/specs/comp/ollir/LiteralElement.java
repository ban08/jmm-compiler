/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.type.BuiltinKind;
import org.specs.comp.ollir.type.BuiltinType;
import org.specs.comp.ollir.type.ClassType;
import org.specs.comp.ollir.type.Type;

import java.util.List;

/**
 * Class represents the OLLIR elements that are literals.
 */
public class LiteralElement extends Element {

    String literal;

    public String getLiteral() {
        return this.literal;
    }

    public void setLiteral(String literal) {
        this.literal = literal;
        checkLiteral();
    }

    public LiteralElement(String literal, Type tp1) {
        super(tp1, List.of());
        this.literal = literal;
        this.isLiteral = true;
        checkLiteral();
    }

    public LiteralElement(Type tp1) {
        this(null, tp1);
        // super(tp1);
        // this.isLiteral = true;
    }

    @Override
    public String toString() {
        return "LiteralElement: " + getLiteral() + "." + getType();
    }

    private void checkLiteral() {

        // No check to do
        if (literal == null) {
            return;
        }

        // If type is bool, check if literal is 0 or 1
        if (getType() instanceof BuiltinType builtinType && builtinType.getKind() == BuiltinKind.BOOLEAN) {
            if (!literal.equals("0") && !literal.equals("1")) {
                throw new RuntimeException("Invalid value '" + literal + "' for a boolean literal, can only be 0 or 1");
            }
        }
    }

    @Override
    public String code() {
        //System.out.println("LITERAL: " + literal);
        if (getType() instanceof BuiltinType builtinType && builtinType.getKind() == BuiltinKind.STRING) {
            return "\"" + literal + "\"";
        }
        if (getType() instanceof ClassType classType) {
            return literal;
        }
        
        return literal + "." + getType().code();
    }
}
