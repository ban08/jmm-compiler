package org.specs.comp.ollir;

import org.specs.comp.ollir.type.Type;

import java.io.PrintStream;
import java.util.List;

public class NullType extends Type implements NullNode {

    public NullType() {
        super(List.of());
    }

    @Override
    public void show(PrintStream out) {
        out.print("No-Type");
    }
}
