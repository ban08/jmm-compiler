/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.inst.*;
import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.ClassKind;
import org.specs.comp.ollir.type.ClassType;
import org.specs.comp.ollir.type.Type;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.*;

/**
 * Class represents each method in the input OLLIR class.
 */
public class Method extends TreeNode {

    private static final String THIS = "this";

    private final ClassUnit ollirClass;

    String methodName;

    // labels of the branch and goto instructions
    HashMap<String, Instruction> methodLabels;

    // variables used by the method
    HashMap<String, Descriptor> varTable;

    Type returnType;

    Node beginNode;
    Node endNode;
    boolean cfgInitialized;

    Map<Instruction, List<String>> labelsMap;

    boolean staticMethod = false;

    boolean finalMethod = false;

    boolean constructMethod = false;

    private boolean isVarargs = false;


    public Method(ClassUnit ollirClass) {
        super(List.of());
        this.ollirClass = ollirClass;

        this.methodLabels = new HashMap<>();

        this.beginNode = new Node(NodeType.BEGIN, List.of());
        this.endNode = new Node(NodeType.END, List.of());
        this.cfgInitialized = false;

        this.varTable = new HashMap<>();
    }


    /**
     * @param instruction
     * @return a String list with the labels of the given instruction, or an empty list if the instruction has no labels
     */
    public List<String> getLabels(Instruction instruction) {
        if (labelsMap == null) {
            labelsMap = buildLabelsMap();
        }

        var labels = labelsMap.get(instruction);

        return labels != null ? labels : Collections.emptyList();
    }

    private Map<Instruction, List<String>> buildLabelsMap() {
        var labelsMap = new HashMap<Instruction, List<String>>();

        for (var entry : methodLabels.entrySet()) {
            var inst = entry.getValue();

            var labels = labelsMap.get(inst);
            if (labels == null) {
                labels = new ArrayList<>();
                labelsMap.put(inst, labels);
            }

            labels.add(entry.getKey());
        }

        return labelsMap;
    }

    public Node getBeginNode() {
        if (!this.cfgInitialized) {
            throw new RuntimeException("CFG has not been initialized yet, please call .buildCFG()");
        }

        return beginNode;
    }

    public Node getEndNode() {
        if (!this.cfgInitialized) {
            throw new RuntimeException("CFG has not been initialized yet, please call .buildCFG()");
        }

        return endNode;
    }

    public HashMap<String, Descriptor> getVarTable() {
        return varTable;
    }

    public HashMap<String, Instruction> getLabels() {
        return methodLabels;
    }

    public void setReturnType(Type tp1) {
        this.returnType = tp1;
    }

    public Type getReturnType() {
        return this.returnType;
    }

    public ClassUnit getOllirClass() {
        return ollirClass;
    }

    AccessModifier methodAccessModifier = AccessModifier.DEFAULT;

    public void setVarargs(boolean varargs) {
        isVarargs = varargs;
    }

    public boolean isVarargs() {
        return isVarargs;
    }

    public void setMethodName(String name) {
        this.methodName = name;
    }

    public String getMethodName() {
        return this.methodName;
    }

    public List<Instruction> getInstructions() {
        return getChildrenOf(Instruction.class);
    }

    public Instruction getInstr(int index) {
        return getInstructions().get(index);
    }

    public void addInstr(Instruction instr) {
        addChild(instr);
    }

    public List<Element> getParams() {
        return getChildrenOf(Element.class);
    }

    public Element getParam(int index) {
        return getParams().get(index);
    }

    public void addParam(Element param) {
        addChild(param);
    }

    public void setMethodAccessModifier(AccessModifier methodAccessModifier) {
        if (this.methodAccessModifier != AccessModifier.DEFAULT)
            System.out.println("Warning: method access modifier previously set to: " + this.methodAccessModifier);
        else
            this.methodAccessModifier = methodAccessModifier;
    }

    public AccessModifier getMethodAccessModifier() {
        return this.methodAccessModifier;
    }

    public boolean isStaticMethod() {
        return this.staticMethod;
    }

    public void setStaticMethod() {
        this.staticMethod = true;
    }

    public boolean isFinalMethod() {
        return this.finalMethod;
    }

    public void setFinalMethod() {
        this.finalMethod = true;
    }

    public boolean isConstructMethod() {
        return this.constructMethod;
    }

    public void setConstructMethod() {
        this.constructMethod = true;
    }

    public void addLabel(String label, Instruction i1) {
        // System.out.println("Label "+label);
        if (!this.methodLabels.containsKey(label)) {
            this.methodLabels.put(label, i1);
            // Change to methodLabels, clear labelsMap
            labelsMap = null;
        } else {
            System.out.println("Label " + label + " already used!");
        }

    }

    /**
     * Check if the labels used in the branch and goto instructions are associated with an instruction of the method. If
     * not, exit from the ollir processor.
     *
     * @throws OllirErrorException exception if the label used is a goto and a conditional branch does not exist.
     */
    public void checkLabels() throws OllirErrorException {
        String label;
        for (Instruction inst : getInstructions()) {
            if (inst.getInstType() == InstructionType.BRANCH) {
                label = ((CondBranchInstruction) inst).getLabel();
                if (!this.methodLabels.containsKey(label))
                    throw new OllirErrorException("Label " + label + " is not associated with an instruction!");
            } else if (inst.getInstType() == InstructionType.GOTO) {
                label = ((GotoInstruction) inst).getLabel();
                if (!this.methodLabels.containsKey(label))
                    throw new OllirErrorException("Label " + label + " is not associated with an instruction!");
            }
        }
    }

    /**
     * If the variable is not already in the varTable, create the Descriptor associated with the variable and update the
     * varTable.
     *
     * @param e1    Element of an Instruction
     * @param vs    the scope of the variable
     * @param varID the ID assigned to the variable
     * @return returns an update of the varID
     */
    int updateTable(Element e1, VarScope vs, int varID) {
        if (!e1.isLiteral()) { // if the e1 is not a literal, then it is a variable
            var operand = (Operand) e1;

            var varName = operand.getName();

            // If it is an import, ignore
            if (getOllirClass().isImportedClass(varName)) {
                return varID;
            }

            if (!this.varTable.containsKey(varName)) { // if not already in the varTable
                // var operand = (Operand) e1;

                // If 'this', special case, is always 0
                if (THIS.equals(varName)) {
                    Descriptor d1 = new Descriptor(vs, 0, e1.getType());
                    this.varTable.put(varName, d1);
                } else {
                    // Descriptor d1 = new Descriptor(vs, ++varID, e1.getType());
                    Descriptor d1 = new Descriptor(vs, varID, e1.getType());
                    varID++;
                    this.varTable.put(varName, d1);
                }
            }
        }
        return varID;
    }

    /**
     * This method adds to the symbol table of variables the vars used in each instruction and their associated
     * descriptors. This can be improved by moving to each instruction class the method to create and add the
     * descriptor.
     *
     * @param inst  an object representing an OLLIR instruction
     * @param varID the id of virtual registers/variables
     */
    public int addToVartable(Instruction inst, int varID) {
        Element e1;
        switch (inst.getInstType()) {
            case CALL:
                var i1 = (CallInstruction) inst;

                var children = i1.getOperands();

                // Only add first argument if call is not a 'new'. Otherwise ignore first operand (which is either 'array',
                // or the name of the class)
                if (!(i1 instanceof NewInstruction)) {
                    //e1 = i1.getCaller();
                    e1 = children.get(0);
                    varID = updateTable(e1, VarScope.LOCAL, varID);
                }

                for (var child : children.subList(1, children.size())) {
                    varID = updateTable(child, VarScope.LOCAL, varID);
                }
/*
                if (i1.getChildren().size() > 1) {
                    // System.out.println(i1.getInstType()+" "+i1.getNumOperands());
                    if (i1.getInvocationType() != CallType.NEW) { // only new type instructions do not have a field with second
                        // arg
                        e1 = i1.getSecondArg();
                        varID = updateTable(e1, VarScope.LOCAL, varID);
                    }
                    ArrayList<Element> otherArgs = i1.getListOfOperands();
                    for (Element arg : otherArgs) {
                        varID = updateTable(arg, VarScope.LOCAL, varID);
                    }
                }
 */
                break;
            case ASSIGN:
                AssignInstruction i2 = (AssignInstruction) inst;

                e1 = i2.getDest();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                Instruction i3 = i2.getRhs();
                varID = this.addToVartable(i3, varID);

                break;
            case BRANCH:
                CondBranchInstruction i4 = (CondBranchInstruction) inst;

                // e1 = i4.getLeftOperand();
                // varID = updateTable(e1, VarScope.LOCAL, varID);
                //
                // e1 = i4.getRightOperand();
                // varID = updateTable(e1, VarScope.LOCAL, varID);

                for (var operand : i4.getOperands()) {
                    e1 = operand;
                    varID = updateTable(e1, VarScope.LOCAL, varID);
                }

                break;
            case PUTFIELD:
                PutFieldInstruction i5 = (PutFieldInstruction) inst;

                e1 = i5.getObject();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                e1 = i5.getField();
                // varID = updateTable(e1, VarScope.FIELD, varID);
                updateTable(e1, VarScope.FIELD, -1);

                e1 = i5.getValue();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                break;
            case GETFIELD:
                GetFieldInstruction i6 = (GetFieldInstruction) inst;

                e1 = i6.getObject();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                e1 = i6.getField();
                // varID = updateTable(e1, VarScope.FIELD, varID);
                updateTable(e1, VarScope.FIELD, -1);

                break;
            case UNARYOPER:
                UnaryOpInstruction i7 = (UnaryOpInstruction) inst;

                e1 = i7.getOperand();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                break;
            case BINARYOPER:
                BinaryOpInstruction i8 = (BinaryOpInstruction) inst;

                e1 = i8.getLeftOperand();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                e1 = i8.getRightOperand();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                break;
            case NOPER:
                SingleOpInstruction i9 = (SingleOpInstruction) inst;

                e1 = i9.getSingleOperand();
                varID = updateTable(e1, VarScope.LOCAL, varID);

                break;
            default:
                break;
        }

        return varID;
    }

    /**
     * Builds a symbol table for the varaiables of the method: paramenters and local variables. It assigns a varID that
     * can be considered the ID of virtual registers or JVM local variables if targeting the JVM. The parameters use
     * varID from 0 (if the method is static) or 1 (if the method is not static) to the number of parameters of the
     * method (or -1 when teh varID starts with 0). The local variables use subsequent values for varID.
     * <p>
     * The table uses a key which is the name of the variable and associates it with a Descriptor (see class
     * Descriptor).
     */
    public void buildVarTable() {
        // int varID = -1;
        int varID = isStaticMethod() ? 0 : 1;
        // System.out.println("INIT varID: " + varID);

        // If instance method, always put "this" on the table
        if (!isStaticMethod()) {
            this.varTable.put(THIS, new Descriptor(VarScope.LOCAL, 0, new ClassType(ClassKind.THIS, THIS)));
        }

        for (Element param : getParams()) {
            // Parameters override the initial value of varID
            varID = ((Operand) param).getParamId();
            // System.out.println("PARAM varID: " + varID);
            Descriptor d1 = new Descriptor(VarScope.PARAMETER, varID++, param.getType());
            // Descriptor d1 = new Descriptor(VarScope.PARAMETER, ++varID, param.getType());
            // System.out.println("PARAM " + ((Operand) param).getName() + " at reg " + d1.getVirtualReg());
            this.varTable.put(((Operand) param).getName(), d1);
        }

        for (Instruction inst : getInstructions()) {
            // System.out.println("INST varID BEFORE: " + varID);
            varID = this.addToVartable(inst, varID);
            // System.out.println("INST varID AFTER: " + varID);
        }

    }

    /**
     * Builds the control-flow graph (CFG) of the method. It uses the ArrayList listOfInstr of instructions and assumes
     * that the instructions are in that ArrayList by the order they order in the input OLLIR.
     */
    public void buildCFG() {
        this.cfgInitialized = true;
        var listOfInstr = getInstructions();

        // methods without instructions just connect begin to the end
        if (getInstructions().isEmpty()) {
            this.beginNode.addSucc(this.endNode);
            this.endNode.addPred(this.beginNode);
            return;
        }

        // connect first BEGIN with first instruction
        // this.beginNode.showNode();
        Node first = listOfInstr.getFirst();
        this.beginNode.addSucc(first);
        first.addPred(this.beginNode);

        // add IDs to nodes and connect Return and last instructions to END
        int id = 1;
        for (Instruction inst : listOfInstr) {
            // inst.show();
            inst.setId(id++);
            if (inst.getInstType() == InstructionType.RETURN) {
                // System.out.println("RETURN +"+inst.getId());
                // inst.show();
                inst.addSucc(this.endNode);
                this.endNode.addPred(inst);
                // System.out.println("CHECK "+inst.getId()+" -> "+inst.getSucc1().getId());
            }
        }
        Instruction last = listOfInstr.get(listOfInstr.size() - 1);
        if (last.getInstType() != InstructionType.GOTO) {
            last.addSucc(this.endNode);
            this.endNode.addPred(last);
        }

        // connect Goto and Conditional Branch instructions to instruction with label
        for (Instruction inst : listOfInstr) {
            if (inst.getInstType() == InstructionType.GOTO) {
                Instruction dest = this.methodLabels.get(((GotoInstruction) inst).getLabel());
                inst.addSucc(dest);
                dest.addPred(inst);
                // System.out.println("CHECK: "+inst.getId()+" -> "+dest.getId());
            } else if (inst.getInstType() == InstructionType.BRANCH) {
                Instruction dest = this.methodLabels.get(((CondBranchInstruction) inst).getLabel());
                inst.addSucc(dest);
                dest.addPred(inst);
                // System.out.println("CHECK: "+inst.getId()+" -> "+dest.getId());
            }
        }

        // connect adjacent instructions
        for (int i = 0; i < listOfInstr.size() - 1; i++) {
            Instruction src = listOfInstr.get(i);
            if (src.getInstType() != InstructionType.GOTO) {
                Instruction dest = listOfInstr.get(i + 1);
                src.addSucc(dest);
                dest.addPred(src);
            }
        }

    }

    /**
     * This method generates a textual dotty file .dot representing the CFG of the OLLIR code of the method. The dotty
     * file generated uses the name of the method. The https://graphviz.org/ Webpage interface:
     * https://dreampuf.github.io/GraphvizOnline/
     *
     * @throws OllirErrorException an Exception in case of error
     */
    public void outputCFG() throws OllirErrorException {
        // String fileName = new String("."+File.separator);
        String fileName = "".concat(this.methodName).concat(".dot");
        // System.out.println("Filename: "+fileName);
        try {
            // PrintWriter file = new PrintWriter(new FileOutputStream(new File(fileName)));
            PrintWriter file = new PrintWriter(new FileOutputStream(fileName));
            file.println("digraph cfg {");
            file.println("\tbegin [shape=Msquare];");
            file.println("\tend [shape=Msquare];");

            Node succ = this.beginNode.getSucc1();
            file.print("\tbegin -> " + succ.getId() + ";");

            for (Instruction src : getInstructions()) {
                // src.show();
                Node dest1 = src.getSucc1();
                Node dest2 = src.getSucc2();
                if (src.getInstType() == InstructionType.BRANCH) {
                    if (dest1.getNodeType() != NodeType.END)
                        file.print("\t" + src.getId() + " -> " + dest1.getId() + "[label=T];");
                    else
                        file.print("\t" + src.getId() + " -> end [label=T];");
                    if (dest1.getNodeType() != NodeType.END)
                        file.print("\t" + src.getId() + " -> " + dest2.getId() + "[label=F];");
                    else
                        file.print("\t" + src.getId() + " -> end [label=F];");
                } else {
                    if (dest1.getNodeType() != NodeType.END)
                        file.print("\t" + src.getId() + " -> " + dest1.getId() + ";");
                    else
                        file.print("\t" + src.getId() + " -> end;");
                }
            }
            file.println("}");

            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new OllirErrorException(e.toString() + fileName);
        }
    }

    public void show() {
        show(System.out);
    }

    /**
     * Print the information regarding a method.
     */
    public void show(PrintStream out) {
        out.println("--------------------------");
        out.println("*** Name of the method: " + this.methodName);
        out.println("\tConstruct method: " + this.constructMethod);
        out.println("\tAccess modifier: " + this.methodAccessModifier);
        out.println("\tStatic method: " + this.staticMethod);
        out.println("\tFinal method: " + this.finalMethod);

        out.println("\t* Parameters: ");
        for (Element param : getParams()) {
            param.show(out);
        }

        out.print("\t* Return: ");
        returnType.show(out);

        var listOfInstr = getInstructions();
        out.println("\t* No. Instructions: " + listOfInstr.size());
        out.println("\n\t* Instructions:");
        for (Instruction inst : listOfInstr) {
            var labels = getLabels(inst);
            if (!labels.isEmpty()) {
                out.println("\tLabel(s): " + String.join(",", labels));
            }
            inst.show(out);
        }

        out.println("\n\t* Table of variables:");
        for (Map.Entry<String, Descriptor> entry : varTable.entrySet()) {
            String key = entry.getKey();
            Descriptor d1 = entry.getValue();
            out.println(
                    "\t\tVar name: " + key + " scope: " + d1.getScope() + " virtual register: " + d1.getVirtualReg());
        }
        out.println("--------------------------");

    }
/*
    public List<OllirNode> getChildren() {
        var children = new ArrayList<OllirNode>();

        children.addAll(paramList);
        children.addAll(listOfInstr);

        return children;
    }

 */
}
