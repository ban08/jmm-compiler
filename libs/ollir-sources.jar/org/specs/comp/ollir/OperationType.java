/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

/**
 * The type of operation. Not all the operations are currently supported.
 */
public enum OperationType {
    ADD,
    SUB,
    MUL,
    DIV,
    REM,
    SHR,
    SHL,
    SHRR,
    XOR,
    LTH,
    GTH,
    EQ,
    NEQ,
    LTE,
    GTE,
    LOGICAL_AND, // boolean
    LOGICAL_OR, // boolean
    LOGICAL_NOT, // boolean
    BITWISE_AND,
    BITWISE_OR,
    BITWISE_NOT
    // They are never used, and they seem not to make much sense, and ADD is an ADD. If it is i32, double or other thing
    // should be specified in a separate attribute
    // ADDI32,
    // SUBI32,
    // MULI32,
    // DIVI32,
    // SHRI32,
    // SHLI32,
    // SHRRI32,
    // XORI32,
    // ANDI32,
    // ORI32,
    // LTHI32,
    // GTHI32,
    // EQI32,
    // NEQI32,
    // LTEI32,
    // GTEI32,
    ;

    public boolean isConditional() {
        return switch (this) {
            case EQ, NEQ, LTH, LTE, GTH, GTE -> true;
            default -> false;
        };
    }

    public OperationType invertConditional() {

        return switch (this) {
            case EQ -> NEQ;
            case NEQ -> EQ;
            case LTH -> GTE;
            case LTE -> GTH;
            case GTE -> LTH;
            case GTH -> LTE;
            default -> throw new RuntimeException("This operation is not a conditional: " + this);
        };
    }
}
