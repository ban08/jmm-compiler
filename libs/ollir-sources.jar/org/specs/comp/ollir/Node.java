/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.inst.Instruction;
import org.specs.comp.ollir.tree.InstructionNode;
import org.specs.comp.ollir.tree.TreeNode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class the represents a node in the CFG.
 */
public class Node implements InstructionNode {

    // th id is just for identifying each node with a number
    int id;

    NodeType type;

    // number of sucessor instruction is from 1 to 2
    // (the conditional branch instructions are the only ones with two succ instruction: one
    // if the condition is true and the other when the condition is false)
    List<Node> succNodes = new ArrayList<>();

    // typically the number of predecessor instructions is 1, but the instructions
    // reached by goto and conditional branches may have more than 1 pred instructions
    List<Node> predNodes = new ArrayList<>();

    public void addSucc(Node n1) {
        this.succNodes.add(n1);
    }

    public void addPred(Node n1) {
        this.predNodes.add(n1);
    }

    public Node getSucc1() {
        // System.out.println("Node "+id+" "+this.succNodes.size());
        if (this.succNodes.size() >= 1)
            return this.succNodes.get(0);
        else
            return null;
    }

    public Node getSucc2() {
        if (this.succNodes.size() >= 2)
            return this.succNodes.get(1);
        else
            return null;
    }

    /**
     * @return the successors of this node (to where you can go from this node)
     */
    public List<Node> getSuccessors() {
        return this.succNodes;
    }

    public ArrayList<Node> getPred() {
        // Casting, to maintain compatibility
        return (ArrayList<Node>) this.predNodes;
    }

    /**
     * @return the predecessors of this node (from where you can come to this node)
     */
    public List<Node> getPredecessors() {
        return this.predNodes;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public NodeType getNodeType() {
        return this.type;
    }

    public void showNode() {
        System.out.println("Node id: " + this.id + " type: " + this.type);
    }

    public Node(NodeType type) {
        this.type = type;
        if (type != NodeType.END)
            this.succNodes = new ArrayList<Node>();
        if (type != NodeType.BEGIN)
            this.predNodes = new ArrayList<Node>();
    }

    public Node() {
        this.type = NodeType.INSTRUCTION;
        this.succNodes = new ArrayList<Node>();
        this.predNodes = new ArrayList<Node>();
    }

    public List<TreeNode> getChildren() {
        // By default, return empty list
        return Collections.emptyList();
    }

    @Override
    public Instruction toInstruction() {
        return (Instruction) this;
    }
}
