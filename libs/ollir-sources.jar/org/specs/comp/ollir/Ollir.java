/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;


import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ListTokenSource;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.specs.comp.ollir.antlr.OllirErrorListener;
import org.specs.comp.ollir.antlr.StructureValidator;
import org.specs.comp.ollir.antlr.ToInternalStructure;
import pt.up.fe.specs.util.SpecsIo;

import java.io.InputStream;
import java.util.List;

/**
 * Class with a main example with the current stages of the OLLIR tool.
 */
public class Ollir {
    public static final int MAJOR_VERSION = 0;
    public static final int MINOR_VERSION = 5;

    public static String getVersion() {
        return MAJOR_VERSION + "." + MINOR_VERSION;
    }

    public static String ollirWithVersion() {
        return "OLLIR " + getVersion();
    }


    /**
     * Main example with the stages to load an OLLIR file and to build the data structures to be used by backends.
     *
     * @param args Name of the input file with the OLLIR
     */
    public static void main(String[] args) {
        InputStream stream;
        if (args.length == 0) {
            System.out.println(ollirWithVersion() + ":  Reading from standard input . . .");
            stream = System.in;
        } else if (args.length == 1) {
            System.out.println(ollirWithVersion() + ":  Reading from file " + args[0] + " . . .");
            try {
                stream = new java.io.FileInputStream(args[0]);
            } catch (java.io.FileNotFoundException e) {
                System.out.println(ollirWithVersion() + ":  File " + args[0] + " not found.");
                return;
            }
        } else {
            System.out.println(ollirWithVersion() + ":  Usage is one of:");
            System.out.println("         java org.specs.comp.ollir.Ollir < inputfile");
            System.out.println("OR");
            System.out.println("         java org.specs.comp.ollir.Ollir inputfile");
            return;
        }
        var code = SpecsIo.read(stream);
        var result = parse(code);
        if (result.hasErrors()) {
            System.out.println("Errors found during parsing/validation:");
            for (var error : result.errors()) {
                System.out.println("\t* " + error);
            }
        } else {
            System.out.println("ollirWithVersion() + \":  OLLIR code parsed and validated successfully.");
            System.out.println(result.classUnit().toTree());
        }
    }

    public static OllirParseResult parse(String ollirCode) {
        var input = new ANTLRInputStream(ollirCode);

        // Transform characters into tokens using the lexer
        var lex = new OllirLexer(input);

        var errorListener = new OllirErrorListener();
        lex.removeErrorListeners();
        lex.addErrorListener(errorListener);

        // Wrap lexer around a token stream
        var tokenStream = new CommonTokenStream(lex);
        // Read all tokens from the stream
        tokenStream.fill();
        var tokenSource = new ListTokenSource(tokenStream.getTokens());
        // Wrap lexer around a token stream
        var tokens = new CommonTokenStream(tokenSource);

        // Transforms tokens into a parse tree
        var parser = new OllirParser(tokens);

        parser.removeErrorListeners();
        parser.addErrorListener(errorListener);
//        parser.addParseListener(astConverter);
        OllirParser.ClassUnitContext classUnitContext = null;
        try {
            classUnitContext = parser.classUnit();
        } catch (Exception e) {
            errorListener.syntaxError(parser, null, -1, -1, "Exception while parsing OLLIR: " + e.getMessage(), null);
        }
        if (!errorListener.getReports().isEmpty()) {
            return OllirParseResult.of(errorListener.getReports());
//            throwErrors(errorListener.getReports(), "Errors found during parsing OLLIR:\n");
        }
        var astConverter = new ToInternalStructure();
        ParseTreeWalker walker = new ParseTreeWalker();

        walker.walk(astConverter, classUnitContext);
        ClassUnit myClass = astConverter.getOllirClassUnit();
        StructureValidator sv = new StructureValidator(myClass);
        sv.validate();
        return new OllirParseResult(myClass, sv.getErrors());
    }

    public static void show(ClassUnit myClass) {
        try {
            myClass.checkMethodLabels(); // check the use of labels in the OLLIR loaded
            myClass.buildCFGs(); // build the CFG of each method
            myClass.outputCFGs(); // output to .dot files the CFGs, one per method
            myClass.buildVarTables(); // build the table of variables for each method
            myClass.show(); // print to console main information about the input OLLIR
        } catch (OllirErrorException e) {
            System.out.println(e.getMessage());
        }
    }

    public static String getSimpleClassName(String className) {
        String separator = ".";

        int extIndex = className.lastIndexOf(separator);
        if (extIndex < 0) {
            return className;
        }

        return className.substring(extIndex + 1);
    }
}
