package org.specs.comp.ollir.antlr;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.*;
import org.specs.comp.ollir.type.*;

import java.util.*;

public class ToInternalStructure extends OllirBaseListener {
    private ClassUnit ollirClassUnit;
    private String className;


    public ToInternalStructure() {
        ollirClassUnit = new ClassUnit();
    }

    public ClassUnit getOllirClassUnit() {
        return ollirClassUnit;
    }

    public void enterClassUnit(OllirParser.ClassUnitContext ctx) {
        // Reset the class unit for each new parsing
        ollirClassUnit = new ClassUnit();
    }

    @Override
    public void exitPackageDeclaration(OllirParser.PackageDeclarationContext ctx) {
        ctx.id().stream().map(id -> id.name).reduce((a, b) -> a + "." + b).ifPresent(ollirClassUnit::setPackage);
    }

    @Override
    public void exitImportDeclaration(OllirParser.ImportDeclarationContext ctx) {
        ctx.packageName.stream().map(id -> id.name).reduce((a, b) -> a + "." + b).ifPresent(ollirClassUnit::addImport);
    }

    @Override
    public void exitClassDeclaration(OllirParser.ClassDeclarationContext ctx) {
        if (ctx.modifiers().isFinal) {
            ollirClassUnit.setFinalClass();
        }
        if (ctx.modifiers().isStatic) {
            ollirClassUnit.setStaticClass();
        }
        if (ctx.modifiers().visibility != null) {
            var visibility = AccessModifier.valueOf(ctx.modifiers().visibility.getText().toUpperCase());
            ollirClassUnit.setClassAccessModifier(visibility);
        } else {
            ollirClassUnit.setClassAccessModifier(AccessModifier.DEFAULT);
        }

        ollirClassUnit.setClassName(ctx.name.name);
        if (ctx.superName != null) {
            ollirClassUnit.setSuperClass(ctx.superName.name);
        } else {
            ollirClassUnit.setSuperClass(Object.class.getSimpleName());
        }

    }

    @Override
    public void exitClassName(OllirParser.ClassNameContext ctx) {
        this.className = ctx.name = ctx.id().name;
    }

    @Override
    public void exitField(OllirParser.FieldContext ctx) {
        Field field = new Field();
        if (ctx.modifiers().isFinal) {
            field.setFinalField();
        }
        if (ctx.modifiers().isStatic) {
            field.setStaticField();
        }
        if (ctx.modifiers().visibility != null) {
            var visibility = AccessModifier.valueOf(ctx.modifiers().visibility.getText().toUpperCase());
            field.setFieldAccessModifier(visibility);
        } else {
            field.setFieldAccessModifier(AccessModifier.DEFAULT);
        }
        field.setFieldName(ctx.name.name);
        field.setFieldType(ctx.type().ollirType);
        if (ctx.initializer() != null) {
            var valueStr = ctx.initializer().sign.getText() + ctx.initializer().value.getText();
            field.setInitialValue(Integer.parseInt(valueStr));
        }
        this.ollirClassUnit.addField(field);
    }


    @Override
    public void exitMethod(OllirParser.MethodContext ctx) {
        Method method = new Method(getOllirClassUnit());
        if (ctx.isConstructor) {
            method.setConstructMethod();
        }
        if (ctx.modifiers().isFinal) {
            method.setFinalMethod();
        }
        if (ctx.modifiers().isStatic) {
            method.setStaticMethod();
        }
        if (ctx.modifiers().visibility != null) {
            var visibility = AccessModifier.valueOf(ctx.modifiers().visibility.getText().toUpperCase());
            method.setMethodAccessModifier(visibility);
        } else {
            method.setMethodAccessModifier(AccessModifier.DEFAULT);
        }
        method.setMethodName(ctx.name.name);
        method.setReturnType(ctx.type().ollirType);
        int paramId = method.isStaticMethod() ? 0 : 1;
        for (var param : ctx.params().param()) {
            Operand operand = new Operand(param.name.name, param.type().ollirType);
            operand.setParamId(paramId);
            method.addParam(operand);
            paramId++;
        }
        for (var instrCtx : ctx.instructions().labelledInstruction()) {
            Instruction instruction = instrCtx.instruction().instr;//instructions.get(instrCtx.instruction());
            if (instruction == null) {
                System.err.println("Instruction not found for context: " + instrCtx.instruction().getText());
                continue;
            }
            method.addInstr(instruction);
            for (var labelCtx : instrCtx.label()) {
                method.addLabel(labelCtx.id().name, instruction);
            }
        }
        this.ollirClassUnit.addMethod(method);
    }

    @Override
    public void exitNewInstr(OllirParser.NewInstrContext ctx) {
        ctx.instr = ctx.newExpression().instr; //propagation
    }

    public void exitNewExpression(OllirParser.NewExpressionContext ctx) {
        var type = ctx.type().ollirType;
        Operand o1;
        List<Element> args;
        if (!ctx.hasArgs) {
            args = Collections.emptyList();
            if (ctx.type().isArray) {
                o1 = new Operand("array", type);
            } else if (ctx.type().primitive == null) {
                o1 = new Operand(ctx.type().name.name, type);
            } else {
                throw new RuntimeException("Expected type of 'new' to be either a class or an array, but primitive found: "
                        + ctx.type().primitive);
            }
        } else {
            if (ctx.ARRAY() != null) {
                o1 = new Operand("array", type);
            } else { // if (ctx.id() != null){
                o1 = new Operand(ctx.id().name, new ClassType(ClassKind.CLASS, ctx.id().name));
            }
            args = ctx.arg().stream().map(a -> a.element).toList();
        }
        ctx.instr = new NewInstruction(o1, args, type, true);
    }

    @Override
    public void exitInvokeInstr(OllirParser.InvokeInstrContext ctx) {
        ctx.instr = ctx.invokeExpression().instr; //propagation
    }


    @Override
    public void exitPutField(OllirParser.PutFieldContext ctx) {
        if (ctx.o2 instanceof OllirParser.ArrayRefContext) {
            throw new RuntimeException("PutField does not support 'array' reference as field names.");
        }
        ctx.instr = new PutFieldInstruction(ctx.o1.op, ctx.o2.op, ctx.o3.element, ctx.type().ollirType);
    }

    @Override
    public void exitAssignment(OllirParser.AssignmentContext ctx) {
        Operand o1;
        if (ctx.arrayIndices() != null) {
            var indices = ctx.arrayIndices().arrayIndex().stream().map(i -> i.element).toList();
            o1 = new ArrayOperand(ctx.id().name, ctx.lhsType.ollirType, indices);
        } else {
            o1 = new Operand(ctx.id().name, ctx.lhsType.ollirType);
        }
        ctx.instr = new AssignInstruction(o1, ctx.assignType.ollirType, ctx.i2.instr);
    }

    public void checkConditionType(Type opType, ParserRuleContext reference) {
        if (!(opType instanceof BuiltinType builtinType) || builtinType.getKind() != BuiltinKind.BOOLEAN) {
            var startToken = reference.getStart();
            throw new RuntimeException("In line " + startToken.getLine() + ": condition operand of IF instruction must be of type BOOLEAN.");
        }
    }


    @Override
    public void exitIf(OllirParser.IfContext ctx) {
        CondBranchInstruction instr;
        if (ctx.cond.instr instanceof SingleOpInstruction singleOp) {
            checkConditionType(singleOp.getSingleOperand().getType(), ctx.cond);
            instr = new SingleOpCondInstruction(singleOp);
        } else if (ctx.cond.instr instanceof OpInstruction opInstr) {
            checkConditionType(opInstr.getOperation().getTypeInfo(), ctx.cond);
            instr = new OpCondInstruction(opInstr);
        } else {
            throw new RuntimeException("IF condition must be either a SingleOpInstruction or OpInstruction.");
        }
        instr.setLabel(ctx.labelName.name);
        ctx.instr = instr;
    }


    @Override
    public void exitGoto(OllirParser.GotoContext ctx) {
        ctx.instr = new GotoInstruction(ctx.id().name);
    }

    @Override
    public void exitReturn(OllirParser.ReturnContext ctx) {
        var retInstr = (ctx.o1 != null) ? new ReturnInstruction(ctx.o1.element) : new ReturnInstruction();
        retInstr.setReturnType(ctx.type().ollirType);
        ctx.instr = retInstr;
    }

    @Override
    public void exitInvokeStatic(OllirParser.InvokeStaticContext ctx) {
        var classNameId = ctx.o1.name;
        var args = ctx.arg().stream().map(a -> a.element).toList();
        var returnType = ctx.type().ollirType;
        Operand o1 = new Operand(classNameId, new ClassType(ClassKind.CLASS, classNameId));
        var o2 = literalStringOfQuoted(ctx.o2.getText());
        ctx.instr = new InvokeStaticInstruction(o1, o2, args, returnType, false);
    }


    @Override
    public void exitInvokeVirtual(OllirParser.InvokeVirtualContext ctx) {
        var args = ctx.arg().stream().map(a -> a.element).toList();
        var returnType = ctx.type().ollirType;
        var o1 = ctx.o1.op;
        var o2 = literalStringOfQuoted(ctx.o2.getText());
        ctx.instr = new InvokeVirtualInstruction(o1, o2, args, returnType, true);
    }

    @Override
    public void exitInvokeSpecial(OllirParser.InvokeSpecialContext ctx) {
        var args = ctx.arg().stream().map(a -> a.element).toList();
        var returnType = ctx.type().ollirType;
        var o1 = ctx.o1.op;
        var o2 = literalStringOfQuoted(ctx.o2.getText());
        var invokeSpecialClass = ctx.invokeSpecialClass != null ? unquoteString(ctx.invokeSpecialClass.getText()) : null;
        ctx.instr = new InvokeSpecialInstruction(o1, o2, invokeSpecialClass, args, returnType, true);
    }

    @Override
    public void exitInvokeExpr(OllirParser.InvokeExprContext ctx) {
        ctx.instr = ctx.invokeExpression().instr;
    }

    @Override
    public void exitGetFieldExpr(OllirParser.GetFieldExprContext ctx) {
        if (ctx.o2 instanceof OllirParser.ArrayRefContext) {
            throw new RuntimeException("GetField does not support 'array' reference as field names.");
        }
        ctx.instr = new GetFieldInstruction(ctx.o1.op, ctx.o2.op, ctx.type().ollirType);
    }

    @Override
    public void exitNewExpr(OllirParser.NewExprContext ctx) {
        ctx.instr = ctx.newExpression().instr;
    }


    @Override
    public void exitLdcExpr(OllirParser.LdcExprContext ctx) {
        if (!Objects.equals(ctx.type().name.name, "String")) {
            throw new RuntimeException("Ldc expression only supports String literals.");
        }
        ctx.instr = new LdcInstruction(ctx.literal().element);
    }

    @Override
    public void exitArrayLengthExpr(OllirParser.ArrayLengthExprContext ctx) {
        ctx.instr = new ArrayLengthInstruction(ctx.o1.op, ctx.o1.op.getType());
    }

    @Override
    public void exitSingleOpExpr(OllirParser.SingleOpExprContext ctx) {
        ctx.instr = new SingleOpInstruction(ctx.operand().element);
    }

    @Override
    public void exitBinaryOpExpr(OllirParser.BinaryOpExprContext ctx) {
        var operation = new Operation(OperationTypeConverter.fromSymbol(ctx.op.getText()), ctx.opType.ollirType);
        ctx.instr = new BinaryOpInstruction(ctx.o1.element, operation, ctx.o2.element);
    }

    @Override
    public void exitUnaryOpExpr(OllirParser.UnaryOpExprContext ctx) {
        var operation = new Operation(OperationTypeConverter.fromSymbol(ctx.op.getText()), ctx.opType.ollirType);
        ctx.instr = new UnaryOpInstruction(operation, ctx.o1.element);
    }


    @Override
    public void exitScalarOperand(OllirParser.ScalarOperandContext ctx) {
        ctx.element = ctx.arg().element;
    }

    @Override
    public void exitArrayAccessOperand(OllirParser.ArrayAccessOperandContext ctx) {
        var indices = ctx.arrayIndices().arrayIndex().stream().map(i -> i.element).toList();
        ctx.element = new ArrayOperand(ctx.id().name, ctx.elType.ollirType, indices);
    }

    @Override
    public void exitArrayIndex(OllirParser.ArrayIndexContext ctx) {
        if (ctx.var() != null) {
            ctx.element = ctx.var().op;
        } else {
            ctx.element = ctx.literal().element;
        }
    }


    @Override
    public void exitVar(OllirParser.VarContext ctx) {
        ctx.op = new Operand(ctx.id().name, ctx.type().ollirType);
    }

    @Override
    public void exitIdArg(OllirParser.IdArgContext ctx) {
        ctx.element = new Operand(ctx.id().name, ctx.type().ollirType);
    }

    @Override
    public void exitThisArg(OllirParser.ThisArgContext ctx) {
        ctx.element = new Operand("this", ctx.type().ollirType);
    }

    @Override
    public void exitLiteralArg(OllirParser.LiteralArgContext ctx) {
        ctx.element = ctx.literal().element;
    }


    @Override
    public void exitInstRef(OllirParser.InstRefContext ctx) {
        ctx.op = new Operand(ctx.id().name, ctx.type().ollirType);
    }

    @Override
    public void exitThisClassRef(OllirParser.ThisClassRefContext ctx) {
        Type t = ctx.type() != null ? new ClassType(ClassKind.THIS, ctx.type().name.name) : thisType();
        ctx.op = new Operand(ctx.THIS().getText(), t);
    }

    @Override
    public void exitArrayRef(OllirParser.ArrayRefContext ctx) {
        ctx.op = new Operand(ctx.ARRAY().getText(), new ArrayType());
    }

    @Override
    public void exitIntegerLiteral(OllirParser.IntegerLiteralContext ctx) {
        ctx.element = new LiteralElement(ctx.sign + ctx.value.getText(), ctx.type().ollirType);
    }

    @Override
    public void exitStringLiteral(OllirParser.StringLiteralContext ctx) {
        ctx.element = new LiteralElement(ctx.getText(), ctx.type().ollirType);
    }

    @Override
    public void exitId(OllirParser.IdContext ctx) {
        if (ctx.STRING_LITERAL() != null) {
            ctx.name = ctx.ident.getText().substring(1, ctx.ident.getText().length() - 1);

        } else {
            ctx.name = ctx.ident.getText();
        }
    }


    @Override
    public void exitType(OllirParser.TypeContext ctx) {


        Type elementType;
        if (ctx.primitive != null) {
            elementType = new BuiltinType(ctx.primitive);
        } else {
            elementType = new ClassType(ClassKind.OBJECTREF, ctx.name.name);
        }
        if (ctx.isArray) {
            if (elementType instanceof BuiltinType builtinType &&
                    builtinType.getKind() == BuiltinKind.VOID) {
                throw new IllegalArgumentException("Array of type VOID is not allowed.");
            }
            var arrayType = new ArrayType(ctx.dims);
            arrayType.setElementType(elementType);

            elementType = arrayType;
        }
        ctx.ollirType = elementType;
    }


    private Type thisType() {
        return new ClassType(ClassKind.THIS, this.className);
    }

    private LiteralElement literalStringOfQuoted(String textWithQuotes) {
        return new LiteralElement(unquoteString(textWithQuotes),
                new BuiltinType(BuiltinKind.STRING));
    }

    private String unquoteString(String textWithQuotes) {
        return textWithQuotes.substring(1, textWithQuotes.length() - 1);
    }

}
