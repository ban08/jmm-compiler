package org.specs.comp.ollir.antlr;

public record ErrorReport(String message, int line, int column) {

    public static ErrorReport of(String message) {
        return new ErrorReport(message, -1, -1);
    }

    public boolean hasLine() {
        return line >= 0;
    }

    public boolean hasColumn() {
        return column >= 0;
    }

    @Override
    public String toString() {
        String message = "Error";
        if (hasLine()) {
            message += " at line " + line;
            if (hasColumn()) {
                message += ", column " + column;
            }
        }
        message += ": ";
        return message + this.message;
    }
}
