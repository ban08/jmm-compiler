package org.specs.comp.ollir.antlr;

import org.specs.comp.ollir.OperationType;

import java.util.HashMap;
import java.util.Map;

public class OperationTypeConverter {

    private static final Map<String, OperationType> arithmeticOps = Map.of(
            "+", OperationType.ADD,
            "-", OperationType.SUB,
            "*", OperationType.MUL,
            "/", OperationType.DIV,
            "%", OperationType.REM
    );

    private static final Map<String, OperationType> unaryOps = Map.of(
            //keeping them for backward compatibility but shouldn't they be switched?
            "!", OperationType.LOGICAL_NOT,
            "~", OperationType.BITWISE_NOT
    );

    private static final Map<String, OperationType> comparisonOps = Map.of(
            "<", OperationType.LTH,
            ">", OperationType.GTH,
            "<=", OperationType.LTE,
            ">=", OperationType.GTE,
            "==", OperationType.EQ,
            "!=", OperationType.NEQ
    );

    private static final Map<String, OperationType> conditionalOps = Map.of(
            "&&", OperationType.LOGICAL_AND,
            "||", OperationType.LOGICAL_OR
    );

    private static final Map<String, OperationType> bitWiseOps = Map.of(
            "<<", OperationType.SHL,
            ">>", OperationType.SHR,
            ">>>", OperationType.SHRR,
            "&", OperationType.BITWISE_AND,
            "|", OperationType.BITWISE_OR,
            "^", OperationType.XOR
    );

    private static final Map<String, OperationType> ops;

    static {
        ops = new HashMap<>();
        ops.putAll(arithmeticOps);
        ops.putAll(unaryOps);
        ops.putAll(comparisonOps);
        ops.putAll(conditionalOps);
        ops.putAll(bitWiseOps);
    }

    public static OperationType fromSymbol(String op) {
        return ops.get(op);
    }
}
