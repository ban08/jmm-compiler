package org.specs.comp.ollir.antlr;

import org.antlr.v4.runtime.BaseErrorListener;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.Recognizer;

import java.util.ArrayList;
import java.util.List;

public class OllirErrorListener extends BaseErrorListener {

    private final List<ErrorReport> reports;

    public OllirErrorListener() {
        this.reports = new ArrayList<>();
    }

    @Override
    public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {

        addError(line, charPositionInLine, msg);
    }

    public void addError(int line, int column, String msg) {
        reports.add(new ErrorReport(msg, line, column));
    }

    public List<ErrorReport> getReports() {
        return reports;
    }
}
