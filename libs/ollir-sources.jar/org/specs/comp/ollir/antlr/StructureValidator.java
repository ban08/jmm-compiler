package org.specs.comp.ollir.antlr;

import org.specs.comp.ollir.*;
import org.specs.comp.ollir.inst.*;
import org.specs.comp.ollir.type.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class StructureValidator {

    private final ClassUnit classUnit;
    private List<ErrorReport> errors;

    public StructureValidator(ClassUnit classUnit) {
        this.classUnit = classUnit;
    }

    public void validate() {
        errors = new ArrayList<>();
        check(classUnit);
    }

    public List<ErrorReport> getErrors() {
        return errors;
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    private void check(ClassUnit classUnit) {
        if (!checkNotNull(classUnit, "ClassUnit")) {
            return;
        }
        this.checkNotEmpty(classUnit.getClassName(), "Class name");
        this.checkNotEmpty(classUnit.getPackage(), "Package");

        classUnit.getFields().forEach(this::check);
        classUnit.getMethods().forEach(this::check);
    }

    private void check(Type type) {
        if (!checkNotNull(type, "Type"))
            return;
        switch (type) {
            case ArrayType at -> {
                checkCondition(at.getNumDimensions() > 0, "Array number of dimensions must be > 0. Given: " + at.getNumDimensions());
                if (checkNotNull(at.getElementType(), "Array element type")) {
                    check(at.getElementType());
                }
            }
            case ClassType ct -> {
                checkNotEmpty(ct.getName(), "ClassType name");
                checkNotNull(ct.getKind(), "ClassType kind");
            }
            case BuiltinType bt -> checkNotNull(bt.getKind(), "BuiltinType kind is null");
            default -> throw new RuntimeException("Unknown Type subclass: " + type.getClass());
        }
    }


    private void check(Field field) {
        if (!checkNotNull(field, "Field"))
            return;
        checkNotEmpty(field.getFieldName(), "Field name");
        check(field.getFieldType());
    }

    private void check(Method method) {
        if (!checkNotNull(method, "Method"))
            return;
        checkNotEmpty(method.getMethodName(), "Method name");
        check(method.getReturnType());
        method.getParams().forEach(this::check);
        method.getInstructions().forEach(this::check);
    }

    private void check(Element element) {
        if (!checkNotNull(element, "Element"))
            return;
        check(element.getType());
        if (element.getType() == null)
            return;
        switch (element) {
            case LiteralElement li -> {
                checkNotEmpty(li.getLiteral(), "LiteralElement");
            }
            case ArrayOperand ao -> {
                checkNotEmpty(ao.getName(), "ArrayOperand name");
                ao.getIndexOperands().forEach(this::check);
            }
            case Operand op -> {
                checkNotEmpty(op.getName(), "Operand name");
                checkCondition(op.getParamId() >= 0, "Operand paramID is negative: " + op.getParamId());
            }
            default -> throw new IllegalStateException("Unexpected value: " + element);
        }
    }

    private void check(Instruction instr) {
        if (!checkNotNull(instr, "Instruction"))
            return;
        switch (instr) {
            case CondBranchInstruction obi -> {
                check(obi.getCondition());
                obi.getOperands().forEach(this::check);
            }
            case GotoInstruction gi -> {
                checkNotEmpty(gi.getLabel(), "GotoInstruction label");
            }
            case LdcInstruction ldi -> {
                check(ldi.getElement());
            }
            case OpInstruction oi -> {
                oi.getOperands().forEach(this::check);
                check(oi.getOperation());
            }
            case ReturnInstruction ri -> {
                check(ri.getReturnType());
                var oper = ri.getOperand();
                if (oper.isPresent()) {
                    check(oper.get());
                } else {
                    if (!(ri.getReturnType() instanceof BuiltinType bt) || bt.getKind() != BuiltinKind.VOID) {
                        throw new RuntimeException("ReturnInstruction has no operand but return type is not VOID");
                    }
                }
            }
            case AssignInstruction ai -> {
                check(ai.getRhs());
                check(ai.getTypeOfAssign());
                check(ai.getDest());
            }
            case SingleOpInstruction sop -> {
                check(sop.getSingleOperand());
            }
            case PutFieldInstruction pfi -> {
                pfi.getOperands().forEach(this::check); //ref, field
                check(pfi.getFieldType());
                check(pfi.getValue());
            }
            case GetFieldInstruction gfi -> {
                gfi.getOperands().forEach(this::check); //ref, field
                check(gfi.getFieldType());
            }
            case ArrayLengthInstruction ali -> {
                check(ali.getCaller());
                check(ali.getReturnType());
            }
            case InvokeSpecialInstruction isi -> {
                check(isi.getCaller());
                check(isi.getMethodName());
                isi.getSuperClass().ifPresent(sp -> checkNotEmpty(sp, "InvokeSpecialInstruction superClass"));
                isi.getArguments().forEach(this::check);
                check(isi.getReturnType());
            }
            case NewInstruction ni -> {
                check(ni.getCaller());
                ni.getArguments().forEach(this::check);
                check(ni.getReturnType());
            }
            case CallInstruction ci -> {
                check(ci.getCaller());
                check(ci.getMethodNameTry().orElse(null));
                ci.getArguments().forEach(this::check);
                check(ci.getReturnType());
            }
            default -> throw new IllegalStateException("Unexpected instruction type: " + instr);
        }
    }

    private void check(Operation operation) {
        if (!checkNotNull(operation, "Operation"))
            return;
        checkNotNull(operation.getOpType(), "Operation type");
        check(operation.getTypeInfo());
    }

    private void checkNotEmpty(String value, String entity) {
        checkNotNull(value, entity + " is null");
        checkCondition(!value.isEmpty(), entity + " is empty");
    }

    private void checkCondition(boolean condition, String message) {
        if (!condition) {
            addError(message);
        }
    }


    private boolean checkNotNull(Object obj, String message) {
        if (obj == null) {
            addError(message + " is null");
            return false;
        }
        return true;
    }

    private void addError(String error) {
        var baos = new ByteArrayOutputStream();
        var printStream = new PrintStream(baos, true, StandardCharsets.UTF_8);
        new RuntimeException().printStackTrace(printStream);
        errors.add(ErrorReport.of(error + ". Stack trace:\n" + baos.toString(StandardCharsets.UTF_8)));
    }
}
