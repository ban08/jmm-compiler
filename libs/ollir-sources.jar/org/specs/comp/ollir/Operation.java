/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.type.Type;

/**
 * Class representing the operation in an OLLIR instruction.
 */
public class Operation {

    OperationType opType;

    Type typeInfo;

    public OperationType getOpType() {
        return this.opType;
    }

    public Type getTypeInfo() {
        return typeInfo;
    }

    public void setOpType(OperationType opType) {
        this.opType = opType;
    }

    public Operation(OperationType opType, Type tp1) {
        this.opType = opType;
        this.typeInfo = tp1;
    }

    public String code() {
        var op = switch (opType) {
            case ADD -> "+";
            case SUB -> "-";
            case MUL -> "*";
            case DIV -> "/";
            case REM -> "%";
            case SHR -> ">>";
            case SHL -> "<<";
            case SHRR -> ">>>";
            case XOR -> "^";
            case LTH -> "<";
            case GTH -> ">";
            case EQ -> "==";
            case NEQ -> "!=";
            case LTE -> "<=";
            case GTE -> ">=";
            case LOGICAL_AND -> "&&";
            case LOGICAL_OR -> "||";
            case LOGICAL_NOT -> "!";
            case BITWISE_AND -> "&";
            case BITWISE_OR -> "|";
            case BITWISE_NOT -> "~";
        };

        return op + "." + getTypeInfo().code();
    }

}
