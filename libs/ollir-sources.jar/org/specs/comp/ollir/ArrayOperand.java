/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.type.Type;
import pt.up.fe.specs.util.SpecsStrings;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The class that represent each operand of type array.
 */
public class ArrayOperand extends Operand {

    // list of the indexing, one per array dimension
    // TODO: convert ArrayList to List
    @Deprecated
    ArrayList<Element> listOfIndexes;

    public ArrayOperand(String name, Type tp1) {
        super(name, tp1, List.of());
        this.listOfIndexes = new ArrayList<Element>();
    }

    public ArrayOperand(String name, Type tp1, ArrayList<Element> listOfIndexes) {
        super(name, tp1, listOfIndexes);
        this.listOfIndexes = listOfIndexes;
    }

    public ArrayOperand(String name, Type tp1, Collection<Element> listOfIndexes) {
        this(name, tp1, new ArrayList<>(listOfIndexes));
    }

    public void addIndexOperand(Operand indexOperand) {
        addChild(indexOperand);
        this.listOfIndexes.add(indexOperand);
    }

    public void addIndexOperand(ArrayList<Element> indexOperands) {
        setChildren(indexOperands);
        this.listOfIndexes = indexOperands;
    }

    public ArrayList<Element> getIndexOperands() {
        return new ArrayList<>(getChildren(Element.class));
        //return this.listOfIndexes;
    }


    @Override
    public String toString() {
        return "ArrayOperand: " + getName()
                + getIndexOperands().stream()
                .map(index -> "[" + index + "]")
                .collect(Collectors.joining(""))
                + "." + getType();
    }

    @Override
    public String code() {
        var operandType = SpecsStrings.buildLine("array.", getIndexOperands().size()) + getType().code();
        var arrayIndexes = getIndexOperands().stream()
                .map(index -> "[" + index.code() + "]")
                .collect(Collectors.joining(""));

        return "\"" + getName() + "\"." + operandType
                + arrayIndexes
                + "." + getType().code();
    }
}
