/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.Type;

import java.io.PrintStream;
import java.util.List;

/**
 * Class representing the elements used in the OLLIR instructions.
 */
public abstract class Element extends TreeNode {

    Type typeOfElement;

    boolean isLiteral;

    public Element(Type typeOfElement) {
        super(List.of());
        this.typeOfElement = typeOfElement;
    }

    public boolean isLiteral() {
        return isLiteral;
    }

    public void setLiteral(boolean literal) {
        isLiteral = literal;
    }

    public void show() {show(System.out);}

    public void show(PrintStream out) {
        out.println("\t\t" + this);
    }

    @Override
    public String toString() {
        return "Element: " + this.typeOfElement.toString();
    }

    public Type getType() {
        return this.typeOfElement;
    }

    public void setType(Type typeOfElement) {
        this.typeOfElement = typeOfElement;
    }


    public Element toElement() {
        return this;
    }
}
