package org.specs.comp.ollir.type;

import java.io.PrintStream;
import java.util.List;

public class BuiltinType extends Type {

    private final BuiltinKind builtinKind;

    public BuiltinType(BuiltinKind typeOfElement) {
        super(List.of());
        this.builtinKind = typeOfElement;
    }

    /**
     * Tests if the given type is a BuiltinType of the given kind.
     *
     * @param type
     * @param builtinKind
     * @return
     */
    public static boolean is(Type type, BuiltinKind builtinKind) {
        if (type instanceof BuiltinType builtinType) {
            return builtinType.getKind() == builtinKind;
        }

        return false;
    }


    @Override
    public void show(PrintStream out) {
        out.println("Type: " + this);
    }

    @Override
    public String toString() {

        return builtinKind.toString();
    }

    public BuiltinKind getKind() {
        return builtinKind;
    }

}
