package org.specs.comp.ollir.type;

public enum ClassKind {

    /**
     * Represents a reference to a class (e.g., java.lang.Object)
     */
    CLASS,
    /**
     * Represents a reference to an object, which has its own  class
     */
    OBJECTREF,
    /**
     * Represents a reference to the object this, which has its own  class
     */
    THIS;

}
