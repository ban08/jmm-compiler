/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

import pt.up.fe.specs.util.treenode.NodeInsertUtils;

import java.io.PrintStream;
import java.util.List;

/**
 *
 */
public class ArrayType extends Type {

    // number of dimensions of the array
    int numDimensions;


    public ArrayType(Type elementType) {
        super(List.of(elementType));
    }


    public ArrayType(Type elementType, int dims) {
        super(List.of(elementType));
        this.numDimensions = dims;
    }

    public void setElementType(Type elementType) {
        var oldChild = getElementType();
        NodeInsertUtils.replace(oldChild, elementType);
    }
/*
    @Override
    public List<OllirNode> getChildren() {
        if (elementType == null) {
            throw new RuntimeException("Element type of the array not set");
        }

        return List.of(elementType);
    }
*/

    /**
     * @return the type of the elements of the array, as a Type
     */
    public Type getElementType() {
        return (Type) getChildren().getFirst();
    }

    public int getNumDimensions() {
        return this.numDimensions;
    }

    @Override
    public void show(PrintStream out) {
        out.println("Type: ARRAYREF " + this);
    }

    @Override
    public String toString() {

        // translate array dimensions to "[..."
        StringBuilder array = new StringBuilder();

        array.append(getElementType());
        for (int i = 0; i < numDimensions; i++) {
            array.append("[]");
        }


        return array.toString();
    }


    @Override
    public String code() {
        return "array." + getElementType().code();
    }
}
