/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

import org.specs.comp.ollir.tree.TreeNode;

import java.io.PrintStream;
import java.util.Collection;

/**
 * Class representing the type of variables, assignments, returns, literals.
 */
public abstract class Type extends TreeNode {

    public Type(Collection<? extends TreeNode> children) {
        super(children);
    }

    public void show() {
        show(System.out);
    }

    public abstract void show(PrintStream out);

}
