/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

import org.specs.comp.ollir.tree.TreeNode;

import java.io.PrintStream;

/**
 * Class representing the type of variables, assignments, returns, literals.
 */
public abstract class Type implements TreeNode {

    public void show() {
        show(System.out);
    }

    public abstract void show(PrintStream out);

}
