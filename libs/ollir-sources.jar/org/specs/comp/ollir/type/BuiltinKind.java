/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto
 * Porto, Portugal
 *
 * March 2021
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.type;

/**
 * The type of each element used in an OLLIR instruction.
 */
public enum BuiltinKind {
        INT32,
        BOOLEAN,
        STRING,
        VOID
}
