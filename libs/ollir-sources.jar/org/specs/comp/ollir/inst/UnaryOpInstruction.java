/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operation;

import java.util.List;

/**
 * Class representing the OLLIR instructions with unary operations.
 */
public class UnaryOpInstruction extends OpInstruction {

    @Deprecated
    Element operand;


    public UnaryOpInstruction(Operation oper, Element o1) {
        super(InstructionType.UNARYOPER, oper, List.of(o1));
        this.operand = o1;
        this.operation = oper;
    }

    public void setOperand(Element rightOperand) {
        setChild(0, rightOperand);
        this.operand = rightOperand;
    }

    public Element getOperand() {
        return getChild(Element.class, 0);
    }


    @Override
    public String toString() {
        return super.toString() + " " + this.operation.getOpType() + " "
                + getOperand();
    }

    // public UnaryOpInstruction(InstructionType tp) {
    // super(tp);
    // }

    @Override
    public List<Element> getOperands() {
        return List.of(getOperand());
    }

    @Override
    public void setOperands(List<Element> operands) {
        if (operands.size() != 1) {
            throw new RuntimeException("Operands must have size 1, has size " + operands.size());
        }

        setOperand(operands.getFirst());
    }

}
