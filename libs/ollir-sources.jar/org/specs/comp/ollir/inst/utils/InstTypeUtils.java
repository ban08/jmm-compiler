package org.specs.comp.ollir.inst.utils;

import org.specs.comp.ollir.Field;
import org.specs.comp.ollir.inst.*;
import org.specs.comp.ollir.type.BuiltinKind;
import org.specs.comp.ollir.type.BuiltinType;
import org.specs.comp.ollir.type.Type;

import java.util.Optional;

public class InstTypeUtils {
    public static Optional<Type> getType(Instruction inst) {
        return Optional.ofNullable(switch (inst.getInstType()) {
            case ASSIGN -> ((AssignInstruction) inst).getTypeOfAssign();
            case CALL -> ((CallInstruction) inst).getReturnType();
            case GOTO -> null;
            case RETURN -> ((ReturnInstruction) inst).getReturnType();
            case PUTFIELD -> new BuiltinType(BuiltinKind.VOID); //Put does not return anything
            case GETFIELD -> ((GetFieldInstruction) inst).getFieldType();
            case UNARYOPER -> ((UnaryOpInstruction) inst).getOperation().getTypeInfo();
            case BINARYOPER -> ((BinaryOpInstruction) inst).getOperation().getTypeInfo();
            case LDC -> ((LdcInstruction) inst).getElement().getType();
            case NOPER -> ((SingleOpInstruction) inst).getSingleOperand().getType();
            default -> throw new IllegalStateException("Unexpected value: " + inst.getInstType());
        });
    }


    public static boolean classTypeMatches(Type type, String classQualifiedName) {

        var simpleName = classQualifiedName.contains(".") ? classQualifiedName.substring(classQualifiedName.lastIndexOf(".") + 1) : classQualifiedName;

        return type instanceof org.specs.comp.ollir.type.ClassType ct
                && (ct.getName().equals(classQualifiedName) || ct.getName().equals(simpleName));
    }
}
