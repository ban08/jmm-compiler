/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.type.Type;

import java.util.List;
import java.util.Optional;

/**
 * Class representing the OLLIR return instructions.
 */
public class ReturnInstruction extends Instruction {

    @Deprecated
    Element operand;

    Type returnType;

    /**
     * with return value
     *
     * @param op1 element to return. It can be an operand or a literal
     */
    public ReturnInstruction(Element op1) {
        super(InstructionType.RETURN, List.of(op1));
        this.operand = op1;
    }

    /**
     * without return value
     */
    public ReturnInstruction() {
        super(InstructionType.RETURN, List.of());
        this.operand = null;
    }

    public void setOperand(Element op1) {
        setChild(0, op1);
        this.operand = op1;
    }

    public Optional<Element> getOperand() {
        return getChildTry(Element.class, 0);
    }

    /**
     * @return the returnType
     */
    public Type getReturnType() {
        return returnType;
    }

    /**
     * @param returnType the returnType to set
     */
    public void setReturnType(Type returnType) {
        this.returnType = returnType;
    }


    public boolean hasReturnValue() {
        return getOperand().isPresent();
    }

    // public void setReturnValue(boolean hasReturnValue) {
    // this.returnsValue = hasReturnValue;
    // }


    @Override
    public String toString() {
        var string = new StringBuilder();

        string.append(super.toString() + "." + returnType);

        getOperand().ifPresent(operand -> string.append(" ").append(operand));
        /*
        if (hasReturnValue()) {
            string.append(" ").append(operand);
        }
         */

        return string.toString();
    }

    @Override
    public String code() {
        var code = new StringBuilder();

        code.append("ret." + getReturnType().code());

        getOperand().ifPresent(operand -> code.append(" ").append(operand.code()));

        code.append(";");

        return code.toString();
    }
}
