/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.tree.TreeNode;
import org.specs.comp.ollir.type.Type;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Class representing the OLLIR return instructions.
 */
public class ReturnInstruction extends Instruction {

    Element operand;

    Type returnType;


    public Optional<Element> getOperand() {
        return Optional.ofNullable(operand);
    }

    /**
     * @return the returnType
     */
    public Type getReturnType() {
        return returnType;
    }

    /**
     * @param returnType the returnType to set
     */
    public void setReturnType(Type returnType) {
        this.returnType = returnType;
    }

    public void setOperand(Element op1) {
        this.operand = op1;
    }

    public boolean hasReturnValue() {
        return operand != null;
        // return returnsValue;
    }

    // public void setReturnValue(boolean hasReturnValue) {
    // this.returnsValue = hasReturnValue;
    // }


    @Override
    public String toString() {
        var string = new StringBuilder();

        string.append(super.toString() + "." + returnType);

        if (hasReturnValue()) {
            string.append(" ").append(operand);
        }

        return string.toString();
    }

    /**
     * with return value
     *
     * @param op1 element to return. It can be an operand or a literal
     */
    public ReturnInstruction(Element op1) {
        super(InstructionType.RETURN);
        this.operand = op1;
        // setReturnValue(true);
    }

    /**
     * without return value
     */
    public ReturnInstruction() {
        super(InstructionType.RETURN);
        this.operand = null;
    }

    @Override
    public List<TreeNode> getChildren() {
        return operand != null ? Arrays.asList(operand) : Collections.emptyList();
    }
}
