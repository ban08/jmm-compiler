/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;

import java.util.List;

/**
 * Class representing the instructions with a single element. I.e., without other elements (operands) and without
 * operation. These instructions are in rhs of assignments such as a = b;
 */
public class SingleOpInstruction extends Instruction {

    // Instruction with a single operand and without operation
    @Deprecated
    Element singleOperand;


    public SingleOpInstruction(Element o1) {
        super(InstructionType.NOPER, List.of(o1));
        this.singleOperand = o1;
    }

    public Element getSingleOperand() {
        return getChild(Element.class, 0);
    }

    public void setSingleOperand(Element singleOperand) {
        setChild(0, singleOperand);
        this.singleOperand = singleOperand;
    }

    @Override
    public String toString() {
        return super.toString() + " (SingleOp) " + getSingleOperand();
    }

    @Override
    public String code() {
        return getSingleOperand().code();
    }
}
