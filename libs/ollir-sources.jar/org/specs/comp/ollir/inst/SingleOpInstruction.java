/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.tree.TreeNode;

import java.util.Arrays;
import java.util.List;

/**
 * Class representing the instructions with a single element. I.e., without other elements (operands) and without
 * operation. These instructions are in rhs of assignments such as a = b;
 */
public class SingleOpInstruction extends Instruction {

    // Instruction with a single operand and without operation
    Element singleOperand;

    public Element getSingleOperand() {
        return singleOperand;
    }

    public void setSingleOperand(Element singleOperand) {
        this.singleOperand = singleOperand;
    }

    @Override
    public String toString() {
        return super.toString() + " (SingleOp) " + singleOperand;
    }

    public SingleOpInstruction(Element o1) {
        super(InstructionType.NOPER);
        this.singleOperand = o1;
    }

    @Override
    public List<TreeNode> getChildren() {
        return Arrays.asList(singleOperand);
    }
}
