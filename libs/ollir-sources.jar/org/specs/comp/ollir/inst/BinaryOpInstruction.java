/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operation;

import java.util.Arrays;
import java.util.List;

/**
 * Class representing all the instructions with 2 operands.
 */
public class BinaryOpInstruction extends OpInstruction {

    Element leftOperand;
    Element rightOperand;
    Operation operation;

    public void setLeftOperand(Element leftOperand) {
        this.leftOperand = leftOperand;
    }

    public Element getLeftOperand() {
        return leftOperand;
    }

    public Element getRightOperand() {
        return rightOperand;
    }

    public void setRightOperand(Element rightOperand) {
        this.rightOperand = rightOperand;
    }

    @Override
    public String toString() {
        return super.toString() + " " + leftOperand + " " + this.operation.getOpType() + " "
                + rightOperand;
    }

    public BinaryOpInstruction(Element o1, Operation oper, Element o2) {
        super(InstructionType.BINARYOPER, oper);
        this.operation = oper;
        this.leftOperand = o1;
        this.rightOperand = o2;
    }

    /**
     * Returns the left operand, followed by the right operand
     */
    @Override
    public List<Element> getOperands() {
        return Arrays.asList(getLeftOperand(), getRightOperand());
    }

    /**
     * Receives the left operand, followed by the right operand.
     */
    @Override
    public void setOperands(List<Element> operands) {
        if (operands.size() != 2) {
            throw new RuntimeException("Operands must have size 2, has size " + operands.size());
        }

        setLeftOperand(operands.get(0));
        setRightOperand(operands.get(1));

    }

}
