/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Operation;
import org.specs.comp.ollir.tree.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing the OLLIR instructions that are operations.
 */
public abstract class OpInstruction extends Instruction {

    Operation operation;

    public OpInstruction(InstructionType tp, Operation operation) {
        super(tp);

        this.operation = operation;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public abstract List<Element> getOperands();

    public abstract void setOperands(List<Element> operands);

    @Override
    public List<TreeNode> getChildren() {
        return new ArrayList<>(getOperands());
    }
}
