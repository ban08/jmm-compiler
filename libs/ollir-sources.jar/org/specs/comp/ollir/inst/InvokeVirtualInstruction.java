package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

import java.util.List;
import java.util.stream.Collectors;

public final class InvokeVirtualInstruction extends CallInstruction {

    public InvokeVirtualInstruction(Element caller, Element methodName, List<Element> arguments, Type returnType, boolean isIsolated) {
        super(caller, methodName, arguments, returnType, isIsolated);
    }

    @Override
    public String code() {
        var code = new StringBuilder();

        code.append("invokevirtual(" + getCaller().code() + ", " + getMethodName().code());

        var argsCode = getArguments().stream().map(Element::code).collect(Collectors.joining(", "));
        if (!getArguments().isEmpty()) {
            code.append(", " + argsCode);
        }

        code.append(")." + getReturnType().code() + ";");

        return code.toString();

    }
}
