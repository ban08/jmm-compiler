package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.NullElement;
import org.specs.comp.ollir.Operand;
import org.specs.comp.ollir.type.Type;

import java.util.List;
import java.util.stream.Collectors;

public final class NewInstruction extends CallInstruction {

    public NewInstruction(Element classNameOrArray, List<Element> arguments, Type returnType, boolean isIsolated) {
        super(classNameOrArray, new NullElement(), arguments, returnType, isIsolated);
    }

    @Override
    public String code() {
        var code = new StringBuilder();

        code.append("new(" + ((Operand) getCaller()).getName());

        var argsCode = getArguments().stream().map(Element::code).collect(Collectors.joining(", "));
        if (!getArguments().isEmpty()) {
            code.append(", " + argsCode);
        }

        code.append(")." + getReturnType().code() + ";");

        return code.toString();

    }
}
