/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.type.Type;

import java.util.List;

/**
 * Class representing assignments. dest = rhs
 */
public class AssignInstruction extends Instruction {


    Type typeOfAssign;

    @Deprecated
    Element dest;

    @Deprecated
    Instruction rhs;

    public AssignInstruction(Element o1, Type tp1, Instruction i1) {
        super(InstructionType.ASSIGN, List.of(o1, i1));
        this.dest = o1;
        this.typeOfAssign = tp1;
        this.rhs = i1;
    }

    @Override
    public void setId(int id) {
        // Set its own id
        super.setId(id);

        // Set id of rhs
        getRhs().setId(id);
        rhs.setId(id);
    }

    public Type getTypeOfAssign() {
        return typeOfAssign;
    }

    public Element getDest() {
        return getChild(Element.class, 0);
    }

    public Instruction getRhs() {
        return getChild(Instruction.class, 1);
    }


    @Override
    public String toString() {
        return super.toString() + " " + this.getDest() + " = " + this.getRhs();
    }

    @Override
    public String code() {
        var rhsCode = getRhs().code();
        var code = getDest().code() + " :=." + getTypeOfAssign().code() + " " + rhsCode;

        if (!rhsCode.endsWith(";")) {
            code += ";";
        }

        return code;
    }
}
