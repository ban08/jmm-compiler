/**
 * Copyright 2022 SPeCS.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License. under the License.
 */

package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;

import java.util.List;

/**
 * Conditional branch that has a {@link OpInstruction} as condition.
 * 
 * @author Joao Bispo
 *
 */
public class OpCondInstruction extends CondBranchInstruction {

    private final OpInstruction inst;

    public OpCondInstruction(OpInstruction inst) {
        this.inst = inst;
    }

    /*
    @Override
    protected String getCondType() {
        return "OpCond";
    }
     */

    @Override
    public List<Element> getOperands() {
        return inst.getOperands();
    }

    @Override
    public OpInstruction getCondition() {
        return inst;
    }

}
