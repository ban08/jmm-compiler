package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.LiteralElement;

public final class LdcInstruction extends Instruction {

    private final LiteralElement element;

    public LdcInstruction(LiteralElement element) {
        super(InstructionType.LDC);
        this.element = element;
    }

    public LiteralElement getElement() {
        return element;
    }
}
