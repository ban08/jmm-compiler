package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.LiteralElement;

public final class LdcInstruction extends Instruction {

    private final LiteralElement element;

    public LiteralElement getElement() {
        return element;
    }

    public LdcInstruction(LiteralElement element) {
        super(InstructionType.LDC);
        this.element = element;
    }


    @Override
    public String code() {
        System.out.println("ELEMENT CODE: " + getElement().code());
        return "ldc(" + getElement().code() + ")." + getElement().getType().code() + ";";

    }
}
