/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.Node;
import org.specs.comp.ollir.tree.TreeNode;

import java.io.PrintStream;
import java.util.Collection;
import java.util.List;

/**
 * Class representing an OLLIR instruction. This extends the Node class, which is used for the CFG.
 */
public abstract class Instruction extends Node {

    private InstructionType instType;

    @Deprecated
    boolean isAssign;

    public Instruction(InstructionType tp, Collection<? extends TreeNode> children) {
        super(children);
        this.instType = tp;
    }

    public Instruction(InstructionType tp) {
        this(tp, List.of());
    }


    public void show() {
        show(System.out);
    }

    public void show(PrintStream out) {
        out.println("\t" + this);
    }

    @Override
    public String toString() {
        return "Inst: " + this.instType.toString();
    }

    public InstructionType getInstType() {
        return this.instType;
    }


    /**
     * @return all successors that are instructions. Will filter out the BEGIN and END node of the CFG
     */
    public List<Instruction> getSuccessorsAsInst() {
        return getSuccessors().stream()
                .filter(n -> n instanceof Instruction)
                .map(Instruction.class::cast)
                .toList();
    }


}