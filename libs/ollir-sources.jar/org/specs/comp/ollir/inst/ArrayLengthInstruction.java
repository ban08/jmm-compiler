package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.NullElement;
import org.specs.comp.ollir.type.Type;

import java.util.List;

public final class ArrayLengthInstruction extends CallInstruction {

    public ArrayLengthInstruction(Element objectRef, Type returnType) {
        super(objectRef, new NullElement(), List.of(), returnType, false);
    }

}
