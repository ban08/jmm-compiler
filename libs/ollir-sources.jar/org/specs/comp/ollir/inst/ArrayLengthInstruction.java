package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.NullElement;
import org.specs.comp.ollir.type.Type;

import java.util.List;

public final class ArrayLengthInstruction extends CallInstruction {

    public ArrayLengthInstruction(Element objectRef, Type returnType) {
        super(objectRef, new NullElement(), List.of(), returnType, false);
    }

    @Override
    public String code() {
        return "arraylength(" + getCaller().code() + ").i32;";
    }

    //        _allowedNameL.i32 :=.i32 arraylength(L.array.i32).i32;
}
