package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

public final class ArrayLengthInstruction extends CallInstruction {

    public ArrayLengthInstruction(Element objectRef, Type returnType) {
        super(objectRef, null,null, returnType, false);
    }

}
