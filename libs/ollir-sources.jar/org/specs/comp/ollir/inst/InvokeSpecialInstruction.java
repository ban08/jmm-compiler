package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

import java.util.List;
import java.util.Optional;

public final class InvokeSpecialInstruction extends CallInstruction {

    private final String superClass;

    public InvokeSpecialInstruction(Element caller, Element methodName, String superClass, List<Element> arguments, Type returnType, boolean isIsolated) {
        super(caller, methodName, arguments, returnType, isIsolated);

        this.superClass = superClass;
    }

    /**
     *
     * @return if this call is invokespecial and has an explicit type for the super that should be called,
     *      returns a String with the class that should be invoked
     */
    public Optional<String> getSuperClass() {
        return Optional.ofNullable(superClass);
    }
}
