/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.InstructionType;
import org.specs.comp.ollir.NullElement;
import org.specs.comp.ollir.NullNode;
import org.specs.comp.ollir.type.Type;
import pt.up.fe.specs.util.SpecsCollections;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Class representing the CALL instructions.
 */
public abstract sealed class CallInstruction extends Instruction
        permits ArrayLengthInstruction, InvokeSpecialInstruction, InvokeStaticInstruction, InvokeVirtualInstruction, NewInstruction {

    private final Type returnType;

    private final boolean isIsolated;


    protected CallInstruction(Element caller, Element methodName, List<Element> arguments,
                              Type returnType, boolean isIsolated) {

        super(InstructionType.CALL, SpecsCollections.concat(List.of(caller, methodName), arguments));

        this.returnType = returnType;
        this.isIsolated = isIsolated;
    }


    public boolean isIsolated() {
        return isIsolated;
    }

    public List<Element> getArguments() {
        return getChildren(Element.class, 2);
    }

    /**
     * @return the base element of the call
     */
    public Element getCaller() {
        return getChild(Element.class, 0);
    }

    public Optional<Element> getMethodNameTry() {

        var methodName = getChild(Element.class, 1);
        return methodName instanceof NullElement ? Optional.empty() : Optional.of(methodName);
    }

    public Element getMethodName() {
        return getMethodNameTry().orElseThrow();
    }


    public String getInvocationKind() {
        var className = getClass().getSimpleName();
        return className.substring(0, className.length() - "Instruction".length());
    }

    public Type getReturnType() {
        return returnType;
    }

    /*
    @Override
    public List<TreeNode> getChildren() {
        var children = new ArrayList<TreeNode>();

        children.add(getCaller());

        getMethodNameTry().ifPresent(m -> children.add(m));

        children.addAll(getArguments());

        return children;

    }

     */

    public List<Element> getOperands() {
        return getChildren().stream()
                .filter(child -> !(child instanceof NullNode))
                .map(child -> (Element) child).toList();
    }

    private int getNumOperands() {
        return getOperands().size();
    }

    @Override
    public String toString() {
        var string = new StringBuilder();

        string.append(super.toString() + " " + getInvocationKind() + " caller " + getCaller());


        if (getNumOperands() > 1) {

            getMethodNameTry().ifPresent(m -> string.append(", methodName " + m));

            var args = getArguments().stream()
                    .map(elem -> elem.toString())
                    .collect(Collectors.joining(", ", ", listOfOperands (", ")"));
            string.append(args);
        }

        return string.toString();
    }


}
