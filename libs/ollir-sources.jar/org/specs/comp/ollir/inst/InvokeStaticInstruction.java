package org.specs.comp.ollir.inst;

import org.specs.comp.ollir.Element;
import org.specs.comp.ollir.type.Type;

import java.util.List;

public final class InvokeStaticInstruction extends CallInstruction {

    public InvokeStaticInstruction(Element className, Element methodName, List<Element> arguments, Type returnType, boolean isIsolated) {
        super(className, methodName, arguments, returnType, isIsolated);
    }

}
