package org.specs.comp.ollir;

import org.specs.comp.ollir.antlr.ErrorReport;

import java.util.Collections;
import java.util.List;

public record OllirParseResult(ClassUnit classUnit, List<ErrorReport> errors) {
    public static OllirParseResult of(ClassUnit classUnit) {
        return new OllirParseResult(classUnit, Collections.emptyList());
    }

    public static OllirParseResult of(List<ErrorReport> errors) {
        return new OllirParseResult(null, errors);
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }
}
