// Generated from org\specs\comp\ollir\Ollir.g4 by ANTLR 4.5.3

    package org.specs.comp.ollir;
    import org.specs.comp.ollir.type.BuiltinKind;
    import org.specs.comp.ollir.inst.Instruction;
    import org.specs.comp.ollir.Element;
    import org.specs.comp.ollir.Operand;
    import org.specs.comp.ollir.type.Type;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class OllirParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		CLASS=1, I32=2, BOOLEAN=3, VOID=4, ARRAY=5, FINAL=6, GOTO=7, IF=8, IMPORT=9, 
		INTERFACE=10, NEW=11, PACKAGE=12, PRIVATE=13, PROTECTED=14, PUBLIC=15, 
		RETURN=16, STATIC=17, THIS=18, LDC=19, INVOKESPECIAL=20, INVOKEVIRTUAL=21, 
		INVOKESTATIC=22, ARRAYLENGTH=23, GETFIELD=24, PUTFIELD=25, GETSTATIC=26, 
		PUTSTATIC=27, METHOD=28, CONSTRUCT=29, FIELD=30, EXTENDS=31, VARARGS=32, 
		IDENTIFIER=33, INTEGER_LITERAL=34, STRING_LITERAL=35, LPAREN=36, RPAREN=37, 
		LBRACE=38, RBRACE=39, LBRACKET=40, RBRACKET=41, SEMICOLON=42, COMMA=43, 
		DOT=44, ASSIGN=45, LT=46, COLON=47, EQ=48, LE=49, GE=50, NE=51, SC_OR=52, 
		SC_AND=53, SC_NOT=54, BIT_NOT=55, PLUS=56, MINUS=57, MUL=58, DIV=59, BIT_AND=60, 
		BIT_OR=61, BIT_XOR=62, REM=63, GT=64, LSHIFT=65, RSHIFT=66, RRSHIFT=67, 
		WS=68, SINGLE_COMMENT=69, BLOCK_COMMENT=70;
	public static final int
		RULE_classUnit = 0, RULE_packageDeclaration = 1, RULE_importDeclaration = 2, 
		RULE_classDeclaration = 3, RULE_field = 4, RULE_initializer = 5, RULE_method = 6, 
		RULE_params = 7, RULE_param = 8, RULE_instructions = 9, RULE_labelledInstruction = 10, 
		RULE_label = 11, RULE_instruction = 12, RULE_newExpression = 13, RULE_invokeExpression = 14, 
		RULE_expression = 15, RULE_operand = 16, RULE_arrayIndices = 17, RULE_arrayIndex = 18, 
		RULE_var = 19, RULE_arg = 20, RULE_objectRef = 21, RULE_literal = 22, 
		RULE_className = 23, RULE_id = 24, RULE_modifiers = 25, RULE_type = 26;
	public static final String[] ruleNames = {
		"classUnit", "packageDeclaration", "importDeclaration", "classDeclaration", 
		"field", "initializer", "method", "params", "param", "instructions", "labelledInstruction", 
		"label", "instruction", "newExpression", "invokeExpression", "expression", 
		"operand", "arrayIndices", "arrayIndex", "var", "arg", "objectRef", "literal", 
		"className", "id", "modifiers", "type"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'class'", "'i32'", "'bool'", "'V'", "'array'", "'final'", "'goto'", 
		"'if'", "'import'", "'interface'", "'new'", "'package'", "'private'", 
		"'protected'", "'public'", "'ret'", "'static'", "'this'", "'ldc'", "'invokespecial'", 
		"'invokevirtual'", "'invokestatic'", "'arraylength'", "'getfield'", "'putfield'", 
		"'getstatic'", "'putstatic'", "'.method'", "'.construct'", "'.field'", 
		"'extends'", "'varargs'", null, null, null, "'('", "')'", "'{'", "'}'", 
		"'['", "']'", "';'", "','", "'.'", "':='", "'<'", "':'", "'=='", "'<='", 
		"'>='", "'!='", "'||'", "'&&'", "'!'", "'~'", "'+'", "'-'", "'*'", "'/'", 
		"'&'", "'|'", "'^'", "'%'", "'>'", "'<<'", "'>>'", "'>>>'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "CLASS", "I32", "BOOLEAN", "VOID", "ARRAY", "FINAL", "GOTO", "IF", 
		"IMPORT", "INTERFACE", "NEW", "PACKAGE", "PRIVATE", "PROTECTED", "PUBLIC", 
		"RETURN", "STATIC", "THIS", "LDC", "INVOKESPECIAL", "INVOKEVIRTUAL", "INVOKESTATIC", 
		"ARRAYLENGTH", "GETFIELD", "PUTFIELD", "GETSTATIC", "PUTSTATIC", "METHOD", 
		"CONSTRUCT", "FIELD", "EXTENDS", "VARARGS", "IDENTIFIER", "INTEGER_LITERAL", 
		"STRING_LITERAL", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "LBRACKET", 
		"RBRACKET", "SEMICOLON", "COMMA", "DOT", "ASSIGN", "LT", "COLON", "EQ", 
		"LE", "GE", "NE", "SC_OR", "SC_AND", "SC_NOT", "BIT_NOT", "PLUS", "MINUS", 
		"MUL", "DIV", "BIT_AND", "BIT_OR", "BIT_XOR", "REM", "GT", "LSHIFT", "RSHIFT", 
		"RRSHIFT", "WS", "SINGLE_COMMENT", "BLOCK_COMMENT"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Ollir.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public OllirParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ClassUnitContext extends ParserRuleContext {
		public PackageDeclarationContext packageDeclaration() {
			return getRuleContext(PackageDeclarationContext.class,0);
		}
		public ClassDeclarationContext classDeclaration() {
			return getRuleContext(ClassDeclarationContext.class,0);
		}
		public TerminalNode EOF() { return getToken(OllirParser.EOF, 0); }
		public List<ImportDeclarationContext> importDeclaration() {
			return getRuleContexts(ImportDeclarationContext.class);
		}
		public ImportDeclarationContext importDeclaration(int i) {
			return getRuleContext(ImportDeclarationContext.class,i);
		}
		public ClassUnitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_classUnit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassUnit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassUnit(this);
		}
	}

	public final ClassUnitContext classUnit() throws RecognitionException {
		ClassUnitContext _localctx = new ClassUnitContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_classUnit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(54);
			packageDeclaration();
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMPORT) {
				{
				{
				setState(55);
				importDeclaration();
				}
				}
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(61);
			classDeclaration();
			setState(62);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PackageDeclarationContext extends ParserRuleContext {
		public IdContext id;
		public List<IdContext> path = new ArrayList<IdContext>();
		public TerminalNode PACKAGE() { return getToken(OllirParser.PACKAGE, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<IdContext> id() {
			return getRuleContexts(IdContext.class);
		}
		public IdContext id(int i) {
			return getRuleContext(IdContext.class,i);
		}
		public List<TerminalNode> DOT() { return getTokens(OllirParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(OllirParser.DOT, i);
		}
		public PackageDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_packageDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterPackageDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitPackageDeclaration(this);
		}
	}

	public final PackageDeclarationContext packageDeclaration() throws RecognitionException {
		PackageDeclarationContext _localctx = new PackageDeclarationContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_packageDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(64);
			match(PACKAGE);
			setState(65);
			((PackageDeclarationContext)_localctx).id = id();
			((PackageDeclarationContext)_localctx).path.add(((PackageDeclarationContext)_localctx).id);
			setState(70);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==DOT) {
				{
				{
				setState(66);
				match(DOT);
				setState(67);
				((PackageDeclarationContext)_localctx).id = id();
				((PackageDeclarationContext)_localctx).path.add(((PackageDeclarationContext)_localctx).id);
				}
				}
				setState(72);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(73);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportDeclarationContext extends ParserRuleContext {
		public boolean isStaticImport =  false;
		public IdContext id;
		public List<IdContext> packageName = new ArrayList<IdContext>();
		public TerminalNode IMPORT() { return getToken(OllirParser.IMPORT, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<IdContext> id() {
			return getRuleContexts(IdContext.class);
		}
		public IdContext id(int i) {
			return getRuleContext(IdContext.class,i);
		}
		public TerminalNode STATIC() { return getToken(OllirParser.STATIC, 0); }
		public List<TerminalNode> DOT() { return getTokens(OllirParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(OllirParser.DOT, i);
		}
		public ImportDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterImportDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitImportDeclaration(this);
		}
	}

	public final ImportDeclarationContext importDeclaration() throws RecognitionException {
		ImportDeclarationContext _localctx = new ImportDeclarationContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_importDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(75);
			match(IMPORT);
			setState(78);
			_la = _input.LA(1);
			if (_la==STATIC) {
				{
				setState(76);
				match(STATIC);
				((ImportDeclarationContext)_localctx).isStaticImport =  true;
				}
			}

			setState(80);
			((ImportDeclarationContext)_localctx).id = id();
			((ImportDeclarationContext)_localctx).packageName.add(((ImportDeclarationContext)_localctx).id);
			setState(83); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(81);
				match(DOT);
				setState(82);
				((ImportDeclarationContext)_localctx).id = id();
				((ImportDeclarationContext)_localctx).packageName.add(((ImportDeclarationContext)_localctx).id);
				}
				}
				setState(85); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==DOT );
			setState(87);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClassDeclarationContext extends ParserRuleContext {
		public ClassNameContext name;
		public IdContext superName;
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(OllirParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(OllirParser.RBRACE, 0); }
		public ClassNameContext className() {
			return getRuleContext(ClassNameContext.class,0);
		}
		public TerminalNode EXTENDS() { return getToken(OllirParser.EXTENDS, 0); }
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public List<MethodContext> method() {
			return getRuleContexts(MethodContext.class);
		}
		public MethodContext method(int i) {
			return getRuleContext(MethodContext.class,i);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ClassDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_classDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassDeclaration(this);
		}
	}

	public final ClassDeclarationContext classDeclaration() throws RecognitionException {
		ClassDeclarationContext _localctx = new ClassDeclarationContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_classDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(89);
			modifiers();
			setState(90);
			((ClassDeclarationContext)_localctx).name = className();
			setState(93);
			_la = _input.LA(1);
			if (_la==EXTENDS) {
				{
				setState(91);
				match(EXTENDS);
				setState(92);
				((ClassDeclarationContext)_localctx).superName = id();
				}
			}

			setState(95);
			match(LBRACE);
			setState(99);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==FIELD) {
				{
				{
				setState(96);
				field();
				}
				}
				setState(101);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(105);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==METHOD || _la==CONSTRUCT) {
				{
				{
				setState(102);
				method();
				}
				}
				setState(107);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(108);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public IdContext name;
		public TerminalNode FIELD() { return getToken(OllirParser.FIELD, 0); }
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public InitializerContext initializer() {
			return getRuleContext(InitializerContext.class,0);
		}
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitField(this);
		}
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_field);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(110);
			match(FIELD);
			setState(111);
			modifiers();
			setState(112);
			((FieldContext)_localctx).name = id();
			setState(113);
			type();
			setState(115);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(114);
				initializer();
				}
			}

			setState(117);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InitializerContext extends ParserRuleContext {
		public Token sign;
		public Token value;
		public TerminalNode ASSIGN() { return getToken(OllirParser.ASSIGN, 0); }
		public TerminalNode INTEGER_LITERAL() { return getToken(OllirParser.INTEGER_LITERAL, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public InitializerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_initializer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInitializer(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInitializer(this);
		}
	}

	public final InitializerContext initializer() throws RecognitionException {
		InitializerContext _localctx = new InitializerContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_initializer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(119);
			match(ASSIGN);
			setState(121);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MINUS) {
				{
				setState(120);
				((InitializerContext)_localctx).sign = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((InitializerContext)_localctx).sign = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
			}

			setState(123);
			((InitializerContext)_localctx).value = match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MethodContext extends ParserRuleContext {
		public boolean isConstructor = false;
		public IdContext name;
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public ParamsContext params() {
			return getRuleContext(ParamsContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(OllirParser.LBRACE, 0); }
		public InstructionsContext instructions() {
			return getRuleContext(InstructionsContext.class,0);
		}
		public TerminalNode RBRACE() { return getToken(OllirParser.RBRACE, 0); }
		public TerminalNode METHOD() { return getToken(OllirParser.METHOD, 0); }
		public TerminalNode CONSTRUCT() { return getToken(OllirParser.CONSTRUCT, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public MethodContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_method; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterMethod(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitMethod(this);
		}
	}

	public final MethodContext method() throws RecognitionException {
		MethodContext _localctx = new MethodContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_method);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			switch (_input.LA(1)) {
			case METHOD:
				{
				setState(125);
				match(METHOD);
				}
				break;
			case CONSTRUCT:
				{
				setState(126);
				match(CONSTRUCT);
				((MethodContext)_localctx).isConstructor = true;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(130);
			modifiers();
			setState(132);
			_la = _input.LA(1);
			if (_la==IDENTIFIER || _la==STRING_LITERAL) {
				{
				setState(131);
				((MethodContext)_localctx).name = id();
				}
			}

			setState(134);
			match(LPAREN);
			setState(135);
			params();
			setState(136);
			match(RPAREN);
			setState(137);
			type();
			setState(138);
			match(LBRACE);
			setState(139);
			instructions();
			setState(140);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamsContext extends ParserRuleContext {
		public List<ParamContext> param() {
			return getRuleContexts(ParamContext.class);
		}
		public ParamContext param(int i) {
			return getRuleContext(ParamContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public ParamsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_params; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterParams(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitParams(this);
		}
	}

	public final ParamsContext params() throws RecognitionException {
		ParamsContext _localctx = new ParamsContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_params);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(150);
			_la = _input.LA(1);
			if (_la==IDENTIFIER || _la==STRING_LITERAL) {
				{
				setState(142);
				param();
				setState(147);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(143);
					match(COMMA);
					setState(144);
					param();
					}
					}
					setState(149);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamContext extends ParserRuleContext {
		public IdContext name;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ParamContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitParam(this);
		}
	}

	public final ParamContext param() throws RecognitionException {
		ParamContext _localctx = new ParamContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_param);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(152);
			((ParamContext)_localctx).name = id();
			setState(153);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionsContext extends ParserRuleContext {
		public List<LabelledInstructionContext> labelledInstruction() {
			return getRuleContexts(LabelledInstructionContext.class);
		}
		public LabelledInstructionContext labelledInstruction(int i) {
			return getRuleContext(LabelledInstructionContext.class,i);
		}
		public InstructionsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructions; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInstructions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInstructions(this);
		}
	}

	public final InstructionsContext instructions() throws RecognitionException {
		InstructionsContext _localctx = new InstructionsContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_instructions);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(158);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << GOTO) | (1L << IF) | (1L << NEW) | (1L << RETURN) | (1L << INVOKESPECIAL) | (1L << INVOKEVIRTUAL) | (1L << INVOKESTATIC) | (1L << PUTFIELD) | (1L << IDENTIFIER) | (1L << STRING_LITERAL))) != 0)) {
				{
				{
				setState(155);
				labelledInstruction();
				}
				}
				setState(160);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelledInstructionContext extends ParserRuleContext {
		public InstructionContext instruction() {
			return getRuleContext(InstructionContext.class,0);
		}
		public List<LabelContext> label() {
			return getRuleContexts(LabelContext.class);
		}
		public LabelContext label(int i) {
			return getRuleContext(LabelContext.class,i);
		}
		public LabelledInstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_labelledInstruction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLabelledInstruction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLabelledInstruction(this);
		}
	}

	public final LabelledInstructionContext labelledInstruction() throws RecognitionException {
		LabelledInstructionContext _localctx = new LabelledInstructionContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_labelledInstruction);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(164);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(161);
					label();
					}
					} 
				}
				setState(166);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,14,_ctx);
			}
			setState(167);
			instruction();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelContext extends ParserRuleContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode COLON() { return getToken(OllirParser.COLON, 0); }
		public LabelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_label; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLabel(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLabel(this);
		}
	}

	public final LabelContext label() throws RecognitionException {
		LabelContext _localctx = new LabelContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_label);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			id();
			setState(170);
			match(COLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionContext extends ParserRuleContext {
		public Instruction instr;
		public InstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instruction; }
	 
		public InstructionContext() { }
		public void copyFrom(InstructionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class AssignmentContext extends InstructionContext {
		public TypeContext arrayType;
		public TypeContext lhsType;
		public TypeContext assignType;
		public ExpressionContext i2;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(OllirParser.ASSIGN, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ArrayIndicesContext arrayIndices() {
			return getRuleContext(ArrayIndicesContext.class,0);
		}
		public AssignmentContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitAssignment(this);
		}
	}
	public static class GotoContext extends InstructionContext {
		public TerminalNode GOTO() { return getToken(OllirParser.GOTO, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public GotoContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterGoto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitGoto(this);
		}
	}
	public static class ReturnContext extends InstructionContext {
		public OperandContext o1;
		public TerminalNode RETURN() { return getToken(OllirParser.RETURN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public ReturnContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterReturn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitReturn(this);
		}
	}
	public static class NewInstrContext extends InstructionContext {
		public NewExpressionContext newExpression() {
			return getRuleContext(NewExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public NewInstrContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewInstr(this);
		}
	}
	public static class InvokeInstrContext extends InstructionContext {
		public InvokeExpressionContext invokeExpression() {
			return getRuleContext(InvokeExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public InvokeInstrContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeInstr(this);
		}
	}
	public static class IfContext extends InstructionContext {
		public ExpressionContext cond;
		public IdContext labelName;
		public TerminalNode IF() { return getToken(OllirParser.IF, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TerminalNode GOTO() { return getToken(OllirParser.GOTO, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public IfContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIf(this);
		}
	}
	public static class PutFieldContext extends InstructionContext {
		public ObjectRefContext o1;
		public ObjectRefContext o2;
		public ArgContext o3;
		public TerminalNode PUTFIELD() { return getToken(OllirParser.PUTFIELD, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<ObjectRefContext> objectRef() {
			return getRuleContexts(ObjectRefContext.class);
		}
		public ObjectRefContext objectRef(int i) {
			return getRuleContext(ObjectRefContext.class,i);
		}
		public ArgContext arg() {
			return getRuleContext(ArgContext.class,0);
		}
		public PutFieldContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterPutField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitPutField(this);
		}
	}

	public final InstructionContext instruction() throws RecognitionException {
		InstructionContext _localctx = new InstructionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_instruction);
		int _la;
		try {
			setState(221);
			switch (_input.LA(1)) {
			case NEW:
				_localctx = new NewInstrContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(172);
				newExpression();
				setState(173);
				match(SEMICOLON);
				}
				break;
			case INVOKESPECIAL:
			case INVOKEVIRTUAL:
			case INVOKESTATIC:
				_localctx = new InvokeInstrContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(175);
				invokeExpression();
				setState(176);
				match(SEMICOLON);
				}
				break;
			case PUTFIELD:
				_localctx = new PutFieldContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(178);
				match(PUTFIELD);
				setState(179);
				match(LPAREN);
				setState(180);
				((PutFieldContext)_localctx).o1 = objectRef();
				setState(181);
				match(COMMA);
				setState(182);
				((PutFieldContext)_localctx).o2 = objectRef();
				setState(183);
				match(COMMA);
				setState(184);
				((PutFieldContext)_localctx).o3 = arg();
				setState(185);
				match(RPAREN);
				setState(186);
				type();
				setState(187);
				match(SEMICOLON);
				}
				break;
			case IDENTIFIER:
			case STRING_LITERAL:
				_localctx = new AssignmentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(189);
				id();
				setState(194);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
				case 1:
					{
					setState(191);
					_la = _input.LA(1);
					if (_la==DOT) {
						{
						setState(190);
						((AssignmentContext)_localctx).arrayType = type();
						}
					}

					setState(193);
					arrayIndices();
					}
					break;
				}
				setState(196);
				((AssignmentContext)_localctx).lhsType = type();
				setState(197);
				match(ASSIGN);
				setState(198);
				((AssignmentContext)_localctx).assignType = type();
				setState(199);
				((AssignmentContext)_localctx).i2 = expression();
				setState(200);
				match(SEMICOLON);
				}
				break;
			case IF:
				_localctx = new IfContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(202);
				match(IF);
				setState(203);
				match(LPAREN);
				setState(204);
				((IfContext)_localctx).cond = expression();
				setState(205);
				match(RPAREN);
				setState(206);
				match(GOTO);
				setState(207);
				((IfContext)_localctx).labelName = id();
				setState(208);
				match(SEMICOLON);
				}
				break;
			case GOTO:
				_localctx = new GotoContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(210);
				match(GOTO);
				setState(211);
				id();
				setState(212);
				match(SEMICOLON);
				}
				break;
			case RETURN:
				_localctx = new ReturnContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(214);
				match(RETURN);
				setState(215);
				type();
				setState(217);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << THIS) | (1L << IDENTIFIER) | (1L << INTEGER_LITERAL) | (1L << STRING_LITERAL) | (1L << PLUS) | (1L << MINUS))) != 0)) {
					{
					setState(216);
					((ReturnContext)_localctx).o1 = operand();
					}
				}

				setState(219);
				match(SEMICOLON);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NewExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public boolean hasArgs = false;
		public TerminalNode NEW() { return getToken(OllirParser.NEW, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TerminalNode ARRAY() { return getToken(OllirParser.ARRAY, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public NewExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_newExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewExpression(this);
		}
	}

	public final NewExpressionContext newExpression() throws RecognitionException {
		NewExpressionContext _localctx = new NewExpressionContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_newExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(223);
			match(NEW);
			setState(238);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(224);
				match(LPAREN);
				setState(227);
				switch (_input.LA(1)) {
				case ARRAY:
					{
					setState(225);
					match(ARRAY);
					}
					break;
				case IDENTIFIER:
				case STRING_LITERAL:
					{
					setState(226);
					id();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(233);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(229);
					match(COMMA);
					setState(230);
					arg();
					}
					}
					setState(235);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(236);
				match(RPAREN);
				((NewExpressionContext)_localctx).hasArgs = true;
				}
			}

			setState(240);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InvokeExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public InvokeExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_invokeExpression; }
	 
		public InvokeExpressionContext() { }
		public void copyFrom(InvokeExpressionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class InvokeVirtualContext extends InvokeExpressionContext {
		public ObjectRefContext o1;
		public Token o2;
		public TerminalNode INVOKEVIRTUAL() { return getToken(OllirParser.INVOKEVIRTUAL, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeVirtualContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeVirtual(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeVirtual(this);
		}
	}
	public static class InvokeSpecialContext extends InvokeExpressionContext {
		public ObjectRefContext o1;
		public Token o2;
		public Token invokeSpecialClass;
		public TerminalNode INVOKESPECIAL() { return getToken(OllirParser.INVOKESPECIAL, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public List<TerminalNode> STRING_LITERAL() { return getTokens(OllirParser.STRING_LITERAL); }
		public TerminalNode STRING_LITERAL(int i) {
			return getToken(OllirParser.STRING_LITERAL, i);
		}
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeSpecialContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeSpecial(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeSpecial(this);
		}
	}
	public static class InvokeStaticContext extends InvokeExpressionContext {
		public IdContext o1;
		public Token o2;
		public TerminalNode INVOKESTATIC() { return getToken(OllirParser.INVOKESTATIC, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeStaticContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeStatic(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeStatic(this);
		}
	}

	public final InvokeExpressionContext invokeExpression() throws RecognitionException {
		InvokeExpressionContext _localctx = new InvokeExpressionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_invokeExpression);
		int _la;
		try {
			setState(290);
			switch (_input.LA(1)) {
			case INVOKESTATIC:
				_localctx = new InvokeStaticContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(242);
				match(INVOKESTATIC);
				setState(243);
				match(LPAREN);
				setState(244);
				((InvokeStaticContext)_localctx).o1 = id();
				setState(245);
				match(COMMA);
				setState(246);
				((InvokeStaticContext)_localctx).o2 = match(STRING_LITERAL);
				setState(251);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(247);
					match(COMMA);
					setState(248);
					arg();
					}
					}
					setState(253);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(254);
				match(RPAREN);
				setState(255);
				type();
				}
				break;
			case INVOKEVIRTUAL:
				_localctx = new InvokeVirtualContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(257);
				match(INVOKEVIRTUAL);
				setState(258);
				match(LPAREN);
				setState(259);
				((InvokeVirtualContext)_localctx).o1 = objectRef();
				setState(260);
				match(COMMA);
				setState(261);
				((InvokeVirtualContext)_localctx).o2 = match(STRING_LITERAL);
				setState(266);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(262);
					match(COMMA);
					setState(263);
					arg();
					}
					}
					setState(268);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(269);
				match(RPAREN);
				setState(270);
				type();
				}
				break;
			case INVOKESPECIAL:
				_localctx = new InvokeSpecialContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(272);
				match(INVOKESPECIAL);
				setState(273);
				match(LPAREN);
				setState(274);
				((InvokeSpecialContext)_localctx).o1 = objectRef();
				setState(275);
				match(COMMA);
				setState(276);
				((InvokeSpecialContext)_localctx).o2 = match(STRING_LITERAL);
				setState(278);
				_la = _input.LA(1);
				if (_la==STRING_LITERAL) {
					{
					setState(277);
					((InvokeSpecialContext)_localctx).invokeSpecialClass = match(STRING_LITERAL);
					}
				}

				setState(284);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(280);
					match(COMMA);
					setState(281);
					arg();
					}
					}
					setState(286);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(287);
				match(RPAREN);
				setState(288);
				type();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class GetFieldExprContext extends ExpressionContext {
		public ObjectRefContext o1;
		public ObjectRefContext o2;
		public TerminalNode GETFIELD() { return getToken(OllirParser.GETFIELD, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(OllirParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public List<ObjectRefContext> objectRef() {
			return getRuleContexts(ObjectRefContext.class);
		}
		public ObjectRefContext objectRef(int i) {
			return getRuleContext(ObjectRefContext.class,i);
		}
		public GetFieldExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterGetFieldExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitGetFieldExpr(this);
		}
	}
	public static class LdcExprContext extends ExpressionContext {
		public TerminalNode LDC() { return getToken(OllirParser.LDC, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public LdcExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLdcExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLdcExpr(this);
		}
	}
	public static class InvokeExprContext extends ExpressionContext {
		public InvokeExpressionContext invokeExpression() {
			return getRuleContext(InvokeExpressionContext.class,0);
		}
		public InvokeExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeExpr(this);
		}
	}
	public static class SingleOpExprContext extends ExpressionContext {
		public OperandContext o1;
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public SingleOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterSingleOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitSingleOpExpr(this);
		}
	}
	public static class NewExprContext extends ExpressionContext {
		public NewExpressionContext newExpression() {
			return getRuleContext(NewExpressionContext.class,0);
		}
		public NewExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewExpr(this);
		}
	}
	public static class UnaryOpExprContext extends ExpressionContext {
		public Token op;
		public TypeContext opType;
		public OperandContext o1;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public TerminalNode SC_NOT() { return getToken(OllirParser.SC_NOT, 0); }
		public TerminalNode BIT_NOT() { return getToken(OllirParser.BIT_NOT, 0); }
		public UnaryOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterUnaryOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitUnaryOpExpr(this);
		}
	}
	public static class ArrayLengthExprContext extends ExpressionContext {
		public ObjectRefContext o1;
		public TerminalNode ARRAYLENGTH() { return getToken(OllirParser.ARRAYLENGTH, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public ArrayLengthExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayLengthExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayLengthExpr(this);
		}
	}
	public static class BinaryOpExprContext extends ExpressionContext {
		public OperandContext o1;
		public Token op;
		public TypeContext opType;
		public OperandContext o2;
		public List<OperandContext> operand() {
			return getRuleContexts(OperandContext.class);
		}
		public OperandContext operand(int i) {
			return getRuleContext(OperandContext.class,i);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode MUL() { return getToken(OllirParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(OllirParser.DIV, 0); }
		public TerminalNode REM() { return getToken(OllirParser.REM, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public TerminalNode LT() { return getToken(OllirParser.LT, 0); }
		public TerminalNode GT() { return getToken(OllirParser.GT, 0); }
		public TerminalNode LE() { return getToken(OllirParser.LE, 0); }
		public TerminalNode GE() { return getToken(OllirParser.GE, 0); }
		public TerminalNode EQ() { return getToken(OllirParser.EQ, 0); }
		public TerminalNode NE() { return getToken(OllirParser.NE, 0); }
		public TerminalNode SC_AND() { return getToken(OllirParser.SC_AND, 0); }
		public TerminalNode SC_OR() { return getToken(OllirParser.SC_OR, 0); }
		public TerminalNode BIT_AND() { return getToken(OllirParser.BIT_AND, 0); }
		public TerminalNode BIT_OR() { return getToken(OllirParser.BIT_OR, 0); }
		public TerminalNode BIT_XOR() { return getToken(OllirParser.BIT_XOR, 0); }
		public TerminalNode LSHIFT() { return getToken(OllirParser.LSHIFT, 0); }
		public TerminalNode RSHIFT() { return getToken(OllirParser.RSHIFT, 0); }
		public TerminalNode RRSHIFT() { return getToken(OllirParser.RRSHIFT, 0); }
		public TerminalNode BIT_NOT() { return getToken(OllirParser.BIT_NOT, 0); }
		public BinaryOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterBinaryOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitBinaryOpExpr(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_expression);
		int _la;
		try {
			setState(324);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				_localctx = new GetFieldExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(292);
				match(GETFIELD);
				setState(293);
				match(LPAREN);
				setState(294);
				((GetFieldExprContext)_localctx).o1 = objectRef();
				setState(295);
				match(COMMA);
				setState(296);
				((GetFieldExprContext)_localctx).o2 = objectRef();
				setState(297);
				match(RPAREN);
				setState(298);
				type();
				}
				break;
			case 2:
				_localctx = new NewExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(300);
				newExpression();
				}
				break;
			case 3:
				_localctx = new InvokeExprContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(301);
				invokeExpression();
				}
				break;
			case 4:
				_localctx = new LdcExprContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(302);
				match(LDC);
				setState(303);
				match(LPAREN);
				setState(304);
				literal();
				setState(305);
				match(RPAREN);
				setState(306);
				type();
				}
				break;
			case 5:
				_localctx = new ArrayLengthExprContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(308);
				match(ARRAYLENGTH);
				setState(309);
				match(LPAREN);
				setState(310);
				((ArrayLengthExprContext)_localctx).o1 = objectRef();
				setState(311);
				match(RPAREN);
				setState(312);
				type();
				}
				break;
			case 6:
				_localctx = new SingleOpExprContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(314);
				((SingleOpExprContext)_localctx).o1 = operand();
				}
				break;
			case 7:
				_localctx = new BinaryOpExprContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(315);
				((BinaryOpExprContext)_localctx).o1 = operand();
				setState(316);
				((BinaryOpExprContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 46)) & ~0x3f) == 0 && ((1L << (_la - 46)) & ((1L << (LT - 46)) | (1L << (EQ - 46)) | (1L << (LE - 46)) | (1L << (GE - 46)) | (1L << (NE - 46)) | (1L << (SC_OR - 46)) | (1L << (SC_AND - 46)) | (1L << (BIT_NOT - 46)) | (1L << (PLUS - 46)) | (1L << (MINUS - 46)) | (1L << (MUL - 46)) | (1L << (DIV - 46)) | (1L << (BIT_AND - 46)) | (1L << (BIT_OR - 46)) | (1L << (BIT_XOR - 46)) | (1L << (REM - 46)) | (1L << (GT - 46)) | (1L << (LSHIFT - 46)) | (1L << (RSHIFT - 46)) | (1L << (RRSHIFT - 46)))) != 0)) ) {
					((BinaryOpExprContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				setState(317);
				((BinaryOpExprContext)_localctx).opType = type();
				setState(318);
				((BinaryOpExprContext)_localctx).o2 = operand();
				}
				break;
			case 8:
				_localctx = new UnaryOpExprContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(320);
				((UnaryOpExprContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==SC_NOT || _la==BIT_NOT) ) {
					((UnaryOpExprContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				setState(321);
				((UnaryOpExprContext)_localctx).opType = type();
				setState(322);
				((UnaryOpExprContext)_localctx).o1 = operand();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperandContext extends ParserRuleContext {
		public Element element;
		public OperandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operand; }
	 
		public OperandContext() { }
		public void copyFrom(OperandContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
		}
	}
	public static class ScalarOperandContext extends OperandContext {
		public ArgContext arg() {
			return getRuleContext(ArgContext.class,0);
		}
		public ScalarOperandContext(OperandContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterScalarOperand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitScalarOperand(this);
		}
	}
	public static class ArrayAccessOperandContext extends OperandContext {
		public TypeContext arrayType;
		public TypeContext elType;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ArrayIndicesContext arrayIndices() {
			return getRuleContext(ArrayIndicesContext.class,0);
		}
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public ArrayAccessOperandContext(OperandContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayAccessOperand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayAccessOperand(this);
		}
	}

	public final OperandContext operand() throws RecognitionException {
		OperandContext _localctx = new OperandContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_operand);
		int _la;
		try {
			setState(334);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,29,_ctx) ) {
			case 1:
				_localctx = new ScalarOperandContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(326);
				arg();
				}
				break;
			case 2:
				_localctx = new ArrayAccessOperandContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(327);
				id();
				setState(329);
				_la = _input.LA(1);
				if (_la==DOT) {
					{
					setState(328);
					((ArrayAccessOperandContext)_localctx).arrayType = type();
					}
				}

				setState(331);
				arrayIndices();
				setState(332);
				((ArrayAccessOperandContext)_localctx).elType = type();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayIndicesContext extends ParserRuleContext {
		public List<TerminalNode> LBRACKET() { return getTokens(OllirParser.LBRACKET); }
		public TerminalNode LBRACKET(int i) {
			return getToken(OllirParser.LBRACKET, i);
		}
		public List<ArrayIndexContext> arrayIndex() {
			return getRuleContexts(ArrayIndexContext.class);
		}
		public ArrayIndexContext arrayIndex(int i) {
			return getRuleContext(ArrayIndexContext.class,i);
		}
		public List<TerminalNode> RBRACKET() { return getTokens(OllirParser.RBRACKET); }
		public TerminalNode RBRACKET(int i) {
			return getToken(OllirParser.RBRACKET, i);
		}
		public ArrayIndicesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayIndices; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayIndices(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayIndices(this);
		}
	}

	public final ArrayIndicesContext arrayIndices() throws RecognitionException {
		ArrayIndicesContext _localctx = new ArrayIndicesContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_arrayIndices);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(340); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(336);
				match(LBRACKET);
				setState(337);
				arrayIndex();
				setState(338);
				match(RBRACKET);
				}
				}
				setState(342); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==LBRACKET );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayIndexContext extends ParserRuleContext {
		public Element element;
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public ArrayIndexContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayIndex; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayIndex(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayIndex(this);
		}
	}

	public final ArrayIndexContext arrayIndex() throws RecognitionException {
		ArrayIndexContext _localctx = new ArrayIndexContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_arrayIndex);
		try {
			setState(346);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,31,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(344);
				var();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(345);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarContext extends ParserRuleContext {
		public Operand op;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public VarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterVar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitVar(this);
		}
	}

	public final VarContext var() throws RecognitionException {
		VarContext _localctx = new VarContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_var);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(348);
			id();
			setState(349);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArgContext extends ParserRuleContext {
		public Element element;
		public ArgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arg; }
	 
		public ArgContext() { }
		public void copyFrom(ArgContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
		}
	}
	public static class IdArgContext extends ArgContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIdArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIdArg(this);
		}
	}
	public static class ThisArgContext extends ArgContext {
		public TerminalNode THIS() { return getToken(OllirParser.THIS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ThisArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterThisArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitThisArg(this);
		}
	}
	public static class LiteralArgContext extends ArgContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLiteralArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLiteralArg(this);
		}
	}

	public final ArgContext arg() throws RecognitionException {
		ArgContext _localctx = new ArgContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_arg);
		try {
			setState(357);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
			case 1:
				_localctx = new IdArgContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(351);
				id();
				setState(352);
				type();
				}
				break;
			case 2:
				_localctx = new ThisArgContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(354);
				match(THIS);
				setState(355);
				type();
				}
				break;
			case 3:
				_localctx = new LiteralArgContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(356);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ObjectRefContext extends ParserRuleContext {
		public Operand op;
		public ObjectRefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_objectRef; }
	 
		public ObjectRefContext() { }
		public void copyFrom(ObjectRefContext ctx) {
			super.copyFrom(ctx);
			this.op = ctx.op;
		}
	}
	public static class ArrayRefContext extends ObjectRefContext {
		public TerminalNode ARRAY() { return getToken(OllirParser.ARRAY, 0); }
		public ArrayRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayRef(this);
		}
	}
	public static class ThisClassRefContext extends ObjectRefContext {
		public TerminalNode THIS() { return getToken(OllirParser.THIS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ThisClassRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterThisClassRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitThisClassRef(this);
		}
	}
	public static class InstRefContext extends ObjectRefContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public InstRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInstRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInstRef(this);
		}
	}

	public final ObjectRefContext objectRef() throws RecognitionException {
		ObjectRefContext _localctx = new ObjectRefContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_objectRef);
		int _la;
		try {
			setState(367);
			switch (_input.LA(1)) {
			case IDENTIFIER:
			case STRING_LITERAL:
				_localctx = new InstRefContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(359);
				id();
				setState(360);
				type();
				}
				break;
			case THIS:
				_localctx = new ThisClassRefContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(362);
				match(THIS);
				setState(364);
				_la = _input.LA(1);
				if (_la==DOT) {
					{
					setState(363);
					type();
					}
				}

				}
				break;
			case ARRAY:
				_localctx = new ArrayRefContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(366);
				match(ARRAY);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public LiteralElement element;
		public String sign = "";
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
	 
		public LiteralContext() { }
		public void copyFrom(LiteralContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
			this.sign = ctx.sign;
		}
	}
	public static class StringLiteralContext extends LiteralContext {
		public Token value;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public StringLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterStringLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitStringLiteral(this);
		}
	}
	public static class IntegerLiteralContext extends LiteralContext {
		public Token value;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(OllirParser.INTEGER_LITERAL, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public IntegerLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIntegerLiteral(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_literal);
		try {
			setState(378);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
			case PLUS:
			case MINUS:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(372);
				switch (_input.LA(1)) {
				case PLUS:
					{
					setState(369);
					match(PLUS);
					}
					break;
				case MINUS:
					{
					setState(370);
					match(MINUS);
					((IntegerLiteralContext)_localctx).sign = "-";
					}
					break;
				case INTEGER_LITERAL:
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(374);
				((IntegerLiteralContext)_localctx).value = match(INTEGER_LITERAL);
				setState(375);
				type();
				}
				break;
			case STRING_LITERAL:
				_localctx = new StringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(376);
				((StringLiteralContext)_localctx).value = match(STRING_LITERAL);
				setState(377);
				type();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClassNameContext extends ParserRuleContext {
		public String name;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ClassNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_className; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassName(this);
		}
	}

	public final ClassNameContext className() throws RecognitionException {
		ClassNameContext _localctx = new ClassNameContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_className);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(380);
			id();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdContext extends ParserRuleContext {
		public String name;
		public Token ident;
		public TerminalNode IDENTIFIER() { return getToken(OllirParser.IDENTIFIER, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public IdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_id; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitId(this);
		}
	}

	public final IdContext id() throws RecognitionException {
		IdContext _localctx = new IdContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_id);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(382);
			((IdContext)_localctx).ident = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==IDENTIFIER || _la==STRING_LITERAL) ) {
				((IdContext)_localctx).ident = (Token)_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ModifiersContext extends ParserRuleContext {
		public boolean isFinal = false;
		public boolean isStatic = false;
		public boolean isVarArgs = false;
		public Token visibility;
		public List<TerminalNode> FINAL() { return getTokens(OllirParser.FINAL); }
		public TerminalNode FINAL(int i) {
			return getToken(OllirParser.FINAL, i);
		}
		public List<TerminalNode> STATIC() { return getTokens(OllirParser.STATIC); }
		public TerminalNode STATIC(int i) {
			return getToken(OllirParser.STATIC, i);
		}
		public List<TerminalNode> VARARGS() { return getTokens(OllirParser.VARARGS); }
		public TerminalNode VARARGS(int i) {
			return getToken(OllirParser.VARARGS, i);
		}
		public List<TerminalNode> PUBLIC() { return getTokens(OllirParser.PUBLIC); }
		public TerminalNode PUBLIC(int i) {
			return getToken(OllirParser.PUBLIC, i);
		}
		public List<TerminalNode> PRIVATE() { return getTokens(OllirParser.PRIVATE); }
		public TerminalNode PRIVATE(int i) {
			return getToken(OllirParser.PRIVATE, i);
		}
		public List<TerminalNode> PROTECTED() { return getTokens(OllirParser.PROTECTED); }
		public TerminalNode PROTECTED(int i) {
			return getToken(OllirParser.PROTECTED, i);
		}
		public ModifiersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_modifiers; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterModifiers(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitModifiers(this);
		}
	}

	public final ModifiersContext modifiers() throws RecognitionException {
		ModifiersContext _localctx = new ModifiersContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_modifiers);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(395);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FINAL) | (1L << PRIVATE) | (1L << PROTECTED) | (1L << PUBLIC) | (1L << STATIC) | (1L << VARARGS))) != 0)) {
				{
				setState(393);
				switch (_input.LA(1)) {
				case PUBLIC:
					{
					setState(384);
					((ModifiersContext)_localctx).visibility = match(PUBLIC);
					}
					break;
				case PRIVATE:
					{
					setState(385);
					((ModifiersContext)_localctx).visibility = match(PRIVATE);
					}
					break;
				case PROTECTED:
					{
					setState(386);
					((ModifiersContext)_localctx).visibility = match(PROTECTED);
					}
					break;
				case FINAL:
					{
					setState(387);
					match(FINAL);
					((ModifiersContext)_localctx).isFinal = true;
					}
					break;
				case STATIC:
					{
					setState(389);
					match(STATIC);
					((ModifiersContext)_localctx).isStatic = true;
					}
					break;
				case VARARGS:
					{
					setState(391);
					match(VARARGS);
					((ModifiersContext)_localctx).isVarArgs = true;
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(397);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public Type ollirType;
		public int dims =  0;
		public boolean isArray = false;
		public BuiltinKind primitive;
		public IdContext name;
		public List<TerminalNode> DOT() { return getTokens(OllirParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(OllirParser.DOT, i);
		}
		public List<TerminalNode> ARRAY() { return getTokens(OllirParser.ARRAY); }
		public TerminalNode ARRAY(int i) {
			return getToken(OllirParser.ARRAY, i);
		}
		public TerminalNode I32() { return getToken(OllirParser.I32, 0); }
		public TerminalNode BOOLEAN() { return getToken(OllirParser.BOOLEAN, 0); }
		public TerminalNode VOID() { return getToken(OllirParser.VOID, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitType(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_type);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(409);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,40,_ctx) ) {
			case 1:
				{
				setState(398);
				match(DOT);
				setState(399);
				match(ARRAY);
				_localctx.dims++; ((TypeContext)_localctx).isArray = true;
				setState(406);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,39,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(401);
						match(DOT);
						setState(402);
						match(ARRAY);
						_localctx.dims++;
						}
						} 
					}
					setState(408);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,39,_ctx);
				}
				}
				break;
			}
			{
			setState(411);
			match(DOT);
			setState(419);
			switch (_input.LA(1)) {
			case I32:
				{
				setState(412);
				match(I32);
				((TypeContext)_localctx).primitive = BuiltinKind.INT32;
				}
				break;
			case BOOLEAN:
				{
				setState(414);
				match(BOOLEAN);
				((TypeContext)_localctx).primitive = BuiltinKind.BOOLEAN;
				}
				break;
			case VOID:
				{
				setState(416);
				match(VOID);
				((TypeContext)_localctx).primitive = BuiltinKind.VOID;
				}
				break;
			case IDENTIFIER:
			case STRING_LITERAL:
				{
				setState(418);
				((TypeContext)_localctx).name = id();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3H\u01a8\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\3\2\3\2\7\2;\n\2\f\2\16\2>\13\2\3\2\3\2"+
		"\3\2\3\3\3\3\3\3\3\3\7\3G\n\3\f\3\16\3J\13\3\3\3\3\3\3\4\3\4\3\4\5\4Q"+
		"\n\4\3\4\3\4\3\4\6\4V\n\4\r\4\16\4W\3\4\3\4\3\5\3\5\3\5\3\5\5\5`\n\5\3"+
		"\5\3\5\7\5d\n\5\f\5\16\5g\13\5\3\5\7\5j\n\5\f\5\16\5m\13\5\3\5\3\5\3\6"+
		"\3\6\3\6\3\6\3\6\5\6v\n\6\3\6\3\6\3\7\3\7\5\7|\n\7\3\7\3\7\3\b\3\b\3\b"+
		"\5\b\u0083\n\b\3\b\3\b\5\b\u0087\n\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3"+
		"\t\3\t\3\t\7\t\u0094\n\t\f\t\16\t\u0097\13\t\5\t\u0099\n\t\3\n\3\n\3\n"+
		"\3\13\7\13\u009f\n\13\f\13\16\13\u00a2\13\13\3\f\7\f\u00a5\n\f\f\f\16"+
		"\f\u00a8\13\f\3\f\3\f\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3"+
		"\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\5\16\u00c2"+
		"\n\16\3\16\5\16\u00c5\n\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16"+
		"\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\16\5\16\u00dc"+
		"\n\16\3\16\3\16\5\16\u00e0\n\16\3\17\3\17\3\17\3\17\5\17\u00e6\n\17\3"+
		"\17\3\17\7\17\u00ea\n\17\f\17\16\17\u00ed\13\17\3\17\3\17\5\17\u00f1\n"+
		"\17\3\17\3\17\3\20\3\20\3\20\3\20\3\20\3\20\3\20\7\20\u00fc\n\20\f\20"+
		"\16\20\u00ff\13\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\7"+
		"\20\u010b\n\20\f\20\16\20\u010e\13\20\3\20\3\20\3\20\3\20\3\20\3\20\3"+
		"\20\3\20\3\20\5\20\u0119\n\20\3\20\3\20\7\20\u011d\n\20\f\20\16\20\u0120"+
		"\13\20\3\20\3\20\3\20\5\20\u0125\n\20\3\21\3\21\3\21\3\21\3\21\3\21\3"+
		"\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3"+
		"\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\5\21\u0147"+
		"\n\21\3\22\3\22\3\22\5\22\u014c\n\22\3\22\3\22\3\22\5\22\u0151\n\22\3"+
		"\23\3\23\3\23\3\23\6\23\u0157\n\23\r\23\16\23\u0158\3\24\3\24\5\24\u015d"+
		"\n\24\3\25\3\25\3\25\3\26\3\26\3\26\3\26\3\26\3\26\5\26\u0168\n\26\3\27"+
		"\3\27\3\27\3\27\3\27\5\27\u016f\n\27\3\27\5\27\u0172\n\27\3\30\3\30\3"+
		"\30\5\30\u0177\n\30\3\30\3\30\3\30\3\30\5\30\u017d\n\30\3\31\3\31\3\32"+
		"\3\32\3\33\3\33\3\33\3\33\3\33\3\33\3\33\3\33\3\33\7\33\u018c\n\33\f\33"+
		"\16\33\u018f\13\33\3\34\3\34\3\34\3\34\3\34\3\34\7\34\u0197\n\34\f\34"+
		"\16\34\u019a\13\34\5\34\u019c\n\34\3\34\3\34\3\34\3\34\3\34\3\34\3\34"+
		"\3\34\5\34\u01a6\n\34\3\34\2\2\35\2\4\6\b\n\f\16\20\22\24\26\30\32\34"+
		"\36 \"$&(*,.\60\62\64\66\2\6\3\2:;\5\2\60\60\62\679E\3\289\4\2##%%\u01cb"+
		"\28\3\2\2\2\4B\3\2\2\2\6M\3\2\2\2\b[\3\2\2\2\np\3\2\2\2\fy\3\2\2\2\16"+
		"\u0082\3\2\2\2\20\u0098\3\2\2\2\22\u009a\3\2\2\2\24\u00a0\3\2\2\2\26\u00a6"+
		"\3\2\2\2\30\u00ab\3\2\2\2\32\u00df\3\2\2\2\34\u00e1\3\2\2\2\36\u0124\3"+
		"\2\2\2 \u0146\3\2\2\2\"\u0150\3\2\2\2$\u0156\3\2\2\2&\u015c\3\2\2\2(\u015e"+
		"\3\2\2\2*\u0167\3\2\2\2,\u0171\3\2\2\2.\u017c\3\2\2\2\60\u017e\3\2\2\2"+
		"\62\u0180\3\2\2\2\64\u018d\3\2\2\2\66\u019b\3\2\2\28<\5\4\3\29;\5\6\4"+
		"\2:9\3\2\2\2;>\3\2\2\2<:\3\2\2\2<=\3\2\2\2=?\3\2\2\2><\3\2\2\2?@\5\b\5"+
		"\2@A\7\2\2\3A\3\3\2\2\2BC\7\16\2\2CH\5\62\32\2DE\7.\2\2EG\5\62\32\2FD"+
		"\3\2\2\2GJ\3\2\2\2HF\3\2\2\2HI\3\2\2\2IK\3\2\2\2JH\3\2\2\2KL\7,\2\2L\5"+
		"\3\2\2\2MP\7\13\2\2NO\7\23\2\2OQ\b\4\1\2PN\3\2\2\2PQ\3\2\2\2QR\3\2\2\2"+
		"RU\5\62\32\2ST\7.\2\2TV\5\62\32\2US\3\2\2\2VW\3\2\2\2WU\3\2\2\2WX\3\2"+
		"\2\2XY\3\2\2\2YZ\7,\2\2Z\7\3\2\2\2[\\\5\64\33\2\\_\5\60\31\2]^\7!\2\2"+
		"^`\5\62\32\2_]\3\2\2\2_`\3\2\2\2`a\3\2\2\2ae\7(\2\2bd\5\n\6\2cb\3\2\2"+
		"\2dg\3\2\2\2ec\3\2\2\2ef\3\2\2\2fk\3\2\2\2ge\3\2\2\2hj\5\16\b\2ih\3\2"+
		"\2\2jm\3\2\2\2ki\3\2\2\2kl\3\2\2\2ln\3\2\2\2mk\3\2\2\2no\7)\2\2o\t\3\2"+
		"\2\2pq\7 \2\2qr\5\64\33\2rs\5\62\32\2su\5\66\34\2tv\5\f\7\2ut\3\2\2\2"+
		"uv\3\2\2\2vw\3\2\2\2wx\7,\2\2x\13\3\2\2\2y{\7/\2\2z|\t\2\2\2{z\3\2\2\2"+
		"{|\3\2\2\2|}\3\2\2\2}~\7$\2\2~\r\3\2\2\2\177\u0083\7\36\2\2\u0080\u0081"+
		"\7\37\2\2\u0081\u0083\b\b\1\2\u0082\177\3\2\2\2\u0082\u0080\3\2\2\2\u0083"+
		"\u0084\3\2\2\2\u0084\u0086\5\64\33\2\u0085\u0087\5\62\32\2\u0086\u0085"+
		"\3\2\2\2\u0086\u0087\3\2\2\2\u0087\u0088\3\2\2\2\u0088\u0089\7&\2\2\u0089"+
		"\u008a\5\20\t\2\u008a\u008b\7\'\2\2\u008b\u008c\5\66\34\2\u008c\u008d"+
		"\7(\2\2\u008d\u008e\5\24\13\2\u008e\u008f\7)\2\2\u008f\17\3\2\2\2\u0090"+
		"\u0095\5\22\n\2\u0091\u0092\7-\2\2\u0092\u0094\5\22\n\2\u0093\u0091\3"+
		"\2\2\2\u0094\u0097\3\2\2\2\u0095\u0093\3\2\2\2\u0095\u0096\3\2\2\2\u0096"+
		"\u0099\3\2\2\2\u0097\u0095\3\2\2\2\u0098\u0090\3\2\2\2\u0098\u0099\3\2"+
		"\2\2\u0099\21\3\2\2\2\u009a\u009b\5\62\32\2\u009b\u009c\5\66\34\2\u009c"+
		"\23\3\2\2\2\u009d\u009f\5\26\f\2\u009e\u009d\3\2\2\2\u009f\u00a2\3\2\2"+
		"\2\u00a0\u009e\3\2\2\2\u00a0\u00a1\3\2\2\2\u00a1\25\3\2\2\2\u00a2\u00a0"+
		"\3\2\2\2\u00a3\u00a5\5\30\r\2\u00a4\u00a3\3\2\2\2\u00a5\u00a8\3\2\2\2"+
		"\u00a6\u00a4\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7\u00a9\3\2\2\2\u00a8\u00a6"+
		"\3\2\2\2\u00a9\u00aa\5\32\16\2\u00aa\27\3\2\2\2\u00ab\u00ac\5\62\32\2"+
		"\u00ac\u00ad\7\61\2\2\u00ad\31\3\2\2\2\u00ae\u00af\5\34\17\2\u00af\u00b0"+
		"\7,\2\2\u00b0\u00e0\3\2\2\2\u00b1\u00b2\5\36\20\2\u00b2\u00b3\7,\2\2\u00b3"+
		"\u00e0\3\2\2\2\u00b4\u00b5\7\33\2\2\u00b5\u00b6\7&\2\2\u00b6\u00b7\5,"+
		"\27\2\u00b7\u00b8\7-\2\2\u00b8\u00b9\5,\27\2\u00b9\u00ba\7-\2\2\u00ba"+
		"\u00bb\5*\26\2\u00bb\u00bc\7\'\2\2\u00bc\u00bd\5\66\34\2\u00bd\u00be\7"+
		",\2\2\u00be\u00e0\3\2\2\2\u00bf\u00c4\5\62\32\2\u00c0\u00c2\5\66\34\2"+
		"\u00c1\u00c0\3\2\2\2\u00c1\u00c2\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3\u00c5"+
		"\5$\23\2\u00c4\u00c1\3\2\2\2\u00c4\u00c5\3\2\2\2\u00c5\u00c6\3\2\2\2\u00c6"+
		"\u00c7\5\66\34\2\u00c7\u00c8\7/\2\2\u00c8\u00c9\5\66\34\2\u00c9\u00ca"+
		"\5 \21\2\u00ca\u00cb\7,\2\2\u00cb\u00e0\3\2\2\2\u00cc\u00cd\7\n\2\2\u00cd"+
		"\u00ce\7&\2\2\u00ce\u00cf\5 \21\2\u00cf\u00d0\7\'\2\2\u00d0\u00d1\7\t"+
		"\2\2\u00d1\u00d2\5\62\32\2\u00d2\u00d3\7,\2\2\u00d3\u00e0\3\2\2\2\u00d4"+
		"\u00d5\7\t\2\2\u00d5\u00d6\5\62\32\2\u00d6\u00d7\7,\2\2\u00d7\u00e0\3"+
		"\2\2\2\u00d8\u00d9\7\22\2\2\u00d9\u00db\5\66\34\2\u00da\u00dc\5\"\22\2"+
		"\u00db\u00da\3\2\2\2\u00db\u00dc\3\2\2\2\u00dc\u00dd\3\2\2\2\u00dd\u00de"+
		"\7,\2\2\u00de\u00e0\3\2\2\2\u00df\u00ae\3\2\2\2\u00df\u00b1\3\2\2\2\u00df"+
		"\u00b4\3\2\2\2\u00df\u00bf\3\2\2\2\u00df\u00cc\3\2\2\2\u00df\u00d4\3\2"+
		"\2\2\u00df\u00d8\3\2\2\2\u00e0\33\3\2\2\2\u00e1\u00f0\7\r\2\2\u00e2\u00e5"+
		"\7&\2\2\u00e3\u00e6\7\7\2\2\u00e4\u00e6\5\62\32\2\u00e5\u00e3\3\2\2\2"+
		"\u00e5\u00e4\3\2\2\2\u00e6\u00eb\3\2\2\2\u00e7\u00e8\7-\2\2\u00e8\u00ea"+
		"\5*\26\2\u00e9\u00e7\3\2\2\2\u00ea\u00ed\3\2\2\2\u00eb\u00e9\3\2\2\2\u00eb"+
		"\u00ec\3\2\2\2\u00ec\u00ee\3\2\2\2\u00ed\u00eb\3\2\2\2\u00ee\u00ef\7\'"+
		"\2\2\u00ef\u00f1\b\17\1\2\u00f0\u00e2\3\2\2\2\u00f0\u00f1\3\2\2\2\u00f1"+
		"\u00f2\3\2\2\2\u00f2\u00f3\5\66\34\2\u00f3\35\3\2\2\2\u00f4\u00f5\7\30"+
		"\2\2\u00f5\u00f6\7&\2\2\u00f6\u00f7\5\62\32\2\u00f7\u00f8\7-\2\2\u00f8"+
		"\u00fd\7%\2\2\u00f9\u00fa\7-\2\2\u00fa\u00fc\5*\26\2\u00fb\u00f9\3\2\2"+
		"\2\u00fc\u00ff\3\2\2\2\u00fd\u00fb\3\2\2\2\u00fd\u00fe\3\2\2\2\u00fe\u0100"+
		"\3\2\2\2\u00ff\u00fd\3\2\2\2\u0100\u0101\7\'\2\2\u0101\u0102\5\66\34\2"+
		"\u0102\u0125\3\2\2\2\u0103\u0104\7\27\2\2\u0104\u0105\7&\2\2\u0105\u0106"+
		"\5,\27\2\u0106\u0107\7-\2\2\u0107\u010c\7%\2\2\u0108\u0109\7-\2\2\u0109"+
		"\u010b\5*\26\2\u010a\u0108\3\2\2\2\u010b\u010e\3\2\2\2\u010c\u010a\3\2"+
		"\2\2\u010c\u010d\3\2\2\2\u010d\u010f\3\2\2\2\u010e\u010c\3\2\2\2\u010f"+
		"\u0110\7\'\2\2\u0110\u0111\5\66\34\2\u0111\u0125\3\2\2\2\u0112\u0113\7"+
		"\26\2\2\u0113\u0114\7&\2\2\u0114\u0115\5,\27\2\u0115\u0116\7-\2\2\u0116"+
		"\u0118\7%\2\2\u0117\u0119\7%\2\2\u0118\u0117\3\2\2\2\u0118\u0119\3\2\2"+
		"\2\u0119\u011e\3\2\2\2\u011a\u011b\7-\2\2\u011b\u011d\5*\26\2\u011c\u011a"+
		"\3\2\2\2\u011d\u0120\3\2\2\2\u011e\u011c\3\2\2\2\u011e\u011f\3\2\2\2\u011f"+
		"\u0121\3\2\2\2\u0120\u011e\3\2\2\2\u0121\u0122\7\'\2\2\u0122\u0123\5\66"+
		"\34\2\u0123\u0125\3\2\2\2\u0124\u00f4\3\2\2\2\u0124\u0103\3\2\2\2\u0124"+
		"\u0112\3\2\2\2\u0125\37\3\2\2\2\u0126\u0127\7\32\2\2\u0127\u0128\7&\2"+
		"\2\u0128\u0129\5,\27\2\u0129\u012a\7-\2\2\u012a\u012b\5,\27\2\u012b\u012c"+
		"\7\'\2\2\u012c\u012d\5\66\34\2\u012d\u0147\3\2\2\2\u012e\u0147\5\34\17"+
		"\2\u012f\u0147\5\36\20\2\u0130\u0131\7\25\2\2\u0131\u0132\7&\2\2\u0132"+
		"\u0133\5.\30\2\u0133\u0134\7\'\2\2\u0134\u0135\5\66\34\2\u0135\u0147\3"+
		"\2\2\2\u0136\u0137\7\31\2\2\u0137\u0138\7&\2\2\u0138\u0139\5,\27\2\u0139"+
		"\u013a\7\'\2\2\u013a\u013b\5\66\34\2\u013b\u0147\3\2\2\2\u013c\u0147\5"+
		"\"\22\2\u013d\u013e\5\"\22\2\u013e\u013f\t\3\2\2\u013f\u0140\5\66\34\2"+
		"\u0140\u0141\5\"\22\2\u0141\u0147\3\2\2\2\u0142\u0143\t\4\2\2\u0143\u0144"+
		"\5\66\34\2\u0144\u0145\5\"\22\2\u0145\u0147\3\2\2\2\u0146\u0126\3\2\2"+
		"\2\u0146\u012e\3\2\2\2\u0146\u012f\3\2\2\2\u0146\u0130\3\2\2\2\u0146\u0136"+
		"\3\2\2\2\u0146\u013c\3\2\2\2\u0146\u013d\3\2\2\2\u0146\u0142\3\2\2\2\u0147"+
		"!\3\2\2\2\u0148\u0151\5*\26\2\u0149\u014b\5\62\32\2\u014a\u014c\5\66\34"+
		"\2\u014b\u014a\3\2\2\2\u014b\u014c\3\2\2\2\u014c\u014d\3\2\2\2\u014d\u014e"+
		"\5$\23\2\u014e\u014f\5\66\34\2\u014f\u0151\3\2\2\2\u0150\u0148\3\2\2\2"+
		"\u0150\u0149\3\2\2\2\u0151#\3\2\2\2\u0152\u0153\7*\2\2\u0153\u0154\5&"+
		"\24\2\u0154\u0155\7+\2\2\u0155\u0157\3\2\2\2\u0156\u0152\3\2\2\2\u0157"+
		"\u0158\3\2\2\2\u0158\u0156\3\2\2\2\u0158\u0159\3\2\2\2\u0159%\3\2\2\2"+
		"\u015a\u015d\5(\25\2\u015b\u015d\5.\30\2\u015c\u015a\3\2\2\2\u015c\u015b"+
		"\3\2\2\2\u015d\'\3\2\2\2\u015e\u015f\5\62\32\2\u015f\u0160\5\66\34\2\u0160"+
		")\3\2\2\2\u0161\u0162\5\62\32\2\u0162\u0163\5\66\34\2\u0163\u0168\3\2"+
		"\2\2\u0164\u0165\7\24\2\2\u0165\u0168\5\66\34\2\u0166\u0168\5.\30\2\u0167"+
		"\u0161\3\2\2\2\u0167\u0164\3\2\2\2\u0167\u0166\3\2\2\2\u0168+\3\2\2\2"+
		"\u0169\u016a\5\62\32\2\u016a\u016b\5\66\34\2\u016b\u0172\3\2\2\2\u016c"+
		"\u016e\7\24\2\2\u016d\u016f\5\66\34\2\u016e\u016d\3\2\2\2\u016e\u016f"+
		"\3\2\2\2\u016f\u0172\3\2\2\2\u0170\u0172\7\7\2\2\u0171\u0169\3\2\2\2\u0171"+
		"\u016c\3\2\2\2\u0171\u0170\3\2\2\2\u0172-\3\2\2\2\u0173\u0177\7:\2\2\u0174"+
		"\u0175\7;\2\2\u0175\u0177\b\30\1\2\u0176\u0173\3\2\2\2\u0176\u0174\3\2"+
		"\2\2\u0176\u0177\3\2\2\2\u0177\u0178\3\2\2\2\u0178\u0179\7$\2\2\u0179"+
		"\u017d\5\66\34\2\u017a\u017b\7%\2\2\u017b\u017d\5\66\34\2\u017c\u0176"+
		"\3\2\2\2\u017c\u017a\3\2\2\2\u017d/\3\2\2\2\u017e\u017f\5\62\32\2\u017f"+
		"\61\3\2\2\2\u0180\u0181\t\5\2\2\u0181\63\3\2\2\2\u0182\u018c\7\21\2\2"+
		"\u0183\u018c\7\17\2\2\u0184\u018c\7\20\2\2\u0185\u0186\7\b\2\2\u0186\u018c"+
		"\b\33\1\2\u0187\u0188\7\23\2\2\u0188\u018c\b\33\1\2\u0189\u018a\7\"\2"+
		"\2\u018a\u018c\b\33\1\2\u018b\u0182\3\2\2\2\u018b\u0183\3\2\2\2\u018b"+
		"\u0184\3\2\2\2\u018b\u0185\3\2\2\2\u018b\u0187\3\2\2\2\u018b\u0189\3\2"+
		"\2\2\u018c\u018f\3\2\2\2\u018d\u018b\3\2\2\2\u018d\u018e\3\2\2\2\u018e"+
		"\65\3\2\2\2\u018f\u018d\3\2\2\2\u0190\u0191\7.\2\2\u0191\u0192\7\7\2\2"+
		"\u0192\u0198\b\34\1\2\u0193\u0194\7.\2\2\u0194\u0195\7\7\2\2\u0195\u0197"+
		"\b\34\1\2\u0196\u0193\3\2\2\2\u0197\u019a\3\2\2\2\u0198\u0196\3\2\2\2"+
		"\u0198\u0199\3\2\2\2\u0199\u019c\3\2\2\2\u019a\u0198\3\2\2\2\u019b\u0190"+
		"\3\2\2\2\u019b\u019c\3\2\2\2\u019c\u019d\3\2\2\2\u019d\u01a5\7.\2\2\u019e"+
		"\u019f\7\4\2\2\u019f\u01a6\b\34\1\2\u01a0\u01a1\7\5\2\2\u01a1\u01a6\b"+
		"\34\1\2\u01a2\u01a3\7\6\2\2\u01a3\u01a6\b\34\1\2\u01a4\u01a6\5\62\32\2"+
		"\u01a5\u019e\3\2\2\2\u01a5\u01a0\3\2\2\2\u01a5\u01a2\3\2\2\2\u01a5\u01a4"+
		"\3\2\2\2\u01a6\67\3\2\2\2,<HPW_eku{\u0082\u0086\u0095\u0098\u00a0\u00a6"+
		"\u00c1\u00c4\u00db\u00df\u00e5\u00eb\u00f0\u00fd\u010c\u0118\u011e\u0124"+
		"\u0146\u014b\u0150\u0158\u015c\u0167\u016e\u0171\u0176\u017c\u018b\u018d"+
		"\u0198\u019b\u01a5";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}