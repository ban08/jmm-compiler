// Generated from org\specs\comp\ollir\Ollir.g4 by ANTLR 4.5.3

    package org.specs.comp.ollir;
    import org.specs.comp.ollir.type.BuiltinKind;
    import org.specs.comp.ollir.inst.Instruction;
    import org.specs.comp.ollir.Element;
    import org.specs.comp.ollir.Operand;
    import org.specs.comp.ollir.type.Type;

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class OllirParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.5.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		DOT=1, CLASS=2, I32=3, BOOLEAN=4, VOID=5, ARRAY=6, FINAL=7, GOTO=8, IF=9, 
		IMPORT=10, INTERFACE=11, NEW=12, PACKAGE=13, PRIVATE=14, PROTECTED=15, 
		PUBLIC=16, RETURN=17, STATIC=18, THIS=19, LDC=20, INVOKESPECIAL=21, INVOKEVIRTUAL=22, 
		INVOKESTATIC=23, ARRAYLENGTH=24, GETFIELD=25, PUTFIELD=26, GETSTATIC=27, 
		PUTSTATIC=28, METHOD=29, CONSTRUCT=30, FIELD=31, EXTENDS=32, VARARGS=33, 
		METHOD_PACK=34, CONSTRUCT_PACK=35, FIELD_PACK=36, IDENTIFIER=37, INTEGER_LITERAL=38, 
		STRING_LITERAL=39, LPAREN=40, RPAREN=41, LBRACE=42, RBRACE=43, LBRACKET=44, 
		RBRACKET=45, SEMICOLON=46, COMMA=47, ASSIGN=48, LT=49, COLON=50, EQ=51, 
		LE=52, GE=53, NE=54, SC_OR=55, SC_AND=56, SC_NOT=57, BIT_NOT=58, PLUS=59, 
		MINUS=60, MUL=61, DIV=62, BIT_AND=63, BIT_OR=64, BIT_XOR=65, REM=66, GT=67, 
		LSHIFT=68, RSHIFT=69, RRSHIFT=70, WS=71, SINGLE_COMMENT=72, BLOCK_COMMENT=73;
	public static final int
		RULE_classUnit = 0, RULE_packageDeclaration = 1, RULE_importDeclaration = 2, 
		RULE_packagePath = 3, RULE_classDeclaration = 4, RULE_field = 5, RULE_initializer = 6, 
		RULE_method = 7, RULE_params = 8, RULE_param = 9, RULE_instructions = 10, 
		RULE_labelledInstruction = 11, RULE_label = 12, RULE_instruction = 13, 
		RULE_newExpression = 14, RULE_invokeExpression = 15, RULE_expression = 16, 
		RULE_operand = 17, RULE_arrayIndices = 18, RULE_arrayIndex = 19, RULE_var = 20, 
		RULE_arg = 21, RULE_objectRef = 22, RULE_literal = 23, RULE_className = 24, 
		RULE_id = 25, RULE_modifiers = 26, RULE_type = 27;
	public static final String[] ruleNames = {
		"classUnit", "packageDeclaration", "importDeclaration", "packagePath", 
		"classDeclaration", "field", "initializer", "method", "params", "param", 
		"instructions", "labelledInstruction", "label", "instruction", "newExpression", 
		"invokeExpression", "expression", "operand", "arrayIndices", "arrayIndex", 
		"var", "arg", "objectRef", "literal", "className", "id", "modifiers", 
		"type"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'.'", "'class'", "'i32'", "'bool'", "'V'", "'array'", "'final'", 
		"'goto'", "'if'", "'import'", "'interface'", "'new'", "'package'", "'private'", 
		"'protected'", "'public'", "'ret'", "'static'", "'this'", "'ldc'", "'invokespecial'", 
		"'invokevirtual'", "'invokestatic'", "'arraylength'", "'getfield'", "'putfield'", 
		"'getstatic'", "'putstatic'", "'.method'", "'.construct'", "'.field'", 
		"'extends'", "'varargs'", null, null, null, null, null, null, "'('", "')'", 
		"'{'", "'}'", "'['", "']'", "';'", "','", "':='", "'<'", "':'", "'=='", 
		"'<='", "'>='", "'!='", "'||'", "'&&'", "'!'", "'~'", "'+'", "'-'", "'*'", 
		"'/'", "'&'", "'|'", "'^'", "'%'", "'>'", "'<<'", "'>>'", "'>>>'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "DOT", "CLASS", "I32", "BOOLEAN", "VOID", "ARRAY", "FINAL", "GOTO", 
		"IF", "IMPORT", "INTERFACE", "NEW", "PACKAGE", "PRIVATE", "PROTECTED", 
		"PUBLIC", "RETURN", "STATIC", "THIS", "LDC", "INVOKESPECIAL", "INVOKEVIRTUAL", 
		"INVOKESTATIC", "ARRAYLENGTH", "GETFIELD", "PUTFIELD", "GETSTATIC", "PUTSTATIC", 
		"METHOD", "CONSTRUCT", "FIELD", "EXTENDS", "VARARGS", "METHOD_PACK", "CONSTRUCT_PACK", 
		"FIELD_PACK", "IDENTIFIER", "INTEGER_LITERAL", "STRING_LITERAL", "LPAREN", 
		"RPAREN", "LBRACE", "RBRACE", "LBRACKET", "RBRACKET", "SEMICOLON", "COMMA", 
		"ASSIGN", "LT", "COLON", "EQ", "LE", "GE", "NE", "SC_OR", "SC_AND", "SC_NOT", 
		"BIT_NOT", "PLUS", "MINUS", "MUL", "DIV", "BIT_AND", "BIT_OR", "BIT_XOR", 
		"REM", "GT", "LSHIFT", "RSHIFT", "RRSHIFT", "WS", "SINGLE_COMMENT", "BLOCK_COMMENT"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Ollir.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public OllirParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ClassUnitContext extends ParserRuleContext {
		public PackageDeclarationContext packageDeclaration() {
			return getRuleContext(PackageDeclarationContext.class,0);
		}
		public ClassDeclarationContext classDeclaration() {
			return getRuleContext(ClassDeclarationContext.class,0);
		}
		public TerminalNode EOF() { return getToken(OllirParser.EOF, 0); }
		public List<ImportDeclarationContext> importDeclaration() {
			return getRuleContexts(ImportDeclarationContext.class);
		}
		public ImportDeclarationContext importDeclaration(int i) {
			return getRuleContext(ImportDeclarationContext.class,i);
		}
		public ClassUnitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_classUnit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassUnit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassUnit(this);
		}
	}

	public final ClassUnitContext classUnit() throws RecognitionException {
		ClassUnitContext _localctx = new ClassUnitContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_classUnit);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(56);
			packageDeclaration();
			setState(60);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==IMPORT) {
				{
				{
				setState(57);
				importDeclaration();
				}
				}
				setState(62);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(63);
			classDeclaration();
			setState(64);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PackageDeclarationContext extends ParserRuleContext {
		public IdContext basePackage;
		public PackagePathContext packagePath;
		public List<PackagePathContext> path = new ArrayList<PackagePathContext>();
		public TerminalNode PACKAGE() { return getToken(OllirParser.PACKAGE, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public List<PackagePathContext> packagePath() {
			return getRuleContexts(PackagePathContext.class);
		}
		public PackagePathContext packagePath(int i) {
			return getRuleContext(PackagePathContext.class,i);
		}
		public PackageDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_packageDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterPackageDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitPackageDeclaration(this);
		}
	}

	public final PackageDeclarationContext packageDeclaration() throws RecognitionException {
		PackageDeclarationContext _localctx = new PackageDeclarationContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_packageDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(66);
			match(PACKAGE);
			setState(67);
			((PackageDeclarationContext)_localctx).basePackage = id();
			setState(71);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DOT) | (1L << METHOD_PACK) | (1L << CONSTRUCT_PACK) | (1L << FIELD_PACK))) != 0)) {
				{
				{
				setState(68);
				((PackageDeclarationContext)_localctx).packagePath = packagePath();
				((PackageDeclarationContext)_localctx).path.add(((PackageDeclarationContext)_localctx).packagePath);
				}
				}
				setState(73);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(74);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ImportDeclarationContext extends ParserRuleContext {
		public boolean isStaticImport =  false;
		public IdContext basePackage;
		public PackagePathContext packagePath;
		public List<PackagePathContext> path = new ArrayList<PackagePathContext>();
		public TerminalNode IMPORT() { return getToken(OllirParser.IMPORT, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode STATIC() { return getToken(OllirParser.STATIC, 0); }
		public List<PackagePathContext> packagePath() {
			return getRuleContexts(PackagePathContext.class);
		}
		public PackagePathContext packagePath(int i) {
			return getRuleContext(PackagePathContext.class,i);
		}
		public ImportDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_importDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterImportDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitImportDeclaration(this);
		}
	}

	public final ImportDeclarationContext importDeclaration() throws RecognitionException {
		ImportDeclarationContext _localctx = new ImportDeclarationContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_importDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(76);
			match(IMPORT);
			setState(79);
			_la = _input.LA(1);
			if (_la==STATIC) {
				{
				setState(77);
				match(STATIC);
				((ImportDeclarationContext)_localctx).isStaticImport =  true;
				}
			}

			setState(81);
			((ImportDeclarationContext)_localctx).basePackage = id();
			setState(83); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(82);
				((ImportDeclarationContext)_localctx).packagePath = packagePath();
				((ImportDeclarationContext)_localctx).path.add(((ImportDeclarationContext)_localctx).packagePath);
				}
				}
				setState(85); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << DOT) | (1L << METHOD_PACK) | (1L << CONSTRUCT_PACK) | (1L << FIELD_PACK))) != 0) );
			setState(87);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PackagePathContext extends ParserRuleContext {
		public String name;
		public IdContext named;
		public Token keyword;
		public TerminalNode DOT() { return getToken(OllirParser.DOT, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode METHOD_PACK() { return getToken(OllirParser.METHOD_PACK, 0); }
		public TerminalNode FIELD_PACK() { return getToken(OllirParser.FIELD_PACK, 0); }
		public TerminalNode CONSTRUCT_PACK() { return getToken(OllirParser.CONSTRUCT_PACK, 0); }
		public PackagePathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_packagePath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterPackagePath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitPackagePath(this);
		}
	}

	public final PackagePathContext packagePath() throws RecognitionException {
		PackagePathContext _localctx = new PackagePathContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_packagePath);
		int _la;
		try {
			setState(92);
			switch (_input.LA(1)) {
			case DOT:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(89);
				match(DOT);
				setState(90);
				((PackagePathContext)_localctx).named = id();
				}
				}
				break;
			case METHOD_PACK:
			case CONSTRUCT_PACK:
			case FIELD_PACK:
				enterOuterAlt(_localctx, 2);
				{
				setState(91);
				((PackagePathContext)_localctx).keyword = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << METHOD_PACK) | (1L << CONSTRUCT_PACK) | (1L << FIELD_PACK))) != 0)) ) {
					((PackagePathContext)_localctx).keyword = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClassDeclarationContext extends ParserRuleContext {
		public ClassNameContext name;
		public IdContext superName;
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(OllirParser.LBRACE, 0); }
		public TerminalNode RBRACE() { return getToken(OllirParser.RBRACE, 0); }
		public ClassNameContext className() {
			return getRuleContext(ClassNameContext.class,0);
		}
		public TerminalNode EXTENDS() { return getToken(OllirParser.EXTENDS, 0); }
		public List<FieldContext> field() {
			return getRuleContexts(FieldContext.class);
		}
		public FieldContext field(int i) {
			return getRuleContext(FieldContext.class,i);
		}
		public List<MethodContext> method() {
			return getRuleContexts(MethodContext.class);
		}
		public MethodContext method(int i) {
			return getRuleContext(MethodContext.class,i);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ClassDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_classDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassDeclaration(this);
		}
	}

	public final ClassDeclarationContext classDeclaration() throws RecognitionException {
		ClassDeclarationContext _localctx = new ClassDeclarationContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_classDeclaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(94);
			modifiers();
			setState(95);
			((ClassDeclarationContext)_localctx).name = className();
			setState(98);
			_la = _input.LA(1);
			if (_la==EXTENDS) {
				{
				setState(96);
				match(EXTENDS);
				setState(97);
				((ClassDeclarationContext)_localctx).superName = id();
				}
			}

			setState(100);
			match(LBRACE);
			setState(104);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==FIELD) {
				{
				{
				setState(101);
				field();
				}
				}
				setState(106);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(110);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==METHOD || _la==CONSTRUCT) {
				{
				{
				setState(107);
				method();
				}
				}
				setState(112);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(113);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FieldContext extends ParserRuleContext {
		public IdContext name;
		public TerminalNode FIELD() { return getToken(OllirParser.FIELD, 0); }
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public InitializerContext initializer() {
			return getRuleContext(InitializerContext.class,0);
		}
		public FieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitField(this);
		}
	}

	public final FieldContext field() throws RecognitionException {
		FieldContext _localctx = new FieldContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_field);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115);
			match(FIELD);
			setState(116);
			modifiers();
			setState(117);
			((FieldContext)_localctx).name = id();
			setState(118);
			type();
			setState(120);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(119);
				initializer();
				}
			}

			setState(122);
			match(SEMICOLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InitializerContext extends ParserRuleContext {
		public Token sign;
		public Token value;
		public TerminalNode ASSIGN() { return getToken(OllirParser.ASSIGN, 0); }
		public TerminalNode INTEGER_LITERAL() { return getToken(OllirParser.INTEGER_LITERAL, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public InitializerContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_initializer; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInitializer(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInitializer(this);
		}
	}

	public final InitializerContext initializer() throws RecognitionException {
		InitializerContext _localctx = new InitializerContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_initializer);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(124);
			match(ASSIGN);
			setState(126);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MINUS) {
				{
				setState(125);
				((InitializerContext)_localctx).sign = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
					((InitializerContext)_localctx).sign = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				}
			}

			setState(128);
			((InitializerContext)_localctx).value = match(INTEGER_LITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MethodContext extends ParserRuleContext {
		public boolean isConstructor = false;
		public IdContext name;
		public ModifiersContext modifiers() {
			return getRuleContext(ModifiersContext.class,0);
		}
		public ParamsContext params() {
			return getRuleContext(ParamsContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(OllirParser.LBRACE, 0); }
		public InstructionsContext instructions() {
			return getRuleContext(InstructionsContext.class,0);
		}
		public TerminalNode RBRACE() { return getToken(OllirParser.RBRACE, 0); }
		public TerminalNode METHOD() { return getToken(OllirParser.METHOD, 0); }
		public TerminalNode CONSTRUCT() { return getToken(OllirParser.CONSTRUCT, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public MethodContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_method; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterMethod(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitMethod(this);
		}
	}

	public final MethodContext method() throws RecognitionException {
		MethodContext _localctx = new MethodContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_method);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(133);
			switch (_input.LA(1)) {
			case METHOD:
				{
				setState(130);
				match(METHOD);
				}
				break;
			case CONSTRUCT:
				{
				setState(131);
				match(CONSTRUCT);
				((MethodContext)_localctx).isConstructor = true;
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(135);
			modifiers();
			setState(137);
			_la = _input.LA(1);
			if (_la==IDENTIFIER || _la==STRING_LITERAL) {
				{
				setState(136);
				((MethodContext)_localctx).name = id();
				}
			}

			setState(139);
			match(LPAREN);
			setState(140);
			params();
			setState(141);
			match(RPAREN);
			setState(142);
			type();
			setState(143);
			match(LBRACE);
			setState(144);
			instructions();
			setState(145);
			match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamsContext extends ParserRuleContext {
		public List<ParamContext> param() {
			return getRuleContexts(ParamContext.class);
		}
		public ParamContext param(int i) {
			return getRuleContext(ParamContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public ParamsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_params; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterParams(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitParams(this);
		}
	}

	public final ParamsContext params() throws RecognitionException {
		ParamsContext _localctx = new ParamsContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_params);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(155);
			_la = _input.LA(1);
			if (_la==IDENTIFIER || _la==STRING_LITERAL) {
				{
				setState(147);
				param();
				setState(152);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(148);
					match(COMMA);
					setState(149);
					param();
					}
					}
					setState(154);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamContext extends ParserRuleContext {
		public IdContext name;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ParamContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterParam(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitParam(this);
		}
	}

	public final ParamContext param() throws RecognitionException {
		ParamContext _localctx = new ParamContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_param);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(157);
			((ParamContext)_localctx).name = id();
			setState(158);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionsContext extends ParserRuleContext {
		public List<LabelledInstructionContext> labelledInstruction() {
			return getRuleContexts(LabelledInstructionContext.class);
		}
		public LabelledInstructionContext labelledInstruction(int i) {
			return getRuleContext(LabelledInstructionContext.class,i);
		}
		public InstructionsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructions; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInstructions(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInstructions(this);
		}
	}

	public final InstructionsContext instructions() throws RecognitionException {
		InstructionsContext _localctx = new InstructionsContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_instructions);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(163);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << GOTO) | (1L << IF) | (1L << NEW) | (1L << RETURN) | (1L << INVOKESPECIAL) | (1L << INVOKEVIRTUAL) | (1L << INVOKESTATIC) | (1L << PUTFIELD) | (1L << IDENTIFIER) | (1L << STRING_LITERAL))) != 0)) {
				{
				{
				setState(160);
				labelledInstruction();
				}
				}
				setState(165);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelledInstructionContext extends ParserRuleContext {
		public InstructionContext instruction() {
			return getRuleContext(InstructionContext.class,0);
		}
		public List<LabelContext> label() {
			return getRuleContexts(LabelContext.class);
		}
		public LabelContext label(int i) {
			return getRuleContext(LabelContext.class,i);
		}
		public LabelledInstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_labelledInstruction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLabelledInstruction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLabelledInstruction(this);
		}
	}

	public final LabelledInstructionContext labelledInstruction() throws RecognitionException {
		LabelledInstructionContext _localctx = new LabelledInstructionContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_labelledInstruction);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(169);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(166);
					label();
					}
					} 
				}
				setState(171);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,15,_ctx);
			}
			setState(172);
			instruction();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelContext extends ParserRuleContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode COLON() { return getToken(OllirParser.COLON, 0); }
		public LabelContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_label; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLabel(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLabel(this);
		}
	}

	public final LabelContext label() throws RecognitionException {
		LabelContext _localctx = new LabelContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_label);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(174);
			id();
			setState(175);
			match(COLON);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructionContext extends ParserRuleContext {
		public Instruction instr;
		public InstructionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instruction; }
	 
		public InstructionContext() { }
		public void copyFrom(InstructionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class AssignmentContext extends InstructionContext {
		public TypeContext arrayType;
		public TypeContext lhsType;
		public TypeContext assignType;
		public ExpressionContext i2;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode ASSIGN() { return getToken(OllirParser.ASSIGN, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public ArrayIndicesContext arrayIndices() {
			return getRuleContext(ArrayIndicesContext.class,0);
		}
		public AssignmentContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitAssignment(this);
		}
	}
	public static class GotoContext extends InstructionContext {
		public TerminalNode GOTO() { return getToken(OllirParser.GOTO, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public GotoContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterGoto(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitGoto(this);
		}
	}
	public static class ReturnContext extends InstructionContext {
		public OperandContext o1;
		public TerminalNode RETURN() { return getToken(OllirParser.RETURN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public ReturnContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterReturn(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitReturn(this);
		}
	}
	public static class NewInstrContext extends InstructionContext {
		public NewExpressionContext newExpression() {
			return getRuleContext(NewExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public NewInstrContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewInstr(this);
		}
	}
	public static class InvokeInstrContext extends InstructionContext {
		public InvokeExpressionContext invokeExpression() {
			return getRuleContext(InvokeExpressionContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public InvokeInstrContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeInstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeInstr(this);
		}
	}
	public static class IfContext extends InstructionContext {
		public ExpressionContext cond;
		public IdContext labelName;
		public TerminalNode IF() { return getToken(OllirParser.IF, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TerminalNode GOTO() { return getToken(OllirParser.GOTO, 0); }
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public IfContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIf(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIf(this);
		}
	}
	public static class PutFieldContext extends InstructionContext {
		public ObjectRefContext o1;
		public ObjectRefContext o2;
		public ArgContext o3;
		public TerminalNode PUTFIELD() { return getToken(OllirParser.PUTFIELD, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode SEMICOLON() { return getToken(OllirParser.SEMICOLON, 0); }
		public List<ObjectRefContext> objectRef() {
			return getRuleContexts(ObjectRefContext.class);
		}
		public ObjectRefContext objectRef(int i) {
			return getRuleContext(ObjectRefContext.class,i);
		}
		public ArgContext arg() {
			return getRuleContext(ArgContext.class,0);
		}
		public PutFieldContext(InstructionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterPutField(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitPutField(this);
		}
	}

	public final InstructionContext instruction() throws RecognitionException {
		InstructionContext _localctx = new InstructionContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_instruction);
		int _la;
		try {
			setState(226);
			switch (_input.LA(1)) {
			case NEW:
				_localctx = new NewInstrContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(177);
				newExpression();
				setState(178);
				match(SEMICOLON);
				}
				break;
			case INVOKESPECIAL:
			case INVOKEVIRTUAL:
			case INVOKESTATIC:
				_localctx = new InvokeInstrContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(180);
				invokeExpression();
				setState(181);
				match(SEMICOLON);
				}
				break;
			case PUTFIELD:
				_localctx = new PutFieldContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(183);
				match(PUTFIELD);
				setState(184);
				match(LPAREN);
				setState(185);
				((PutFieldContext)_localctx).o1 = objectRef();
				setState(186);
				match(COMMA);
				setState(187);
				((PutFieldContext)_localctx).o2 = objectRef();
				setState(188);
				match(COMMA);
				setState(189);
				((PutFieldContext)_localctx).o3 = arg();
				setState(190);
				match(RPAREN);
				setState(191);
				type();
				setState(192);
				match(SEMICOLON);
				}
				break;
			case IDENTIFIER:
			case STRING_LITERAL:
				_localctx = new AssignmentContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(194);
				id();
				setState(199);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,17,_ctx) ) {
				case 1:
					{
					setState(196);
					_la = _input.LA(1);
					if (_la==DOT) {
						{
						setState(195);
						((AssignmentContext)_localctx).arrayType = type();
						}
					}

					setState(198);
					arrayIndices();
					}
					break;
				}
				setState(201);
				((AssignmentContext)_localctx).lhsType = type();
				setState(202);
				match(ASSIGN);
				setState(203);
				((AssignmentContext)_localctx).assignType = type();
				setState(204);
				((AssignmentContext)_localctx).i2 = expression();
				setState(205);
				match(SEMICOLON);
				}
				break;
			case IF:
				_localctx = new IfContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(207);
				match(IF);
				setState(208);
				match(LPAREN);
				setState(209);
				((IfContext)_localctx).cond = expression();
				setState(210);
				match(RPAREN);
				setState(211);
				match(GOTO);
				setState(212);
				((IfContext)_localctx).labelName = id();
				setState(213);
				match(SEMICOLON);
				}
				break;
			case GOTO:
				_localctx = new GotoContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(215);
				match(GOTO);
				setState(216);
				id();
				setState(217);
				match(SEMICOLON);
				}
				break;
			case RETURN:
				_localctx = new ReturnContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(219);
				match(RETURN);
				setState(220);
				type();
				setState(222);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << THIS) | (1L << IDENTIFIER) | (1L << INTEGER_LITERAL) | (1L << STRING_LITERAL) | (1L << PLUS) | (1L << MINUS))) != 0)) {
					{
					setState(221);
					((ReturnContext)_localctx).o1 = operand();
					}
				}

				setState(224);
				match(SEMICOLON);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NewExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public boolean hasArgs = false;
		public TerminalNode NEW() { return getToken(OllirParser.NEW, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TerminalNode ARRAY() { return getToken(OllirParser.ARRAY, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public NewExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_newExpression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewExpression(this);
		}
	}

	public final NewExpressionContext newExpression() throws RecognitionException {
		NewExpressionContext _localctx = new NewExpressionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_newExpression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(228);
			match(NEW);
			setState(243);
			_la = _input.LA(1);
			if (_la==LPAREN) {
				{
				setState(229);
				match(LPAREN);
				setState(232);
				switch (_input.LA(1)) {
				case ARRAY:
					{
					setState(230);
					match(ARRAY);
					}
					break;
				case IDENTIFIER:
				case STRING_LITERAL:
					{
					setState(231);
					id();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(238);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(234);
					match(COMMA);
					setState(235);
					arg();
					}
					}
					setState(240);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(241);
				match(RPAREN);
				((NewExpressionContext)_localctx).hasArgs = true;
				}
			}

			setState(245);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InvokeExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public InvokeExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_invokeExpression; }
	 
		public InvokeExpressionContext() { }
		public void copyFrom(InvokeExpressionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class InvokeVirtualContext extends InvokeExpressionContext {
		public ObjectRefContext o1;
		public Token o2;
		public TerminalNode INVOKEVIRTUAL() { return getToken(OllirParser.INVOKEVIRTUAL, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeVirtualContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeVirtual(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeVirtual(this);
		}
	}
	public static class InvokeSpecialContext extends InvokeExpressionContext {
		public ObjectRefContext o1;
		public Token o2;
		public Token invokeSpecialClass;
		public TerminalNode INVOKESPECIAL() { return getToken(OllirParser.INVOKESPECIAL, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public List<TerminalNode> STRING_LITERAL() { return getTokens(OllirParser.STRING_LITERAL); }
		public TerminalNode STRING_LITERAL(int i) {
			return getToken(OllirParser.STRING_LITERAL, i);
		}
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeSpecialContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeSpecial(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeSpecial(this);
		}
	}
	public static class InvokeStaticContext extends InvokeExpressionContext {
		public IdContext o1;
		public Token o2;
		public TerminalNode INVOKESTATIC() { return getToken(OllirParser.INVOKESTATIC, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(OllirParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(OllirParser.COMMA, i);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public List<ArgContext> arg() {
			return getRuleContexts(ArgContext.class);
		}
		public ArgContext arg(int i) {
			return getRuleContext(ArgContext.class,i);
		}
		public InvokeStaticContext(InvokeExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeStatic(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeStatic(this);
		}
	}

	public final InvokeExpressionContext invokeExpression() throws RecognitionException {
		InvokeExpressionContext _localctx = new InvokeExpressionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_invokeExpression);
		int _la;
		try {
			setState(295);
			switch (_input.LA(1)) {
			case INVOKESTATIC:
				_localctx = new InvokeStaticContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(247);
				match(INVOKESTATIC);
				setState(248);
				match(LPAREN);
				setState(249);
				((InvokeStaticContext)_localctx).o1 = id();
				setState(250);
				match(COMMA);
				setState(251);
				((InvokeStaticContext)_localctx).o2 = match(STRING_LITERAL);
				setState(256);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(252);
					match(COMMA);
					setState(253);
					arg();
					}
					}
					setState(258);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(259);
				match(RPAREN);
				setState(260);
				type();
				}
				break;
			case INVOKEVIRTUAL:
				_localctx = new InvokeVirtualContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(262);
				match(INVOKEVIRTUAL);
				setState(263);
				match(LPAREN);
				setState(264);
				((InvokeVirtualContext)_localctx).o1 = objectRef();
				setState(265);
				match(COMMA);
				setState(266);
				((InvokeVirtualContext)_localctx).o2 = match(STRING_LITERAL);
				setState(271);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(267);
					match(COMMA);
					setState(268);
					arg();
					}
					}
					setState(273);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(274);
				match(RPAREN);
				setState(275);
				type();
				}
				break;
			case INVOKESPECIAL:
				_localctx = new InvokeSpecialContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(277);
				match(INVOKESPECIAL);
				setState(278);
				match(LPAREN);
				setState(279);
				((InvokeSpecialContext)_localctx).o1 = objectRef();
				setState(280);
				match(COMMA);
				setState(281);
				((InvokeSpecialContext)_localctx).o2 = match(STRING_LITERAL);
				setState(283);
				_la = _input.LA(1);
				if (_la==STRING_LITERAL) {
					{
					setState(282);
					((InvokeSpecialContext)_localctx).invokeSpecialClass = match(STRING_LITERAL);
					}
				}

				setState(289);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(285);
					match(COMMA);
					setState(286);
					arg();
					}
					}
					setState(291);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(292);
				match(RPAREN);
				setState(293);
				type();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public Instruction instr;
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
			this.instr = ctx.instr;
		}
	}
	public static class GetFieldExprContext extends ExpressionContext {
		public ObjectRefContext o1;
		public ObjectRefContext o2;
		public TerminalNode GETFIELD() { return getToken(OllirParser.GETFIELD, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode COMMA() { return getToken(OllirParser.COMMA, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public List<ObjectRefContext> objectRef() {
			return getRuleContexts(ObjectRefContext.class);
		}
		public ObjectRefContext objectRef(int i) {
			return getRuleContext(ObjectRefContext.class,i);
		}
		public GetFieldExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterGetFieldExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitGetFieldExpr(this);
		}
	}
	public static class LdcExprContext extends ExpressionContext {
		public TerminalNode LDC() { return getToken(OllirParser.LDC, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public LdcExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLdcExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLdcExpr(this);
		}
	}
	public static class InvokeExprContext extends ExpressionContext {
		public InvokeExpressionContext invokeExpression() {
			return getRuleContext(InvokeExpressionContext.class,0);
		}
		public InvokeExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInvokeExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInvokeExpr(this);
		}
	}
	public static class SingleOpExprContext extends ExpressionContext {
		public OperandContext o1;
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public SingleOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterSingleOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitSingleOpExpr(this);
		}
	}
	public static class NewExprContext extends ExpressionContext {
		public NewExpressionContext newExpression() {
			return getRuleContext(NewExpressionContext.class,0);
		}
		public NewExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterNewExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitNewExpr(this);
		}
	}
	public static class UnaryOpExprContext extends ExpressionContext {
		public Token op;
		public TypeContext opType;
		public OperandContext o1;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public OperandContext operand() {
			return getRuleContext(OperandContext.class,0);
		}
		public TerminalNode SC_NOT() { return getToken(OllirParser.SC_NOT, 0); }
		public TerminalNode BIT_NOT() { return getToken(OllirParser.BIT_NOT, 0); }
		public UnaryOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterUnaryOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitUnaryOpExpr(this);
		}
	}
	public static class ArrayLengthExprContext extends ExpressionContext {
		public ObjectRefContext o1;
		public TerminalNode ARRAYLENGTH() { return getToken(OllirParser.ARRAYLENGTH, 0); }
		public TerminalNode LPAREN() { return getToken(OllirParser.LPAREN, 0); }
		public TerminalNode RPAREN() { return getToken(OllirParser.RPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ObjectRefContext objectRef() {
			return getRuleContext(ObjectRefContext.class,0);
		}
		public ArrayLengthExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayLengthExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayLengthExpr(this);
		}
	}
	public static class BinaryOpExprContext extends ExpressionContext {
		public OperandContext o1;
		public Token op;
		public TypeContext opType;
		public OperandContext o2;
		public List<OperandContext> operand() {
			return getRuleContexts(OperandContext.class);
		}
		public OperandContext operand(int i) {
			return getRuleContext(OperandContext.class,i);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode MUL() { return getToken(OllirParser.MUL, 0); }
		public TerminalNode DIV() { return getToken(OllirParser.DIV, 0); }
		public TerminalNode REM() { return getToken(OllirParser.REM, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public TerminalNode LT() { return getToken(OllirParser.LT, 0); }
		public TerminalNode GT() { return getToken(OllirParser.GT, 0); }
		public TerminalNode LE() { return getToken(OllirParser.LE, 0); }
		public TerminalNode GE() { return getToken(OllirParser.GE, 0); }
		public TerminalNode EQ() { return getToken(OllirParser.EQ, 0); }
		public TerminalNode NE() { return getToken(OllirParser.NE, 0); }
		public TerminalNode SC_AND() { return getToken(OllirParser.SC_AND, 0); }
		public TerminalNode SC_OR() { return getToken(OllirParser.SC_OR, 0); }
		public TerminalNode BIT_AND() { return getToken(OllirParser.BIT_AND, 0); }
		public TerminalNode BIT_OR() { return getToken(OllirParser.BIT_OR, 0); }
		public TerminalNode BIT_XOR() { return getToken(OllirParser.BIT_XOR, 0); }
		public TerminalNode LSHIFT() { return getToken(OllirParser.LSHIFT, 0); }
		public TerminalNode RSHIFT() { return getToken(OllirParser.RSHIFT, 0); }
		public TerminalNode RRSHIFT() { return getToken(OllirParser.RRSHIFT, 0); }
		public TerminalNode BIT_NOT() { return getToken(OllirParser.BIT_NOT, 0); }
		public BinaryOpExprContext(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterBinaryOpExpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitBinaryOpExpr(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_expression);
		int _la;
		try {
			setState(329);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,28,_ctx) ) {
			case 1:
				_localctx = new GetFieldExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(297);
				match(GETFIELD);
				setState(298);
				match(LPAREN);
				setState(299);
				((GetFieldExprContext)_localctx).o1 = objectRef();
				setState(300);
				match(COMMA);
				setState(301);
				((GetFieldExprContext)_localctx).o2 = objectRef();
				setState(302);
				match(RPAREN);
				setState(303);
				type();
				}
				break;
			case 2:
				_localctx = new NewExprContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(305);
				newExpression();
				}
				break;
			case 3:
				_localctx = new InvokeExprContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(306);
				invokeExpression();
				}
				break;
			case 4:
				_localctx = new LdcExprContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(307);
				match(LDC);
				setState(308);
				match(LPAREN);
				setState(309);
				literal();
				setState(310);
				match(RPAREN);
				setState(311);
				type();
				}
				break;
			case 5:
				_localctx = new ArrayLengthExprContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(313);
				match(ARRAYLENGTH);
				setState(314);
				match(LPAREN);
				setState(315);
				((ArrayLengthExprContext)_localctx).o1 = objectRef();
				setState(316);
				match(RPAREN);
				setState(317);
				type();
				}
				break;
			case 6:
				_localctx = new SingleOpExprContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(319);
				((SingleOpExprContext)_localctx).o1 = operand();
				}
				break;
			case 7:
				_localctx = new BinaryOpExprContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(320);
				((BinaryOpExprContext)_localctx).o1 = operand();
				setState(321);
				((BinaryOpExprContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(((((_la - 49)) & ~0x3f) == 0 && ((1L << (_la - 49)) & ((1L << (LT - 49)) | (1L << (EQ - 49)) | (1L << (LE - 49)) | (1L << (GE - 49)) | (1L << (NE - 49)) | (1L << (SC_OR - 49)) | (1L << (SC_AND - 49)) | (1L << (BIT_NOT - 49)) | (1L << (PLUS - 49)) | (1L << (MINUS - 49)) | (1L << (MUL - 49)) | (1L << (DIV - 49)) | (1L << (BIT_AND - 49)) | (1L << (BIT_OR - 49)) | (1L << (BIT_XOR - 49)) | (1L << (REM - 49)) | (1L << (GT - 49)) | (1L << (LSHIFT - 49)) | (1L << (RSHIFT - 49)) | (1L << (RRSHIFT - 49)))) != 0)) ) {
					((BinaryOpExprContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				setState(322);
				((BinaryOpExprContext)_localctx).opType = type();
				setState(323);
				((BinaryOpExprContext)_localctx).o2 = operand();
				}
				break;
			case 8:
				_localctx = new UnaryOpExprContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(325);
				((UnaryOpExprContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==SC_NOT || _la==BIT_NOT) ) {
					((UnaryOpExprContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				} else {
					consume();
				}
				setState(326);
				((UnaryOpExprContext)_localctx).opType = type();
				setState(327);
				((UnaryOpExprContext)_localctx).o1 = operand();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperandContext extends ParserRuleContext {
		public Element element;
		public OperandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operand; }
	 
		public OperandContext() { }
		public void copyFrom(OperandContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
		}
	}
	public static class ScalarOperandContext extends OperandContext {
		public ArgContext arg() {
			return getRuleContext(ArgContext.class,0);
		}
		public ScalarOperandContext(OperandContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterScalarOperand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitScalarOperand(this);
		}
	}
	public static class ArrayAccessOperandContext extends OperandContext {
		public TypeContext arrayType;
		public TypeContext elType;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ArrayIndicesContext arrayIndices() {
			return getRuleContext(ArrayIndicesContext.class,0);
		}
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public ArrayAccessOperandContext(OperandContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayAccessOperand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayAccessOperand(this);
		}
	}

	public final OperandContext operand() throws RecognitionException {
		OperandContext _localctx = new OperandContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_operand);
		int _la;
		try {
			setState(339);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
			case 1:
				_localctx = new ScalarOperandContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(331);
				arg();
				}
				break;
			case 2:
				_localctx = new ArrayAccessOperandContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(332);
				id();
				setState(334);
				_la = _input.LA(1);
				if (_la==DOT) {
					{
					setState(333);
					((ArrayAccessOperandContext)_localctx).arrayType = type();
					}
				}

				setState(336);
				arrayIndices();
				setState(337);
				((ArrayAccessOperandContext)_localctx).elType = type();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayIndicesContext extends ParserRuleContext {
		public List<TerminalNode> LBRACKET() { return getTokens(OllirParser.LBRACKET); }
		public TerminalNode LBRACKET(int i) {
			return getToken(OllirParser.LBRACKET, i);
		}
		public List<ArrayIndexContext> arrayIndex() {
			return getRuleContexts(ArrayIndexContext.class);
		}
		public ArrayIndexContext arrayIndex(int i) {
			return getRuleContext(ArrayIndexContext.class,i);
		}
		public List<TerminalNode> RBRACKET() { return getTokens(OllirParser.RBRACKET); }
		public TerminalNode RBRACKET(int i) {
			return getToken(OllirParser.RBRACKET, i);
		}
		public ArrayIndicesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayIndices; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayIndices(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayIndices(this);
		}
	}

	public final ArrayIndicesContext arrayIndices() throws RecognitionException {
		ArrayIndicesContext _localctx = new ArrayIndicesContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_arrayIndices);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(345); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(341);
				match(LBRACKET);
				setState(342);
				arrayIndex();
				setState(343);
				match(RBRACKET);
				}
				}
				setState(347); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==LBRACKET );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayIndexContext extends ParserRuleContext {
		public Element element;
		public VarContext var() {
			return getRuleContext(VarContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public ArrayIndexContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayIndex; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayIndex(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayIndex(this);
		}
	}

	public final ArrayIndexContext arrayIndex() throws RecognitionException {
		ArrayIndexContext _localctx = new ArrayIndexContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_arrayIndex);
		try {
			setState(351);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(349);
				var();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(350);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VarContext extends ParserRuleContext {
		public Operand op;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public VarContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_var; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterVar(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitVar(this);
		}
	}

	public final VarContext var() throws RecognitionException {
		VarContext _localctx = new VarContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_var);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(353);
			id();
			setState(354);
			type();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArgContext extends ParserRuleContext {
		public Element element;
		public ArgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arg; }
	 
		public ArgContext() { }
		public void copyFrom(ArgContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
		}
	}
	public static class IdArgContext extends ArgContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public IdArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIdArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIdArg(this);
		}
	}
	public static class ThisArgContext extends ArgContext {
		public TerminalNode THIS() { return getToken(OllirParser.THIS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ThisArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterThisArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitThisArg(this);
		}
	}
	public static class LiteralArgContext extends ArgContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralArgContext(ArgContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterLiteralArg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitLiteralArg(this);
		}
	}

	public final ArgContext arg() throws RecognitionException {
		ArgContext _localctx = new ArgContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_arg);
		try {
			setState(362);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
			case 1:
				_localctx = new IdArgContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(356);
				id();
				setState(357);
				type();
				}
				break;
			case 2:
				_localctx = new ThisArgContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(359);
				match(THIS);
				setState(360);
				type();
				}
				break;
			case 3:
				_localctx = new LiteralArgContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(361);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ObjectRefContext extends ParserRuleContext {
		public Operand op;
		public ObjectRefContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_objectRef; }
	 
		public ObjectRefContext() { }
		public void copyFrom(ObjectRefContext ctx) {
			super.copyFrom(ctx);
			this.op = ctx.op;
		}
	}
	public static class ArrayRefContext extends ObjectRefContext {
		public TerminalNode ARRAY() { return getToken(OllirParser.ARRAY, 0); }
		public ArrayRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterArrayRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitArrayRef(this);
		}
	}
	public static class ThisClassRefContext extends ObjectRefContext {
		public TerminalNode THIS() { return getToken(OllirParser.THIS, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ThisClassRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterThisClassRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitThisClassRef(this);
		}
	}
	public static class InstRefContext extends ObjectRefContext {
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public InstRefContext(ObjectRefContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterInstRef(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitInstRef(this);
		}
	}

	public final ObjectRefContext objectRef() throws RecognitionException {
		ObjectRefContext _localctx = new ObjectRefContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_objectRef);
		int _la;
		try {
			setState(372);
			switch (_input.LA(1)) {
			case IDENTIFIER:
			case STRING_LITERAL:
				_localctx = new InstRefContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(364);
				id();
				setState(365);
				type();
				}
				break;
			case THIS:
				_localctx = new ThisClassRefContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(367);
				match(THIS);
				setState(369);
				_la = _input.LA(1);
				if (_la==DOT) {
					{
					setState(368);
					type();
					}
				}

				}
				break;
			case ARRAY:
				_localctx = new ArrayRefContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(371);
				match(ARRAY);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public LiteralElement element;
		public String sign = "";
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
	 
		public LiteralContext() { }
		public void copyFrom(LiteralContext ctx) {
			super.copyFrom(ctx);
			this.element = ctx.element;
			this.sign = ctx.sign;
		}
	}
	public static class StringLiteralContext extends LiteralContext {
		public Token value;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public StringLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterStringLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitStringLiteral(this);
		}
	}
	public static class IntegerLiteralContext extends LiteralContext {
		public Token value;
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode INTEGER_LITERAL() { return getToken(OllirParser.INTEGER_LITERAL, 0); }
		public TerminalNode PLUS() { return getToken(OllirParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(OllirParser.MINUS, 0); }
		public IntegerLiteralContext(LiteralContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterIntegerLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitIntegerLiteral(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_literal);
		try {
			setState(383);
			switch (_input.LA(1)) {
			case INTEGER_LITERAL:
			case PLUS:
			case MINUS:
				_localctx = new IntegerLiteralContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(377);
				switch (_input.LA(1)) {
				case PLUS:
					{
					setState(374);
					match(PLUS);
					}
					break;
				case MINUS:
					{
					setState(375);
					match(MINUS);
					((IntegerLiteralContext)_localctx).sign = "-";
					}
					break;
				case INTEGER_LITERAL:
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(379);
				((IntegerLiteralContext)_localctx).value = match(INTEGER_LITERAL);
				setState(380);
				type();
				}
				break;
			case STRING_LITERAL:
				_localctx = new StringLiteralContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(381);
				((StringLiteralContext)_localctx).value = match(STRING_LITERAL);
				setState(382);
				type();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClassNameContext extends ParserRuleContext {
		public String name;
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public ClassNameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_className; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterClassName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitClassName(this);
		}
	}

	public final ClassNameContext className() throws RecognitionException {
		ClassNameContext _localctx = new ClassNameContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_className);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(385);
			id();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdContext extends ParserRuleContext {
		public String name;
		public Token ident;
		public TerminalNode IDENTIFIER() { return getToken(OllirParser.IDENTIFIER, 0); }
		public TerminalNode STRING_LITERAL() { return getToken(OllirParser.STRING_LITERAL, 0); }
		public IdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_id; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterId(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitId(this);
		}
	}

	public final IdContext id() throws RecognitionException {
		IdContext _localctx = new IdContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_id);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(387);
			((IdContext)_localctx).ident = _input.LT(1);
			_la = _input.LA(1);
			if ( !(_la==IDENTIFIER || _la==STRING_LITERAL) ) {
				((IdContext)_localctx).ident = (Token)_errHandler.recoverInline(this);
			} else {
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ModifiersContext extends ParserRuleContext {
		public boolean isFinal = false;
		public boolean isStatic = false;
		public boolean isVarArgs = false;
		public Token visibility;
		public List<TerminalNode> FINAL() { return getTokens(OllirParser.FINAL); }
		public TerminalNode FINAL(int i) {
			return getToken(OllirParser.FINAL, i);
		}
		public List<TerminalNode> STATIC() { return getTokens(OllirParser.STATIC); }
		public TerminalNode STATIC(int i) {
			return getToken(OllirParser.STATIC, i);
		}
		public List<TerminalNode> VARARGS() { return getTokens(OllirParser.VARARGS); }
		public TerminalNode VARARGS(int i) {
			return getToken(OllirParser.VARARGS, i);
		}
		public List<TerminalNode> PUBLIC() { return getTokens(OllirParser.PUBLIC); }
		public TerminalNode PUBLIC(int i) {
			return getToken(OllirParser.PUBLIC, i);
		}
		public List<TerminalNode> PRIVATE() { return getTokens(OllirParser.PRIVATE); }
		public TerminalNode PRIVATE(int i) {
			return getToken(OllirParser.PRIVATE, i);
		}
		public List<TerminalNode> PROTECTED() { return getTokens(OllirParser.PROTECTED); }
		public TerminalNode PROTECTED(int i) {
			return getToken(OllirParser.PROTECTED, i);
		}
		public ModifiersContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_modifiers; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterModifiers(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitModifiers(this);
		}
	}

	public final ModifiersContext modifiers() throws RecognitionException {
		ModifiersContext _localctx = new ModifiersContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_modifiers);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(400);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << FINAL) | (1L << PRIVATE) | (1L << PROTECTED) | (1L << PUBLIC) | (1L << STATIC) | (1L << VARARGS))) != 0)) {
				{
				setState(398);
				switch (_input.LA(1)) {
				case PUBLIC:
					{
					setState(389);
					((ModifiersContext)_localctx).visibility = match(PUBLIC);
					}
					break;
				case PRIVATE:
					{
					setState(390);
					((ModifiersContext)_localctx).visibility = match(PRIVATE);
					}
					break;
				case PROTECTED:
					{
					setState(391);
					((ModifiersContext)_localctx).visibility = match(PROTECTED);
					}
					break;
				case FINAL:
					{
					setState(392);
					match(FINAL);
					((ModifiersContext)_localctx).isFinal = true;
					}
					break;
				case STATIC:
					{
					setState(394);
					match(STATIC);
					((ModifiersContext)_localctx).isStatic = true;
					}
					break;
				case VARARGS:
					{
					setState(396);
					match(VARARGS);
					((ModifiersContext)_localctx).isVarArgs = true;
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(402);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public Type ollirType;
		public int dims =  0;
		public boolean isArray = false;
		public BuiltinKind primitive;
		public IdContext name;
		public List<TerminalNode> DOT() { return getTokens(OllirParser.DOT); }
		public TerminalNode DOT(int i) {
			return getToken(OllirParser.DOT, i);
		}
		public List<TerminalNode> ARRAY() { return getTokens(OllirParser.ARRAY); }
		public TerminalNode ARRAY(int i) {
			return getToken(OllirParser.ARRAY, i);
		}
		public TerminalNode I32() { return getToken(OllirParser.I32, 0); }
		public TerminalNode BOOLEAN() { return getToken(OllirParser.BOOLEAN, 0); }
		public TerminalNode VOID() { return getToken(OllirParser.VOID, 0); }
		public IdContext id() {
			return getRuleContext(IdContext.class,0);
		}
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).enterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof OllirListener ) ((OllirListener)listener).exitType(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_type);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(414);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				{
				setState(403);
				match(DOT);
				setState(404);
				match(ARRAY);
				_localctx.dims++; ((TypeContext)_localctx).isArray = true;
				setState(411);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(406);
						match(DOT);
						setState(407);
						match(ARRAY);
						_localctx.dims++;
						}
						} 
					}
					setState(413);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,40,_ctx);
				}
				}
				break;
			}
			{
			setState(416);
			match(DOT);
			setState(424);
			switch (_input.LA(1)) {
			case I32:
				{
				setState(417);
				match(I32);
				((TypeContext)_localctx).primitive = BuiltinKind.INT32;
				}
				break;
			case BOOLEAN:
				{
				setState(419);
				match(BOOLEAN);
				((TypeContext)_localctx).primitive = BuiltinKind.BOOLEAN;
				}
				break;
			case VOID:
				{
				setState(421);
				match(VOID);
				((TypeContext)_localctx).primitive = BuiltinKind.VOID;
				}
				break;
			case IDENTIFIER:
			case STRING_LITERAL:
				{
				setState(423);
				((TypeContext)_localctx).name = id();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3K\u01ad\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\3\2\3\2\7\2=\n\2\f\2\16\2@\13"+
		"\2\3\2\3\2\3\2\3\3\3\3\3\3\7\3H\n\3\f\3\16\3K\13\3\3\3\3\3\3\4\3\4\3\4"+
		"\5\4R\n\4\3\4\3\4\6\4V\n\4\r\4\16\4W\3\4\3\4\3\5\3\5\3\5\5\5_\n\5\3\6"+
		"\3\6\3\6\3\6\5\6e\n\6\3\6\3\6\7\6i\n\6\f\6\16\6l\13\6\3\6\7\6o\n\6\f\6"+
		"\16\6r\13\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\5\7{\n\7\3\7\3\7\3\b\3\b\5\b\u0081"+
		"\n\b\3\b\3\b\3\t\3\t\3\t\5\t\u0088\n\t\3\t\3\t\5\t\u008c\n\t\3\t\3\t\3"+
		"\t\3\t\3\t\3\t\3\t\3\t\3\n\3\n\3\n\7\n\u0099\n\n\f\n\16\n\u009c\13\n\5"+
		"\n\u009e\n\n\3\13\3\13\3\13\3\f\7\f\u00a4\n\f\f\f\16\f\u00a7\13\f\3\r"+
		"\7\r\u00aa\n\r\f\r\16\r\u00ad\13\r\3\r\3\r\3\16\3\16\3\16\3\17\3\17\3"+
		"\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3"+
		"\17\3\17\3\17\5\17\u00c7\n\17\3\17\5\17\u00ca\n\17\3\17\3\17\3\17\3\17"+
		"\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17"+
		"\3\17\3\17\3\17\5\17\u00e1\n\17\3\17\3\17\5\17\u00e5\n\17\3\20\3\20\3"+
		"\20\3\20\5\20\u00eb\n\20\3\20\3\20\7\20\u00ef\n\20\f\20\16\20\u00f2\13"+
		"\20\3\20\3\20\5\20\u00f6\n\20\3\20\3\20\3\21\3\21\3\21\3\21\3\21\3\21"+
		"\3\21\7\21\u0101\n\21\f\21\16\21\u0104\13\21\3\21\3\21\3\21\3\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\7\21\u0110\n\21\f\21\16\21\u0113\13\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\5\21\u011e\n\21\3\21\3\21\7\21"+
		"\u0122\n\21\f\21\16\21\u0125\13\21\3\21\3\21\3\21\5\21\u012a\n\21\3\22"+
		"\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22"+
		"\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22"+
		"\3\22\3\22\3\22\5\22\u014c\n\22\3\23\3\23\3\23\5\23\u0151\n\23\3\23\3"+
		"\23\3\23\5\23\u0156\n\23\3\24\3\24\3\24\3\24\6\24\u015c\n\24\r\24\16\24"+
		"\u015d\3\25\3\25\5\25\u0162\n\25\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3"+
		"\27\3\27\5\27\u016d\n\27\3\30\3\30\3\30\3\30\3\30\5\30\u0174\n\30\3\30"+
		"\5\30\u0177\n\30\3\31\3\31\3\31\5\31\u017c\n\31\3\31\3\31\3\31\3\31\5"+
		"\31\u0182\n\31\3\32\3\32\3\33\3\33\3\34\3\34\3\34\3\34\3\34\3\34\3\34"+
		"\3\34\3\34\7\34\u0191\n\34\f\34\16\34\u0194\13\34\3\35\3\35\3\35\3\35"+
		"\3\35\3\35\7\35\u019c\n\35\f\35\16\35\u019f\13\35\5\35\u01a1\n\35\3\35"+
		"\3\35\3\35\3\35\3\35\3\35\3\35\3\35\5\35\u01ab\n\35\3\35\2\2\36\2\4\6"+
		"\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668\2\7\3\2$&\3\2"+
		"=>\5\2\63\63\65:<H\3\2;<\4\2\'\'))\u01d0\2:\3\2\2\2\4D\3\2\2\2\6N\3\2"+
		"\2\2\b^\3\2\2\2\n`\3\2\2\2\fu\3\2\2\2\16~\3\2\2\2\20\u0087\3\2\2\2\22"+
		"\u009d\3\2\2\2\24\u009f\3\2\2\2\26\u00a5\3\2\2\2\30\u00ab\3\2\2\2\32\u00b0"+
		"\3\2\2\2\34\u00e4\3\2\2\2\36\u00e6\3\2\2\2 \u0129\3\2\2\2\"\u014b\3\2"+
		"\2\2$\u0155\3\2\2\2&\u015b\3\2\2\2(\u0161\3\2\2\2*\u0163\3\2\2\2,\u016c"+
		"\3\2\2\2.\u0176\3\2\2\2\60\u0181\3\2\2\2\62\u0183\3\2\2\2\64\u0185\3\2"+
		"\2\2\66\u0192\3\2\2\28\u01a0\3\2\2\2:>\5\4\3\2;=\5\6\4\2<;\3\2\2\2=@\3"+
		"\2\2\2><\3\2\2\2>?\3\2\2\2?A\3\2\2\2@>\3\2\2\2AB\5\n\6\2BC\7\2\2\3C\3"+
		"\3\2\2\2DE\7\17\2\2EI\5\64\33\2FH\5\b\5\2GF\3\2\2\2HK\3\2\2\2IG\3\2\2"+
		"\2IJ\3\2\2\2JL\3\2\2\2KI\3\2\2\2LM\7\60\2\2M\5\3\2\2\2NQ\7\f\2\2OP\7\24"+
		"\2\2PR\b\4\1\2QO\3\2\2\2QR\3\2\2\2RS\3\2\2\2SU\5\64\33\2TV\5\b\5\2UT\3"+
		"\2\2\2VW\3\2\2\2WU\3\2\2\2WX\3\2\2\2XY\3\2\2\2YZ\7\60\2\2Z\7\3\2\2\2["+
		"\\\7\3\2\2\\_\5\64\33\2]_\t\2\2\2^[\3\2\2\2^]\3\2\2\2_\t\3\2\2\2`a\5\66"+
		"\34\2ad\5\62\32\2bc\7\"\2\2ce\5\64\33\2db\3\2\2\2de\3\2\2\2ef\3\2\2\2"+
		"fj\7,\2\2gi\5\f\7\2hg\3\2\2\2il\3\2\2\2jh\3\2\2\2jk\3\2\2\2kp\3\2\2\2"+
		"lj\3\2\2\2mo\5\20\t\2nm\3\2\2\2or\3\2\2\2pn\3\2\2\2pq\3\2\2\2qs\3\2\2"+
		"\2rp\3\2\2\2st\7-\2\2t\13\3\2\2\2uv\7!\2\2vw\5\66\34\2wx\5\64\33\2xz\5"+
		"8\35\2y{\5\16\b\2zy\3\2\2\2z{\3\2\2\2{|\3\2\2\2|}\7\60\2\2}\r\3\2\2\2"+
		"~\u0080\7\62\2\2\177\u0081\t\3\2\2\u0080\177\3\2\2\2\u0080\u0081\3\2\2"+
		"\2\u0081\u0082\3\2\2\2\u0082\u0083\7(\2\2\u0083\17\3\2\2\2\u0084\u0088"+
		"\7\37\2\2\u0085\u0086\7 \2\2\u0086\u0088\b\t\1\2\u0087\u0084\3\2\2\2\u0087"+
		"\u0085\3\2\2\2\u0088\u0089\3\2\2\2\u0089\u008b\5\66\34\2\u008a\u008c\5"+
		"\64\33\2\u008b\u008a\3\2\2\2\u008b\u008c\3\2\2\2\u008c\u008d\3\2\2\2\u008d"+
		"\u008e\7*\2\2\u008e\u008f\5\22\n\2\u008f\u0090\7+\2\2\u0090\u0091\58\35"+
		"\2\u0091\u0092\7,\2\2\u0092\u0093\5\26\f\2\u0093\u0094\7-\2\2\u0094\21"+
		"\3\2\2\2\u0095\u009a\5\24\13\2\u0096\u0097\7\61\2\2\u0097\u0099\5\24\13"+
		"\2\u0098\u0096\3\2\2\2\u0099\u009c\3\2\2\2\u009a\u0098\3\2\2\2\u009a\u009b"+
		"\3\2\2\2\u009b\u009e\3\2\2\2\u009c\u009a\3\2\2\2\u009d\u0095\3\2\2\2\u009d"+
		"\u009e\3\2\2\2\u009e\23\3\2\2\2\u009f\u00a0\5\64\33\2\u00a0\u00a1\58\35"+
		"\2\u00a1\25\3\2\2\2\u00a2\u00a4\5\30\r\2\u00a3\u00a2\3\2\2\2\u00a4\u00a7"+
		"\3\2\2\2\u00a5\u00a3\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\27\3\2\2\2\u00a7"+
		"\u00a5\3\2\2\2\u00a8\u00aa\5\32\16\2\u00a9\u00a8\3\2\2\2\u00aa\u00ad\3"+
		"\2\2\2\u00ab\u00a9\3\2\2\2\u00ab\u00ac\3\2\2\2\u00ac\u00ae\3\2\2\2\u00ad"+
		"\u00ab\3\2\2\2\u00ae\u00af\5\34\17\2\u00af\31\3\2\2\2\u00b0\u00b1\5\64"+
		"\33\2\u00b1\u00b2\7\64\2\2\u00b2\33\3\2\2\2\u00b3\u00b4\5\36\20\2\u00b4"+
		"\u00b5\7\60\2\2\u00b5\u00e5\3\2\2\2\u00b6\u00b7\5 \21\2\u00b7\u00b8\7"+
		"\60\2\2\u00b8\u00e5\3\2\2\2\u00b9\u00ba\7\34\2\2\u00ba\u00bb\7*\2\2\u00bb"+
		"\u00bc\5.\30\2\u00bc\u00bd\7\61\2\2\u00bd\u00be\5.\30\2\u00be\u00bf\7"+
		"\61\2\2\u00bf\u00c0\5,\27\2\u00c0\u00c1\7+\2\2\u00c1\u00c2\58\35\2\u00c2"+
		"\u00c3\7\60\2\2\u00c3\u00e5\3\2\2\2\u00c4\u00c9\5\64\33\2\u00c5\u00c7"+
		"\58\35\2\u00c6\u00c5\3\2\2\2\u00c6\u00c7\3\2\2\2\u00c7\u00c8\3\2\2\2\u00c8"+
		"\u00ca\5&\24\2\u00c9\u00c6\3\2\2\2\u00c9\u00ca\3\2\2\2\u00ca\u00cb\3\2"+
		"\2\2\u00cb\u00cc\58\35\2\u00cc\u00cd\7\62\2\2\u00cd\u00ce\58\35\2\u00ce"+
		"\u00cf\5\"\22\2\u00cf\u00d0\7\60\2\2\u00d0\u00e5\3\2\2\2\u00d1\u00d2\7"+
		"\13\2\2\u00d2\u00d3\7*\2\2\u00d3\u00d4\5\"\22\2\u00d4\u00d5\7+\2\2\u00d5"+
		"\u00d6\7\n\2\2\u00d6\u00d7\5\64\33\2\u00d7\u00d8\7\60\2\2\u00d8\u00e5"+
		"\3\2\2\2\u00d9\u00da\7\n\2\2\u00da\u00db\5\64\33\2\u00db\u00dc\7\60\2"+
		"\2\u00dc\u00e5\3\2\2\2\u00dd\u00de\7\23\2\2\u00de\u00e0\58\35\2\u00df"+
		"\u00e1\5$\23\2\u00e0\u00df\3\2\2\2\u00e0\u00e1\3\2\2\2\u00e1\u00e2\3\2"+
		"\2\2\u00e2\u00e3\7\60\2\2\u00e3\u00e5\3\2\2\2\u00e4\u00b3\3\2\2\2\u00e4"+
		"\u00b6\3\2\2\2\u00e4\u00b9\3\2\2\2\u00e4\u00c4\3\2\2\2\u00e4\u00d1\3\2"+
		"\2\2\u00e4\u00d9\3\2\2\2\u00e4\u00dd\3\2\2\2\u00e5\35\3\2\2\2\u00e6\u00f5"+
		"\7\16\2\2\u00e7\u00ea\7*\2\2\u00e8\u00eb\7\b\2\2\u00e9\u00eb\5\64\33\2"+
		"\u00ea\u00e8\3\2\2\2\u00ea\u00e9\3\2\2\2\u00eb\u00f0\3\2\2\2\u00ec\u00ed"+
		"\7\61\2\2\u00ed\u00ef\5,\27\2\u00ee\u00ec\3\2\2\2\u00ef\u00f2\3\2\2\2"+
		"\u00f0\u00ee\3\2\2\2\u00f0\u00f1\3\2\2\2\u00f1\u00f3\3\2\2\2\u00f2\u00f0"+
		"\3\2\2\2\u00f3\u00f4\7+\2\2\u00f4\u00f6\b\20\1\2\u00f5\u00e7\3\2\2\2\u00f5"+
		"\u00f6\3\2\2\2\u00f6\u00f7\3\2\2\2\u00f7\u00f8\58\35\2\u00f8\37\3\2\2"+
		"\2\u00f9\u00fa\7\31\2\2\u00fa\u00fb\7*\2\2\u00fb\u00fc\5\64\33\2\u00fc"+
		"\u00fd\7\61\2\2\u00fd\u0102\7)\2\2\u00fe\u00ff\7\61\2\2\u00ff\u0101\5"+
		",\27\2\u0100\u00fe\3\2\2\2\u0101\u0104\3\2\2\2\u0102\u0100\3\2\2\2\u0102"+
		"\u0103\3\2\2\2\u0103\u0105\3\2\2\2\u0104\u0102\3\2\2\2\u0105\u0106\7+"+
		"\2\2\u0106\u0107\58\35\2\u0107\u012a\3\2\2\2\u0108\u0109\7\30\2\2\u0109"+
		"\u010a\7*\2\2\u010a\u010b\5.\30\2\u010b\u010c\7\61\2\2\u010c\u0111\7)"+
		"\2\2\u010d\u010e\7\61\2\2\u010e\u0110\5,\27\2\u010f\u010d\3\2\2\2\u0110"+
		"\u0113\3\2\2\2\u0111\u010f\3\2\2\2\u0111\u0112\3\2\2\2\u0112\u0114\3\2"+
		"\2\2\u0113\u0111\3\2\2\2\u0114\u0115\7+\2\2\u0115\u0116\58\35\2\u0116"+
		"\u012a\3\2\2\2\u0117\u0118\7\27\2\2\u0118\u0119\7*\2\2\u0119\u011a\5."+
		"\30\2\u011a\u011b\7\61\2\2\u011b\u011d\7)\2\2\u011c\u011e\7)\2\2\u011d"+
		"\u011c\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u0123\3\2\2\2\u011f\u0120\7\61"+
		"\2\2\u0120\u0122\5,\27\2\u0121\u011f\3\2\2\2\u0122\u0125\3\2\2\2\u0123"+
		"\u0121\3\2\2\2\u0123\u0124\3\2\2\2\u0124\u0126\3\2\2\2\u0125\u0123\3\2"+
		"\2\2\u0126\u0127\7+\2\2\u0127\u0128\58\35\2\u0128\u012a\3\2\2\2\u0129"+
		"\u00f9\3\2\2\2\u0129\u0108\3\2\2\2\u0129\u0117\3\2\2\2\u012a!\3\2\2\2"+
		"\u012b\u012c\7\33\2\2\u012c\u012d\7*\2\2\u012d\u012e\5.\30\2\u012e\u012f"+
		"\7\61\2\2\u012f\u0130\5.\30\2\u0130\u0131\7+\2\2\u0131\u0132\58\35\2\u0132"+
		"\u014c\3\2\2\2\u0133\u014c\5\36\20\2\u0134\u014c\5 \21\2\u0135\u0136\7"+
		"\26\2\2\u0136\u0137\7*\2\2\u0137\u0138\5\60\31\2\u0138\u0139\7+\2\2\u0139"+
		"\u013a\58\35\2\u013a\u014c\3\2\2\2\u013b\u013c\7\32\2\2\u013c\u013d\7"+
		"*\2\2\u013d\u013e\5.\30\2\u013e\u013f\7+\2\2\u013f\u0140\58\35\2\u0140"+
		"\u014c\3\2\2\2\u0141\u014c\5$\23\2\u0142\u0143\5$\23\2\u0143\u0144\t\4"+
		"\2\2\u0144\u0145\58\35\2\u0145\u0146\5$\23\2\u0146\u014c\3\2\2\2\u0147"+
		"\u0148\t\5\2\2\u0148\u0149\58\35\2\u0149\u014a\5$\23\2\u014a\u014c\3\2"+
		"\2\2\u014b\u012b\3\2\2\2\u014b\u0133\3\2\2\2\u014b\u0134\3\2\2\2\u014b"+
		"\u0135\3\2\2\2\u014b\u013b\3\2\2\2\u014b\u0141\3\2\2\2\u014b\u0142\3\2"+
		"\2\2\u014b\u0147\3\2\2\2\u014c#\3\2\2\2\u014d\u0156\5,\27\2\u014e\u0150"+
		"\5\64\33\2\u014f\u0151\58\35\2\u0150\u014f\3\2\2\2\u0150\u0151\3\2\2\2"+
		"\u0151\u0152\3\2\2\2\u0152\u0153\5&\24\2\u0153\u0154\58\35\2\u0154\u0156"+
		"\3\2\2\2\u0155\u014d\3\2\2\2\u0155\u014e\3\2\2\2\u0156%\3\2\2\2\u0157"+
		"\u0158\7.\2\2\u0158\u0159\5(\25\2\u0159\u015a\7/\2\2\u015a\u015c\3\2\2"+
		"\2\u015b\u0157\3\2\2\2\u015c\u015d\3\2\2\2\u015d\u015b\3\2\2\2\u015d\u015e"+
		"\3\2\2\2\u015e\'\3\2\2\2\u015f\u0162\5*\26\2\u0160\u0162\5\60\31\2\u0161"+
		"\u015f\3\2\2\2\u0161\u0160\3\2\2\2\u0162)\3\2\2\2\u0163\u0164\5\64\33"+
		"\2\u0164\u0165\58\35\2\u0165+\3\2\2\2\u0166\u0167\5\64\33\2\u0167\u0168"+
		"\58\35\2\u0168\u016d\3\2\2\2\u0169\u016a\7\25\2\2\u016a\u016d\58\35\2"+
		"\u016b\u016d\5\60\31\2\u016c\u0166\3\2\2\2\u016c\u0169\3\2\2\2\u016c\u016b"+
		"\3\2\2\2\u016d-\3\2\2\2\u016e\u016f\5\64\33\2\u016f\u0170\58\35\2\u0170"+
		"\u0177\3\2\2\2\u0171\u0173\7\25\2\2\u0172\u0174\58\35\2\u0173\u0172\3"+
		"\2\2\2\u0173\u0174\3\2\2\2\u0174\u0177\3\2\2\2\u0175\u0177\7\b\2\2\u0176"+
		"\u016e\3\2\2\2\u0176\u0171\3\2\2\2\u0176\u0175\3\2\2\2\u0177/\3\2\2\2"+
		"\u0178\u017c\7=\2\2\u0179\u017a\7>\2\2\u017a\u017c\b\31\1\2\u017b\u0178"+
		"\3\2\2\2\u017b\u0179\3\2\2\2\u017b\u017c\3\2\2\2\u017c\u017d\3\2\2\2\u017d"+
		"\u017e\7(\2\2\u017e\u0182\58\35\2\u017f\u0180\7)\2\2\u0180\u0182\58\35"+
		"\2\u0181\u017b\3\2\2\2\u0181\u017f\3\2\2\2\u0182\61\3\2\2\2\u0183\u0184"+
		"\5\64\33\2\u0184\63\3\2\2\2\u0185\u0186\t\6\2\2\u0186\65\3\2\2\2\u0187"+
		"\u0191\7\22\2\2\u0188\u0191\7\20\2\2\u0189\u0191\7\21\2\2\u018a\u018b"+
		"\7\t\2\2\u018b\u0191\b\34\1\2\u018c\u018d\7\24\2\2\u018d\u0191\b\34\1"+
		"\2\u018e\u018f\7#\2\2\u018f\u0191\b\34\1\2\u0190\u0187\3\2\2\2\u0190\u0188"+
		"\3\2\2\2\u0190\u0189\3\2\2\2\u0190\u018a\3\2\2\2\u0190\u018c\3\2\2\2\u0190"+
		"\u018e\3\2\2\2\u0191\u0194\3\2\2\2\u0192\u0190\3\2\2\2\u0192\u0193\3\2"+
		"\2\2\u0193\67\3\2\2\2\u0194\u0192\3\2\2\2\u0195\u0196\7\3\2\2\u0196\u0197"+
		"\7\b\2\2\u0197\u019d\b\35\1\2\u0198\u0199\7\3\2\2\u0199\u019a\7\b\2\2"+
		"\u019a\u019c\b\35\1\2\u019b\u0198\3\2\2\2\u019c\u019f\3\2\2\2\u019d\u019b"+
		"\3\2\2\2\u019d\u019e\3\2\2\2\u019e\u01a1\3\2\2\2\u019f\u019d\3\2\2\2\u01a0"+
		"\u0195\3\2\2\2\u01a0\u01a1\3\2\2\2\u01a1\u01a2\3\2\2\2\u01a2\u01aa\7\3"+
		"\2\2\u01a3\u01a4\7\5\2\2\u01a4\u01ab\b\35\1\2\u01a5\u01a6\7\6\2\2\u01a6"+
		"\u01ab\b\35\1\2\u01a7\u01a8\7\7\2\2\u01a8\u01ab\b\35\1\2\u01a9\u01ab\5"+
		"\64\33\2\u01aa\u01a3\3\2\2\2\u01aa\u01a5\3\2\2\2\u01aa\u01a7\3\2\2\2\u01aa"+
		"\u01a9\3\2\2\2\u01ab9\3\2\2\2->IQW^djpz\u0080\u0087\u008b\u009a\u009d"+
		"\u00a5\u00ab\u00c6\u00c9\u00e0\u00e4\u00ea\u00f0\u00f5\u0102\u0111\u011d"+
		"\u0123\u0129\u014b\u0150\u0155\u015d\u0161\u016c\u0173\u0176\u017b\u0181"+
		"\u0190\u0192\u019d\u01a0\u01aa";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}