// Generated from org\specs\comp\ollir\Ollir.g4 by ANTLR 4.5.3

    package org.specs.comp.ollir;
    import org.specs.comp.ollir.type.BuiltinKind;
    import org.specs.comp.ollir.inst.Instruction;
    import org.specs.comp.ollir.Element;
    import org.specs.comp.ollir.Operand;
    import org.specs.comp.ollir.type.Type;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link OllirParser}.
 */
public interface OllirListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link OllirParser#classUnit}.
	 * @param ctx the parse tree
	 */
	void enterClassUnit(OllirParser.ClassUnitContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#classUnit}.
	 * @param ctx the parse tree
	 */
	void exitClassUnit(OllirParser.ClassUnitContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#packageDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterPackageDeclaration(OllirParser.PackageDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#packageDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitPackageDeclaration(OllirParser.PackageDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#importDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterImportDeclaration(OllirParser.ImportDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#importDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitImportDeclaration(OllirParser.ImportDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#packagePath}.
	 * @param ctx the parse tree
	 */
	void enterPackagePath(OllirParser.PackagePathContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#packagePath}.
	 * @param ctx the parse tree
	 */
	void exitPackagePath(OllirParser.PackagePathContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#classDeclaration}.
	 * @param ctx the parse tree
	 */
	void enterClassDeclaration(OllirParser.ClassDeclarationContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#classDeclaration}.
	 * @param ctx the parse tree
	 */
	void exitClassDeclaration(OllirParser.ClassDeclarationContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#field}.
	 * @param ctx the parse tree
	 */
	void enterField(OllirParser.FieldContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#field}.
	 * @param ctx the parse tree
	 */
	void exitField(OllirParser.FieldContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#initializer}.
	 * @param ctx the parse tree
	 */
	void enterInitializer(OllirParser.InitializerContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#initializer}.
	 * @param ctx the parse tree
	 */
	void exitInitializer(OllirParser.InitializerContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#method}.
	 * @param ctx the parse tree
	 */
	void enterMethod(OllirParser.MethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#method}.
	 * @param ctx the parse tree
	 */
	void exitMethod(OllirParser.MethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#params}.
	 * @param ctx the parse tree
	 */
	void enterParams(OllirParser.ParamsContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#params}.
	 * @param ctx the parse tree
	 */
	void exitParams(OllirParser.ParamsContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#param}.
	 * @param ctx the parse tree
	 */
	void enterParam(OllirParser.ParamContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#param}.
	 * @param ctx the parse tree
	 */
	void exitParam(OllirParser.ParamContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#instructions}.
	 * @param ctx the parse tree
	 */
	void enterInstructions(OllirParser.InstructionsContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#instructions}.
	 * @param ctx the parse tree
	 */
	void exitInstructions(OllirParser.InstructionsContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#labelledInstruction}.
	 * @param ctx the parse tree
	 */
	void enterLabelledInstruction(OllirParser.LabelledInstructionContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#labelledInstruction}.
	 * @param ctx the parse tree
	 */
	void exitLabelledInstruction(OllirParser.LabelledInstructionContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#label}.
	 * @param ctx the parse tree
	 */
	void enterLabel(OllirParser.LabelContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#label}.
	 * @param ctx the parse tree
	 */
	void exitLabel(OllirParser.LabelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NewInstr}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterNewInstr(OllirParser.NewInstrContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NewInstr}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitNewInstr(OllirParser.NewInstrContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InvokeInstr}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterInvokeInstr(OllirParser.InvokeInstrContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InvokeInstr}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitInvokeInstr(OllirParser.InvokeInstrContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PutField}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterPutField(OllirParser.PutFieldContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PutField}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitPutField(OllirParser.PutFieldContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Assignment}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(OllirParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Assignment}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(OllirParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by the {@code If}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterIf(OllirParser.IfContext ctx);
	/**
	 * Exit a parse tree produced by the {@code If}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitIf(OllirParser.IfContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Goto}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterGoto(OllirParser.GotoContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Goto}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitGoto(OllirParser.GotoContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Return}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void enterReturn(OllirParser.ReturnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Return}
	 * labeled alternative in {@link OllirParser#instruction}.
	 * @param ctx the parse tree
	 */
	void exitReturn(OllirParser.ReturnContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#newExpression}.
	 * @param ctx the parse tree
	 */
	void enterNewExpression(OllirParser.NewExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#newExpression}.
	 * @param ctx the parse tree
	 */
	void exitNewExpression(OllirParser.NewExpressionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InvokeStatic}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void enterInvokeStatic(OllirParser.InvokeStaticContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InvokeStatic}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void exitInvokeStatic(OllirParser.InvokeStaticContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InvokeVirtual}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void enterInvokeVirtual(OllirParser.InvokeVirtualContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InvokeVirtual}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void exitInvokeVirtual(OllirParser.InvokeVirtualContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InvokeSpecial}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void enterInvokeSpecial(OllirParser.InvokeSpecialContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InvokeSpecial}
	 * labeled alternative in {@link OllirParser#invokeExpression}.
	 * @param ctx the parse tree
	 */
	void exitInvokeSpecial(OllirParser.InvokeSpecialContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GetFieldExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterGetFieldExpr(OllirParser.GetFieldExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GetFieldExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitGetFieldExpr(OllirParser.GetFieldExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NewExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterNewExpr(OllirParser.NewExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NewExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitNewExpr(OllirParser.NewExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InvokeExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterInvokeExpr(OllirParser.InvokeExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InvokeExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitInvokeExpr(OllirParser.InvokeExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LdcExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterLdcExpr(OllirParser.LdcExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LdcExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitLdcExpr(OllirParser.LdcExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayLengthExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterArrayLengthExpr(OllirParser.ArrayLengthExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayLengthExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitArrayLengthExpr(OllirParser.ArrayLengthExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SingleOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterSingleOpExpr(OllirParser.SingleOpExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SingleOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitSingleOpExpr(OllirParser.SingleOpExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterBinaryOpExpr(OllirParser.BinaryOpExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitBinaryOpExpr(OllirParser.BinaryOpExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterUnaryOpExpr(OllirParser.UnaryOpExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryOpExpr}
	 * labeled alternative in {@link OllirParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitUnaryOpExpr(OllirParser.UnaryOpExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ScalarOperand}
	 * labeled alternative in {@link OllirParser#operand}.
	 * @param ctx the parse tree
	 */
	void enterScalarOperand(OllirParser.ScalarOperandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ScalarOperand}
	 * labeled alternative in {@link OllirParser#operand}.
	 * @param ctx the parse tree
	 */
	void exitScalarOperand(OllirParser.ScalarOperandContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayAccessOperand}
	 * labeled alternative in {@link OllirParser#operand}.
	 * @param ctx the parse tree
	 */
	void enterArrayAccessOperand(OllirParser.ArrayAccessOperandContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayAccessOperand}
	 * labeled alternative in {@link OllirParser#operand}.
	 * @param ctx the parse tree
	 */
	void exitArrayAccessOperand(OllirParser.ArrayAccessOperandContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#arrayIndices}.
	 * @param ctx the parse tree
	 */
	void enterArrayIndices(OllirParser.ArrayIndicesContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#arrayIndices}.
	 * @param ctx the parse tree
	 */
	void exitArrayIndices(OllirParser.ArrayIndicesContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#arrayIndex}.
	 * @param ctx the parse tree
	 */
	void enterArrayIndex(OllirParser.ArrayIndexContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#arrayIndex}.
	 * @param ctx the parse tree
	 */
	void exitArrayIndex(OllirParser.ArrayIndexContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#var}.
	 * @param ctx the parse tree
	 */
	void enterVar(OllirParser.VarContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#var}.
	 * @param ctx the parse tree
	 */
	void exitVar(OllirParser.VarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IdArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void enterIdArg(OllirParser.IdArgContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IdArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void exitIdArg(OllirParser.IdArgContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ThisArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void enterThisArg(OllirParser.ThisArgContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ThisArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void exitThisArg(OllirParser.ThisArgContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LiteralArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void enterLiteralArg(OllirParser.LiteralArgContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LiteralArg}
	 * labeled alternative in {@link OllirParser#arg}.
	 * @param ctx the parse tree
	 */
	void exitLiteralArg(OllirParser.LiteralArgContext ctx);
	/**
	 * Enter a parse tree produced by the {@code InstRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void enterInstRef(OllirParser.InstRefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code InstRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void exitInstRef(OllirParser.InstRefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ThisClassRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void enterThisClassRef(OllirParser.ThisClassRefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ThisClassRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void exitThisClassRef(OllirParser.ThisClassRefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void enterArrayRef(OllirParser.ArrayRefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayRef}
	 * labeled alternative in {@link OllirParser#objectRef}.
	 * @param ctx the parse tree
	 */
	void exitArrayRef(OllirParser.ArrayRefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IntegerLiteral}
	 * labeled alternative in {@link OllirParser#literal}.
	 * @param ctx the parse tree
	 */
	void enterIntegerLiteral(OllirParser.IntegerLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IntegerLiteral}
	 * labeled alternative in {@link OllirParser#literal}.
	 * @param ctx the parse tree
	 */
	void exitIntegerLiteral(OllirParser.IntegerLiteralContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StringLiteral}
	 * labeled alternative in {@link OllirParser#literal}.
	 * @param ctx the parse tree
	 */
	void enterStringLiteral(OllirParser.StringLiteralContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StringLiteral}
	 * labeled alternative in {@link OllirParser#literal}.
	 * @param ctx the parse tree
	 */
	void exitStringLiteral(OllirParser.StringLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#className}.
	 * @param ctx the parse tree
	 */
	void enterClassName(OllirParser.ClassNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#className}.
	 * @param ctx the parse tree
	 */
	void exitClassName(OllirParser.ClassNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#id}.
	 * @param ctx the parse tree
	 */
	void enterId(OllirParser.IdContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#id}.
	 * @param ctx the parse tree
	 */
	void exitId(OllirParser.IdContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#modifiers}.
	 * @param ctx the parse tree
	 */
	void enterModifiers(OllirParser.ModifiersContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#modifiers}.
	 * @param ctx the parse tree
	 */
	void exitModifiers(OllirParser.ModifiersContext ctx);
	/**
	 * Enter a parse tree produced by {@link OllirParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(OllirParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link OllirParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(OllirParser.TypeContext ctx);
}