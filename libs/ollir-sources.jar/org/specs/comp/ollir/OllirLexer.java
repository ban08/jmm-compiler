// Generated from org\specs\comp\ollir\Ollir.g4 by ANTLR 4.5.3

    package org.specs.comp.ollir;
    import org.specs.comp.ollir.type.BuiltinKind;
    import org.specs.comp.ollir.inst.Instruction;
    import org.specs.comp.ollir.Element;
    import org.specs.comp.ollir.Operand;
    import org.specs.comp.ollir.type.Type;

import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class OllirLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.5.3", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		CLASS=1, I32=2, BOOLEAN=3, VOID=4, ARRAY=5, FINAL=6, GOTO=7, IF=8, IMPORT=9, 
		INTERFACE=10, NEW=11, PACKAGE=12, PRIVATE=13, PROTECTED=14, PUBLIC=15, 
		RETURN=16, STATIC=17, THIS=18, LDC=19, INVOKESPECIAL=20, INVOKEVIRTUAL=21, 
		INVOKESTATIC=22, ARRAYLENGTH=23, GETFIELD=24, PUTFIELD=25, GETSTATIC=26, 
		PUTSTATIC=27, METHOD=28, CONSTRUCT=29, FIELD=30, EXTENDS=31, VARARGS=32, 
		IDENTIFIER=33, INTEGER_LITERAL=34, STRING_LITERAL=35, LPAREN=36, RPAREN=37, 
		LBRACE=38, RBRACE=39, LBRACKET=40, RBRACKET=41, SEMICOLON=42, COMMA=43, 
		DOT=44, ASSIGN=45, LT=46, COLON=47, EQ=48, LE=49, GE=50, NE=51, SC_OR=52, 
		SC_AND=53, SC_NOT=54, BIT_NOT=55, PLUS=56, MINUS=57, MUL=58, DIV=59, BIT_AND=60, 
		BIT_OR=61, BIT_XOR=62, REM=63, GT=64, LSHIFT=65, RSHIFT=66, RRSHIFT=67, 
		WS=68, SINGLE_COMMENT=69, BLOCK_COMMENT=70;
	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	public static final String[] ruleNames = {
		"CLASS", "I32", "BOOLEAN", "VOID", "ARRAY", "FINAL", "GOTO", "IF", "IMPORT", 
		"INTERFACE", "NEW", "PACKAGE", "PRIVATE", "PROTECTED", "PUBLIC", "RETURN", 
		"STATIC", "THIS", "LDC", "INVOKESPECIAL", "INVOKEVIRTUAL", "INVOKESTATIC", 
		"ARRAYLENGTH", "GETFIELD", "PUTFIELD", "GETSTATIC", "PUTSTATIC", "METHOD", 
		"CONSTRUCT", "FIELD", "EXTENDS", "VARARGS", "IDENTIFIER", "INTEGER_LITERAL", 
		"STRING_LITERAL", "StringCharacters", "StringCharacter", "EscapeSequence", 
		"OctalEscape", "UnicodeEscape", "OctalDigit", "ZeroToThree", "HexDigit", 
		"LPAREN", "RPAREN", "LBRACE", "RBRACE", "LBRACKET", "RBRACKET", "SEMICOLON", 
		"COMMA", "DOT", "ASSIGN", "LT", "COLON", "EQ", "LE", "GE", "NE", "SC_OR", 
		"SC_AND", "SC_NOT", "BIT_NOT", "PLUS", "MINUS", "MUL", "DIV", "BIT_AND", 
		"BIT_OR", "BIT_XOR", "REM", "GT", "LSHIFT", "RSHIFT", "RRSHIFT", "WS", 
		"SINGLE_COMMENT", "BLOCK_COMMENT"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'class'", "'i32'", "'bool'", "'V'", "'array'", "'final'", "'goto'", 
		"'if'", "'import'", "'interface'", "'new'", "'package'", "'private'", 
		"'protected'", "'public'", "'ret'", "'static'", "'this'", "'ldc'", "'invokespecial'", 
		"'invokevirtual'", "'invokestatic'", "'arraylength'", "'getfield'", "'putfield'", 
		"'getstatic'", "'putstatic'", "'.method'", "'.construct'", "'.field'", 
		"'extends'", "'varargs'", null, null, null, "'('", "')'", "'{'", "'}'", 
		"'['", "']'", "';'", "','", "'.'", "':='", "'<'", "':'", "'=='", "'<='", 
		"'>='", "'!='", "'||'", "'&&'", "'!'", "'~'", "'+'", "'-'", "'*'", "'/'", 
		"'&'", "'|'", "'^'", "'%'", "'>'", "'<<'", "'>>'", "'>>>'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "CLASS", "I32", "BOOLEAN", "VOID", "ARRAY", "FINAL", "GOTO", "IF", 
		"IMPORT", "INTERFACE", "NEW", "PACKAGE", "PRIVATE", "PROTECTED", "PUBLIC", 
		"RETURN", "STATIC", "THIS", "LDC", "INVOKESPECIAL", "INVOKEVIRTUAL", "INVOKESTATIC", 
		"ARRAYLENGTH", "GETFIELD", "PUTFIELD", "GETSTATIC", "PUTSTATIC", "METHOD", 
		"CONSTRUCT", "FIELD", "EXTENDS", "VARARGS", "IDENTIFIER", "INTEGER_LITERAL", 
		"STRING_LITERAL", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "LBRACKET", 
		"RBRACKET", "SEMICOLON", "COMMA", "DOT", "ASSIGN", "LT", "COLON", "EQ", 
		"LE", "GE", "NE", "SC_OR", "SC_AND", "SC_NOT", "BIT_NOT", "PLUS", "MINUS", 
		"MUL", "DIV", "BIT_AND", "BIT_OR", "BIT_XOR", "REM", "GT", "LSHIFT", "RSHIFT", 
		"RRSHIFT", "WS", "SINGLE_COMMENT", "BLOCK_COMMENT"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public OllirLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "Ollir.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\2H\u0242\b\1\4\2\t"+
		"\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \4!"+
		"\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4"+
		",\t,\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\4\64\t"+
		"\64\4\65\t\65\4\66\t\66\4\67\t\67\48\t8\49\t9\4:\t:\4;\t;\4<\t<\4=\t="+
		"\4>\t>\4?\t?\4@\t@\4A\tA\4B\tB\4C\tC\4D\tD\4E\tE\4F\tF\4G\tG\4H\tH\4I"+
		"\tI\4J\tJ\4K\tK\4L\tL\4M\tM\4N\tN\4O\tO\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3"+
		"\3\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\5\3\5\3\6\3\6\3\6\3\6\3\6\3\6\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3"+
		"\n\3\n\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\f\3\f\3\f\3"+
		"\f\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\16\3\16\3\16"+
		"\3\16\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\21\3\21\3\21\3\21\3\22\3\22\3\22\3\22\3\22\3\22"+
		"\3\22\3\23\3\23\3\23\3\23\3\23\3\24\3\24\3\24\3\24\3\25\3\25\3\25\3\25"+
		"\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\26\3\26\3\26\3\26"+
		"\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27"+
		"\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\27\3\30\3\30\3\30\3\30\3\30"+
		"\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\31\3\31\3\31\3\31\3\31\3\31\3\31"+
		"\3\31\3\31\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\32\3\33\3\33\3\33"+
		"\3\33\3\33\3\33\3\33\3\33\3\33\3\33\3\34\3\34\3\34\3\34\3\34\3\34\3\34"+
		"\3\34\3\34\3\34\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\35\3\36\3\36\3\36"+
		"\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\36\3\37\3\37\3\37\3\37\3\37\3\37"+
		"\3\37\3 \3 \3 \3 \3 \3 \3 \3 \3!\3!\3!\3!\3!\3!\3!\3!\3\"\3\"\7\"\u0196"+
		"\n\"\f\"\16\"\u0199\13\"\3#\3#\3#\7#\u019e\n#\f#\16#\u01a1\13#\5#\u01a3"+
		"\n#\3$\3$\5$\u01a7\n$\3$\3$\3%\6%\u01ac\n%\r%\16%\u01ad\3&\3&\5&\u01b2"+
		"\n&\3\'\3\'\3\'\3\'\5\'\u01b8\n\'\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\3(\5("+
		"\u01c5\n(\3)\3)\6)\u01c9\n)\r)\16)\u01ca\3)\3)\3)\3)\3)\3*\3*\3+\3+\3"+
		",\3,\3-\3-\3.\3.\3/\3/\3\60\3\60\3\61\3\61\3\62\3\62\3\63\3\63\3\64\3"+
		"\64\3\65\3\65\3\66\3\66\3\66\3\67\3\67\38\38\39\39\39\3:\3:\3:\3;\3;\3"+
		";\3<\3<\3<\3=\3=\3=\3>\3>\3>\3?\3?\3@\3@\3A\3A\3B\3B\3C\3C\3D\3D\3E\3"+
		"E\3F\3F\3G\3G\3H\3H\3I\3I\3J\3J\3J\3K\3K\3K\3L\3L\3L\3L\3M\6M\u0224\n"+
		"M\rM\16M\u0225\3M\3M\3N\3N\3N\3N\7N\u022e\nN\fN\16N\u0231\13N\3N\3N\3"+
		"O\3O\3O\3O\7O\u0239\nO\fO\16O\u023c\13O\3O\3O\3O\3O\3O\3\u023a\2P\3\3"+
		"\5\4\7\5\t\6\13\7\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\35\20\37\21"+
		"!\22#\23%\24\'\25)\26+\27-\30/\31\61\32\63\33\65\34\67\359\36;\37= ?!"+
		"A\"C#E$G%I\2K\2M\2O\2Q\2S\2U\2W\2Y&[\'](_)a*c+e,g-i.k/m\60o\61q\62s\63"+
		"u\64w\65y\66{\67}8\1779\u0081:\u0083;\u0085<\u0087=\u0089>\u008b?\u008d"+
		"@\u008fA\u0091B\u0093C\u0095D\u0097E\u0099F\u009bG\u009dH\3\2\r\6\2&&"+
		"C\\aac|\7\2&&\62;C\\aac|\3\2\63;\3\2\62;\6\2\f\f\17\17$$^^\n\2$$))^^d"+
		"dhhppttvv\3\2\629\3\2\62\65\5\2\62;CHch\5\2\13\f\16\17\"\"\4\2\f\f\17"+
		"\17\u0247\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2"+
		"\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27"+
		"\3\2\2\2\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2"+
		"\2\2#\3\2\2\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2\2-\3\2\2\2"+
		"\2/\3\2\2\2\2\61\3\2\2\2\2\63\3\2\2\2\2\65\3\2\2\2\2\67\3\2\2\2\29\3\2"+
		"\2\2\2;\3\2\2\2\2=\3\2\2\2\2?\3\2\2\2\2A\3\2\2\2\2C\3\2\2\2\2E\3\2\2\2"+
		"\2G\3\2\2\2\2Y\3\2\2\2\2[\3\2\2\2\2]\3\2\2\2\2_\3\2\2\2\2a\3\2\2\2\2c"+
		"\3\2\2\2\2e\3\2\2\2\2g\3\2\2\2\2i\3\2\2\2\2k\3\2\2\2\2m\3\2\2\2\2o\3\2"+
		"\2\2\2q\3\2\2\2\2s\3\2\2\2\2u\3\2\2\2\2w\3\2\2\2\2y\3\2\2\2\2{\3\2\2\2"+
		"\2}\3\2\2\2\2\177\3\2\2\2\2\u0081\3\2\2\2\2\u0083\3\2\2\2\2\u0085\3\2"+
		"\2\2\2\u0087\3\2\2\2\2\u0089\3\2\2\2\2\u008b\3\2\2\2\2\u008d\3\2\2\2\2"+
		"\u008f\3\2\2\2\2\u0091\3\2\2\2\2\u0093\3\2\2\2\2\u0095\3\2\2\2\2\u0097"+
		"\3\2\2\2\2\u0099\3\2\2\2\2\u009b\3\2\2\2\2\u009d\3\2\2\2\3\u009f\3\2\2"+
		"\2\5\u00a5\3\2\2\2\7\u00a9\3\2\2\2\t\u00ae\3\2\2\2\13\u00b0\3\2\2\2\r"+
		"\u00b6\3\2\2\2\17\u00bc\3\2\2\2\21\u00c1\3\2\2\2\23\u00c4\3\2\2\2\25\u00cb"+
		"\3\2\2\2\27\u00d5\3\2\2\2\31\u00d9\3\2\2\2\33\u00e1\3\2\2\2\35\u00e9\3"+
		"\2\2\2\37\u00f3\3\2\2\2!\u00fa\3\2\2\2#\u00fe\3\2\2\2%\u0105\3\2\2\2\'"+
		"\u010a\3\2\2\2)\u010e\3\2\2\2+\u011c\3\2\2\2-\u012a\3\2\2\2/\u0137\3\2"+
		"\2\2\61\u0143\3\2\2\2\63\u014c\3\2\2\2\65\u0155\3\2\2\2\67\u015f\3\2\2"+
		"\29\u0169\3\2\2\2;\u0171\3\2\2\2=\u017c\3\2\2\2?\u0183\3\2\2\2A\u018b"+
		"\3\2\2\2C\u0193\3\2\2\2E\u01a2\3\2\2\2G\u01a4\3\2\2\2I\u01ab\3\2\2\2K"+
		"\u01b1\3\2\2\2M\u01b7\3\2\2\2O\u01c4\3\2\2\2Q\u01c6\3\2\2\2S\u01d1\3\2"+
		"\2\2U\u01d3\3\2\2\2W\u01d5\3\2\2\2Y\u01d7\3\2\2\2[\u01d9\3\2\2\2]\u01db"+
		"\3\2\2\2_\u01dd\3\2\2\2a\u01df\3\2\2\2c\u01e1\3\2\2\2e\u01e3\3\2\2\2g"+
		"\u01e5\3\2\2\2i\u01e7\3\2\2\2k\u01e9\3\2\2\2m\u01ec\3\2\2\2o\u01ee\3\2"+
		"\2\2q\u01f0\3\2\2\2s\u01f3\3\2\2\2u\u01f6\3\2\2\2w\u01f9\3\2\2\2y\u01fc"+
		"\3\2\2\2{\u01ff\3\2\2\2}\u0202\3\2\2\2\177\u0204\3\2\2\2\u0081\u0206\3"+
		"\2\2\2\u0083\u0208\3\2\2\2\u0085\u020a\3\2\2\2\u0087\u020c\3\2\2\2\u0089"+
		"\u020e\3\2\2\2\u008b\u0210\3\2\2\2\u008d\u0212\3\2\2\2\u008f\u0214\3\2"+
		"\2\2\u0091\u0216\3\2\2\2\u0093\u0218\3\2\2\2\u0095\u021b\3\2\2\2\u0097"+
		"\u021e\3\2\2\2\u0099\u0223\3\2\2\2\u009b\u0229\3\2\2\2\u009d\u0234\3\2"+
		"\2\2\u009f\u00a0\7e\2\2\u00a0\u00a1\7n\2\2\u00a1\u00a2\7c\2\2\u00a2\u00a3"+
		"\7u\2\2\u00a3\u00a4\7u\2\2\u00a4\4\3\2\2\2\u00a5\u00a6\7k\2\2\u00a6\u00a7"+
		"\7\65\2\2\u00a7\u00a8\7\64\2\2\u00a8\6\3\2\2\2\u00a9\u00aa\7d\2\2\u00aa"+
		"\u00ab\7q\2\2\u00ab\u00ac\7q\2\2\u00ac\u00ad\7n\2\2\u00ad\b\3\2\2\2\u00ae"+
		"\u00af\7X\2\2\u00af\n\3\2\2\2\u00b0\u00b1\7c\2\2\u00b1\u00b2\7t\2\2\u00b2"+
		"\u00b3\7t\2\2\u00b3\u00b4\7c\2\2\u00b4\u00b5\7{\2\2\u00b5\f\3\2\2\2\u00b6"+
		"\u00b7\7h\2\2\u00b7\u00b8\7k\2\2\u00b8\u00b9\7p\2\2\u00b9\u00ba\7c\2\2"+
		"\u00ba\u00bb\7n\2\2\u00bb\16\3\2\2\2\u00bc\u00bd\7i\2\2\u00bd\u00be\7"+
		"q\2\2\u00be\u00bf\7v\2\2\u00bf\u00c0\7q\2\2\u00c0\20\3\2\2\2\u00c1\u00c2"+
		"\7k\2\2\u00c2\u00c3\7h\2\2\u00c3\22\3\2\2\2\u00c4\u00c5\7k\2\2\u00c5\u00c6"+
		"\7o\2\2\u00c6\u00c7\7r\2\2\u00c7\u00c8\7q\2\2\u00c8\u00c9\7t\2\2\u00c9"+
		"\u00ca\7v\2\2\u00ca\24\3\2\2\2\u00cb\u00cc\7k\2\2\u00cc\u00cd\7p\2\2\u00cd"+
		"\u00ce\7v\2\2\u00ce\u00cf\7g\2\2\u00cf\u00d0\7t\2\2\u00d0\u00d1\7h\2\2"+
		"\u00d1\u00d2\7c\2\2\u00d2\u00d3\7e\2\2\u00d3\u00d4\7g\2\2\u00d4\26\3\2"+
		"\2\2\u00d5\u00d6\7p\2\2\u00d6\u00d7\7g\2\2\u00d7\u00d8\7y\2\2\u00d8\30"+
		"\3\2\2\2\u00d9\u00da\7r\2\2\u00da\u00db\7c\2\2\u00db\u00dc\7e\2\2\u00dc"+
		"\u00dd\7m\2\2\u00dd\u00de\7c\2\2\u00de\u00df\7i\2\2\u00df\u00e0\7g\2\2"+
		"\u00e0\32\3\2\2\2\u00e1\u00e2\7r\2\2\u00e2\u00e3\7t\2\2\u00e3\u00e4\7"+
		"k\2\2\u00e4\u00e5\7x\2\2\u00e5\u00e6\7c\2\2\u00e6\u00e7\7v\2\2\u00e7\u00e8"+
		"\7g\2\2\u00e8\34\3\2\2\2\u00e9\u00ea\7r\2\2\u00ea\u00eb\7t\2\2\u00eb\u00ec"+
		"\7q\2\2\u00ec\u00ed\7v\2\2\u00ed\u00ee\7g\2\2\u00ee\u00ef\7e\2\2\u00ef"+
		"\u00f0\7v\2\2\u00f0\u00f1\7g\2\2\u00f1\u00f2\7f\2\2\u00f2\36\3\2\2\2\u00f3"+
		"\u00f4\7r\2\2\u00f4\u00f5\7w\2\2\u00f5\u00f6\7d\2\2\u00f6\u00f7\7n\2\2"+
		"\u00f7\u00f8\7k\2\2\u00f8\u00f9\7e\2\2\u00f9 \3\2\2\2\u00fa\u00fb\7t\2"+
		"\2\u00fb\u00fc\7g\2\2\u00fc\u00fd\7v\2\2\u00fd\"\3\2\2\2\u00fe\u00ff\7"+
		"u\2\2\u00ff\u0100\7v\2\2\u0100\u0101\7c\2\2\u0101\u0102\7v\2\2\u0102\u0103"+
		"\7k\2\2\u0103\u0104\7e\2\2\u0104$\3\2\2\2\u0105\u0106\7v\2\2\u0106\u0107"+
		"\7j\2\2\u0107\u0108\7k\2\2\u0108\u0109\7u\2\2\u0109&\3\2\2\2\u010a\u010b"+
		"\7n\2\2\u010b\u010c\7f\2\2\u010c\u010d\7e\2\2\u010d(\3\2\2\2\u010e\u010f"+
		"\7k\2\2\u010f\u0110\7p\2\2\u0110\u0111\7x\2\2\u0111\u0112\7q\2\2\u0112"+
		"\u0113\7m\2\2\u0113\u0114\7g\2\2\u0114\u0115\7u\2\2\u0115\u0116\7r\2\2"+
		"\u0116\u0117\7g\2\2\u0117\u0118\7e\2\2\u0118\u0119\7k\2\2\u0119\u011a"+
		"\7c\2\2\u011a\u011b\7n\2\2\u011b*\3\2\2\2\u011c\u011d\7k\2\2\u011d\u011e"+
		"\7p\2\2\u011e\u011f\7x\2\2\u011f\u0120\7q\2\2\u0120\u0121\7m\2\2\u0121"+
		"\u0122\7g\2\2\u0122\u0123\7x\2\2\u0123\u0124\7k\2\2\u0124\u0125\7t\2\2"+
		"\u0125\u0126\7v\2\2\u0126\u0127\7w\2\2\u0127\u0128\7c\2\2\u0128\u0129"+
		"\7n\2\2\u0129,\3\2\2\2\u012a\u012b\7k\2\2\u012b\u012c\7p\2\2\u012c\u012d"+
		"\7x\2\2\u012d\u012e\7q\2\2\u012e\u012f\7m\2\2\u012f\u0130\7g\2\2\u0130"+
		"\u0131\7u\2\2\u0131\u0132\7v\2\2\u0132\u0133\7c\2\2\u0133\u0134\7v\2\2"+
		"\u0134\u0135\7k\2\2\u0135\u0136\7e\2\2\u0136.\3\2\2\2\u0137\u0138\7c\2"+
		"\2\u0138\u0139\7t\2\2\u0139\u013a\7t\2\2\u013a\u013b\7c\2\2\u013b\u013c"+
		"\7{\2\2\u013c\u013d\7n\2\2\u013d\u013e\7g\2\2\u013e\u013f\7p\2\2\u013f"+
		"\u0140\7i\2\2\u0140\u0141\7v\2\2\u0141\u0142\7j\2\2\u0142\60\3\2\2\2\u0143"+
		"\u0144\7i\2\2\u0144\u0145\7g\2\2\u0145\u0146\7v\2\2\u0146\u0147\7h\2\2"+
		"\u0147\u0148\7k\2\2\u0148\u0149\7g\2\2\u0149\u014a\7n\2\2\u014a\u014b"+
		"\7f\2\2\u014b\62\3\2\2\2\u014c\u014d\7r\2\2\u014d\u014e\7w\2\2\u014e\u014f"+
		"\7v\2\2\u014f\u0150\7h\2\2\u0150\u0151\7k\2\2\u0151\u0152\7g\2\2\u0152"+
		"\u0153\7n\2\2\u0153\u0154\7f\2\2\u0154\64\3\2\2\2\u0155\u0156\7i\2\2\u0156"+
		"\u0157\7g\2\2\u0157\u0158\7v\2\2\u0158\u0159\7u\2\2\u0159\u015a\7v\2\2"+
		"\u015a\u015b\7c\2\2\u015b\u015c\7v\2\2\u015c\u015d\7k\2\2\u015d\u015e"+
		"\7e\2\2\u015e\66\3\2\2\2\u015f\u0160\7r\2\2\u0160\u0161\7w\2\2\u0161\u0162"+
		"\7v\2\2\u0162\u0163\7u\2\2\u0163\u0164\7v\2\2\u0164\u0165\7c\2\2\u0165"+
		"\u0166\7v\2\2\u0166\u0167\7k\2\2\u0167\u0168\7e\2\2\u01688\3\2\2\2\u0169"+
		"\u016a\7\60\2\2\u016a\u016b\7o\2\2\u016b\u016c\7g\2\2\u016c\u016d\7v\2"+
		"\2\u016d\u016e\7j\2\2\u016e\u016f\7q\2\2\u016f\u0170\7f\2\2\u0170:\3\2"+
		"\2\2\u0171\u0172\7\60\2\2\u0172\u0173\7e\2\2\u0173\u0174\7q\2\2\u0174"+
		"\u0175\7p\2\2\u0175\u0176\7u\2\2\u0176\u0177\7v\2\2\u0177\u0178\7t\2\2"+
		"\u0178\u0179\7w\2\2\u0179\u017a\7e\2\2\u017a\u017b\7v\2\2\u017b<\3\2\2"+
		"\2\u017c\u017d\7\60\2\2\u017d\u017e\7h\2\2\u017e\u017f\7k\2\2\u017f\u0180"+
		"\7g\2\2\u0180\u0181\7n\2\2\u0181\u0182\7f\2\2\u0182>\3\2\2\2\u0183\u0184"+
		"\7g\2\2\u0184\u0185\7z\2\2\u0185\u0186\7v\2\2\u0186\u0187\7g\2\2\u0187"+
		"\u0188\7p\2\2\u0188\u0189\7f\2\2\u0189\u018a\7u\2\2\u018a@\3\2\2\2\u018b"+
		"\u018c\7x\2\2\u018c\u018d\7c\2\2\u018d\u018e\7t\2\2\u018e\u018f\7c\2\2"+
		"\u018f\u0190\7t\2\2\u0190\u0191\7i\2\2\u0191\u0192\7u\2\2\u0192B\3\2\2"+
		"\2\u0193\u0197\t\2\2\2\u0194\u0196\t\3\2\2\u0195\u0194\3\2\2\2\u0196\u0199"+
		"\3\2\2\2\u0197\u0195\3\2\2\2\u0197\u0198\3\2\2\2\u0198D\3\2\2\2\u0199"+
		"\u0197\3\2\2\2\u019a\u01a3\7\62\2\2\u019b\u019f\t\4\2\2\u019c\u019e\t"+
		"\5\2\2\u019d\u019c\3\2\2\2\u019e\u01a1\3\2\2\2\u019f\u019d\3\2\2\2\u019f"+
		"\u01a0\3\2\2\2\u01a0\u01a3\3\2\2\2\u01a1\u019f\3\2\2\2\u01a2\u019a\3\2"+
		"\2\2\u01a2\u019b\3\2\2\2\u01a3F\3\2\2\2\u01a4\u01a6\7$\2\2\u01a5\u01a7"+
		"\5I%\2\u01a6\u01a5\3\2\2\2\u01a6\u01a7\3\2\2\2\u01a7\u01a8\3\2\2\2\u01a8"+
		"\u01a9\7$\2\2\u01a9H\3\2\2\2\u01aa\u01ac\5K&\2\u01ab\u01aa\3\2\2\2\u01ac"+
		"\u01ad\3\2\2\2\u01ad\u01ab\3\2\2\2\u01ad\u01ae\3\2\2\2\u01aeJ\3\2\2\2"+
		"\u01af\u01b2\n\6\2\2\u01b0\u01b2\5M\'\2\u01b1\u01af\3\2\2\2\u01b1\u01b0"+
		"\3\2\2\2\u01b2L\3\2\2\2\u01b3\u01b4\7^\2\2\u01b4\u01b8\t\7\2\2\u01b5\u01b8"+
		"\5O(\2\u01b6\u01b8\5Q)\2\u01b7\u01b3\3\2\2\2\u01b7\u01b5\3\2\2\2\u01b7"+
		"\u01b6\3\2\2\2\u01b8N\3\2\2\2\u01b9\u01ba\7^\2\2\u01ba\u01c5\5S*\2\u01bb"+
		"\u01bc\7^\2\2\u01bc\u01bd\5S*\2\u01bd\u01be\5S*\2\u01be\u01c5\3\2\2\2"+
		"\u01bf\u01c0\7^\2\2\u01c0\u01c1\5U+\2\u01c1\u01c2\5S*\2\u01c2\u01c3\5"+
		"S*\2\u01c3\u01c5\3\2\2\2\u01c4\u01b9\3\2\2\2\u01c4\u01bb\3\2\2\2\u01c4"+
		"\u01bf\3\2\2\2\u01c5P\3\2\2\2\u01c6\u01c8\7^\2\2\u01c7\u01c9\7w\2\2\u01c8"+
		"\u01c7\3\2\2\2\u01c9\u01ca\3\2\2\2\u01ca\u01c8\3\2\2\2\u01ca\u01cb\3\2"+
		"\2\2\u01cb\u01cc\3\2\2\2\u01cc\u01cd\5W,\2\u01cd\u01ce\5W,\2\u01ce\u01cf"+
		"\5W,\2\u01cf\u01d0\5W,\2\u01d0R\3\2\2\2\u01d1\u01d2\t\b\2\2\u01d2T\3\2"+
		"\2\2\u01d3\u01d4\t\t\2\2\u01d4V\3\2\2\2\u01d5\u01d6\t\n\2\2\u01d6X\3\2"+
		"\2\2\u01d7\u01d8\7*\2\2\u01d8Z\3\2\2\2\u01d9\u01da\7+\2\2\u01da\\\3\2"+
		"\2\2\u01db\u01dc\7}\2\2\u01dc^\3\2\2\2\u01dd\u01de\7\177\2\2\u01de`\3"+
		"\2\2\2\u01df\u01e0\7]\2\2\u01e0b\3\2\2\2\u01e1\u01e2\7_\2\2\u01e2d\3\2"+
		"\2\2\u01e3\u01e4\7=\2\2\u01e4f\3\2\2\2\u01e5\u01e6\7.\2\2\u01e6h\3\2\2"+
		"\2\u01e7\u01e8\7\60\2\2\u01e8j\3\2\2\2\u01e9\u01ea\7<\2\2\u01ea\u01eb"+
		"\7?\2\2\u01ebl\3\2\2\2\u01ec\u01ed\7>\2\2\u01edn\3\2\2\2\u01ee\u01ef\7"+
		"<\2\2\u01efp\3\2\2\2\u01f0\u01f1\7?\2\2\u01f1\u01f2\7?\2\2\u01f2r\3\2"+
		"\2\2\u01f3\u01f4\7>\2\2\u01f4\u01f5\7?\2\2\u01f5t\3\2\2\2\u01f6\u01f7"+
		"\7@\2\2\u01f7\u01f8\7?\2\2\u01f8v\3\2\2\2\u01f9\u01fa\7#\2\2\u01fa\u01fb"+
		"\7?\2\2\u01fbx\3\2\2\2\u01fc\u01fd\7~\2\2\u01fd\u01fe\7~\2\2\u01fez\3"+
		"\2\2\2\u01ff\u0200\7(\2\2\u0200\u0201\7(\2\2\u0201|\3\2\2\2\u0202\u0203"+
		"\7#\2\2\u0203~\3\2\2\2\u0204\u0205\7\u0080\2\2\u0205\u0080\3\2\2\2\u0206"+
		"\u0207\7-\2\2\u0207\u0082\3\2\2\2\u0208\u0209\7/\2\2\u0209\u0084\3\2\2"+
		"\2\u020a\u020b\7,\2\2\u020b\u0086\3\2\2\2\u020c\u020d\7\61\2\2\u020d\u0088"+
		"\3\2\2\2\u020e\u020f\7(\2\2\u020f\u008a\3\2\2\2\u0210\u0211\7~\2\2\u0211"+
		"\u008c\3\2\2\2\u0212\u0213\7`\2\2\u0213\u008e\3\2\2\2\u0214\u0215\7\'"+
		"\2\2\u0215\u0090\3\2\2\2\u0216\u0217\7@\2\2\u0217\u0092\3\2\2\2\u0218"+
		"\u0219\7>\2\2\u0219\u021a\7>\2\2\u021a\u0094\3\2\2\2\u021b\u021c\7@\2"+
		"\2\u021c\u021d\7@\2\2\u021d\u0096\3\2\2\2\u021e\u021f\7@\2\2\u021f\u0220"+
		"\7@\2\2\u0220\u0221\7@\2\2\u0221\u0098\3\2\2\2\u0222\u0224\t\13\2\2\u0223"+
		"\u0222\3\2\2\2\u0224\u0225\3\2\2\2\u0225\u0223\3\2\2\2\u0225\u0226\3\2"+
		"\2\2\u0226\u0227\3\2\2\2\u0227\u0228\bM\2\2\u0228\u009a\3\2\2\2\u0229"+
		"\u022a\7\61\2\2\u022a\u022b\7\61\2\2\u022b\u022f\3\2\2\2\u022c\u022e\n"+
		"\f\2\2\u022d\u022c\3\2\2\2\u022e\u0231\3\2\2\2\u022f\u022d\3\2\2\2\u022f"+
		"\u0230\3\2\2\2\u0230\u0232\3\2\2\2\u0231\u022f\3\2\2\2\u0232\u0233\bN"+
		"\2\2\u0233\u009c\3\2\2\2\u0234\u0235\7\61\2\2\u0235\u0236\7,\2\2\u0236"+
		"\u023a\3\2\2\2\u0237\u0239\13\2\2\2\u0238\u0237\3\2\2\2\u0239\u023c\3"+
		"\2\2\2\u023a\u023b\3\2\2\2\u023a\u0238\3\2\2\2\u023b\u023d\3\2\2\2\u023c"+
		"\u023a\3\2\2\2\u023d\u023e\7,\2\2\u023e\u023f\7\61\2\2\u023f\u0240\3\2"+
		"\2\2\u0240\u0241\bO\2\2\u0241\u009e\3\2\2\2\17\2\u0197\u019f\u01a2\u01a6"+
		"\u01ad\u01b1\u01b7\u01c4\u01ca\u0225\u022f\u023a\3\b\2\2";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}