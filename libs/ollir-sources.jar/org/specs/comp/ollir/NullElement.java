package org.specs.comp.ollir;

import java.util.List;

/**
 * This class is used to represent null Element values in the AST.
 */
public class NullElement extends Element implements NullNode {

    public NullElement() {
        super(new NullType(), List.of());
    }
}
