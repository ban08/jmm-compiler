/*
 * Compiler course
 *
 * Department of Informatics Engineering, Faculty of Engineering of the University of Porto Porto, Portugal
 *
 * March 2021
 *
 * @author João MP Cardoso
 */
package org.specs.comp.ollir;

import org.specs.comp.ollir.tree.TreeNode;
import pt.up.fe.specs.util.utilities.StringLines;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Class representing all the information loaded from the OLLIR input.
 */
public class ClassUnit extends TreeNode {

    String classPackage;

    ArrayList<String> imports;
    Set<String> importClasses;

    String className;

    String superClass;

    AccessModifier classAccessModifier = AccessModifier.DEFAULT;

    boolean staticClass = false;

    boolean finalClass = false;

    //ArrayList<Field> fieldList;

    //ArrayList<Method> methodList;

    public ClassUnit() {
        super(List.of());
        //this.fieldList = new ArrayList<Field>();
        //this.methodList = new ArrayList<Method>();
        this.imports = new ArrayList<String>();
        this.importClasses = new HashSet<>();
        this.superClass = null;
    }

    public int getNumFields() {
        return getFields().size();
    }

    public int getNumMethods() {
        return getMethods().size();
    }

    /**
     * TODO: Seems to be returning "Object" and not null, when class does not extend another.
     *
     * @return the name of the parent class if this class extends another, or null otherwise
     */
    public String getSuperClass() {
        return superClass;
    }

    public void setSuperClass(String superClass) {
        this.superClass = superClass;
    }

    public void checkMethodLabels() throws OllirErrorException {
        for (Method method : getMethods()) {
            method.checkLabels();
        }
    }

    public void buildCFGs() {
        for (Method method : getMethods()) {
            method.buildCFG();
        }
    }

    public void buildVarTables() {
        for (Method method : getMethods()) {
            method.buildVarTable();
        }
    }

    public void outputCFGs() throws OllirErrorException {
        for (Method method : getMethods()) {
            method.outputCFG();
        }
    }

    public String getClassName() {
        return this.className;
    }

    public String getClassFullyQualifiedName() {
        if (this.classPackage == null || this.classPackage.isEmpty()) {
            return this.className;
        }
        return this.classPackage + "." + this.className;
    }

    public String getImport(int index) {
        return this.imports.get(index);
    }

    public List<String> getImports() {
        return this.imports;
    }

    public void addImport(String str) {

        if (this.imports.contains(str)) {
            System.out.println("Ignoring duplicated import: " + str);
            return;
        }

        this.imports.add(str);

        var simpleClassName = Ollir.getSimpleClassName(str);

        var isNew = this.importClasses.add(simpleClassName);

        if (!isNew) {
            throw new RuntimeException(
                    "Code has two imports with the name simple class name: " + simpleClassName);
        }
    }

    /**
     * @param simpleClassName
     * @return true is the given class name is an import (e.g. "io" will return true if there is an import foo.io;),
     * false otherwise
     */
    public boolean isImportedClass(String simpleClassName) {
        return importClasses.contains(simpleClassName);
    }

    public Set<String> getImportedClasseNames() {
        return importClasses;
    }

    public void setClassName(String name) {
        this.className = name;
    }

    public Field getField(int index) {
        return this.getFields().get(index);
    }

    public List<Field> getFields() {
        return getChildrenOf(Field.class);
    }

    public void addField(Field newField) {
        addChild(newField);
    }

    public Method getMethod(int index) {
        return getMethods().get(index);
    }

    public List<Method> getMethods() {
        return getChildrenOf(Method.class);
    }

    public void addMethod(Method newMethod) {
        addChild(newMethod);
    }

    public void setClassAccessModifier(AccessModifier classAccessModifier) {
        if (this.classAccessModifier != AccessModifier.DEFAULT)
            System.out.println("Warning: class access modifier previously set to: " + this.classAccessModifier);
        else
            this.classAccessModifier = classAccessModifier;
    }

    public AccessModifier getClassAccessModifier() {
        return this.classAccessModifier;
    }

    public boolean isStaticClass() {
        return this.staticClass;
    }

    public void setStaticClass() {
        this.staticClass = true;
    }

    public boolean isFinalClass() {
        return this.staticClass;
    }

    public void setFinalClass() {
        this.finalClass = true;
    }

    public void setPackage(String classPackage) {
        this.classPackage = classPackage;
    }

    public String getPackage() {
        return this.classPackage;
    }

    public void show() {
        show(System.out);
    }

    public void show(PrintStream out) {
        out.println("** Name of the package: " + this.classPackage);
        out.println("** Name of the class: " + this.className);
        out.println("\tAccess modifier: " + this.classAccessModifier);
        out.println("\tStatic class: " + this.staticClass);
        out.println("\tFinal class: " + this.finalClass);

        for (Field field : getFields()) {
            field.show(out);
        }

        for (Method method : getMethods()) {
            method.show(out);
        }
    }


/*
    @Override
    public List<OllirNode> getChildren() {
        var children = new ArrayList<OllirNode>();

        children.addAll(getFields());
        children.addAll(getMethods());

        return children;
    }
*/

    @Override
    public String code() {
        var code = new StringBuilder();

        code.append("package " + getPackage() + ";\n\n");

        var imports = getImports();
        imports.forEach(importName -> {
            code.append("import " + importName + ";\n");
        });

        if (!imports.isEmpty()) {
            code.append("\n");
        }

        code.append(getClassName() + " extends \"" + getSuperClass() + "\" {\n\n");

        var ident = "   ";

        for (var field : getFields()) {
            code.append(ident + field.code() + "\n");
        }

        if (!getFields().isEmpty()) {
            code.append("\n");
        }


        for (var method : getMethods()) {
            var methodCode = method.code();
            StringLines.getLines(methodCode).forEach(line -> code.append(ident + line + "\n"));
        }

        code.append("\n}\n");
        return code.toString();
    }
}
