package pt.up.fe.comp.test.env.providers;

import com.github.difflib.DiffUtils;
import com.github.difflib.UnifiedDiffUtils;
import com.github.difflib.patch.Patch;
import pt.up.fe.specs.util.SpecsCheck;
import pt.up.fe.specs.util.SpecsIo;

import java.io.File;
import java.util.List;

/**
 * Provides text content and a temporary file if a file reference is needed.
 */
public class TextDiffProvider extends ContentProvider {

    private File fileRef;
    private final String original;
    private final String revised;
    private final String extension;
    private String diffContent;


    public TextDiffProvider(String description, String original, String revised, String extension) {
        super(description);
        SpecsCheck.checkNotNull(original, () -> "'Original' content of TextDiffProvider cannot be null");
        SpecsCheck.checkNotNull(original, () -> "'Revised' content of TextDiffProvider cannot be null");
        this.original = original;
        this.revised = revised;
        this.extension = extension != null ? extension : "txt";
    }

    @Override
    public File getFile() {
        if (fileRef == null) {
            fileRef = createTempFile(extension);
            SpecsIo.write(fileRef, getContent());
        }
        return fileRef;
    }

    @Override
    public String getExtension() {
        return extension;
    }

    @Override
    public boolean isTempFile() {
        return true;
    }

    @Override
    public String getContent() {
        if (diffContent != null) {
            return diffContent;
        }
        var originalLines = List.of(original.split("\n"));
        if (!hasChanges()) {
            diffContent = """
                    --- Expected	content.%s
                    +++ Expected	content.%s
                    @@ -1,%d +1,%d @@
                     %s""".formatted(extension, extension,
                    originalLines.size(), originalLines.size(),
                    String.join("\n ", originalLines));
            return diffContent;
        }


        var revisedLines = List.of(revised.split("\n"));
        Patch<String> diff = DiffUtils.diff(originalLines, revisedLines, false);
        //generating unified diff format
        int contextSize = Math.max(originalLines.size(), revisedLines.size());
        List<String> unifiedDiff = UnifiedDiffUtils.generateUnifiedDiff("content." + extension, "content." + extension, originalLines, diff, contextSize);
        diffContent = String.join("\n", unifiedDiff);
        return diffContent;
    }

    public boolean hasChanges() {
        return !original.equals(revised);
    }
}
