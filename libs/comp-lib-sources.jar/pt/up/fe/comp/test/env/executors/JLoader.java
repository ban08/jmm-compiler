package pt.up.fe.comp.test.env.executors;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;

public class JLoader {
    private final ClassLoader loader;

    public JLoader() {
        this(Object.class.getClassLoader());
    }

    public JLoader(ClassLoader loader) {
        this.loader = loader;
    }

    public JLoader(List<File> classPaths, ClassLoader parent) {
        var urls = classPaths.stream().map(f -> {
            try {
                return f.toURI().toURL();
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
        }).toList().toArray(new URL[0]);
        this.loader = new URLClassLoader(urls, parent);
    }

    public Class<?> load(String qualifiedName) throws ClassNotFoundException {
        return loader.loadClass(qualifiedName);
    }
}
