package pt.up.fe.comp.test.env.utils;

import org.antlr.v4.misc.OrderedHashMap;
import org.specs.comp.ollir.ClassUnit;
import org.w3c.dom.Text;
import pt.up.fe.comp.jmm.jasmin.ExecutionResult;
import pt.up.fe.comp.test.env.providers.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Utility that stores intermediate compilation artifacts and debugging information produced during the execution of
 * the tests. Provides methods to reset state, store artifacts to temporary or resource files,build debug messages
 * (including file:// references), and captured execution results and user logs.
 *
 * <p>This is a class to be used withing the {@link pt.up.fe.comp.test.env.CompilerAssertion} class. It populates an
 * instance of this class with relevant information during the compilation and execution process. The assertion methods
 * will then use methods such as {@link #buildDebugInfoMessage(String, String, String)} or {@link #debugInfoTempFiles()}
 * to obtain file references and debugging information suitable for inclusion in test failure messages.</p>
 */
public class CompilerHistory {
    private static final String FAILED_DIR_NAME = "failed";
    private static final String PASSED_DIR_NAME = "passed";

    //if we are not running in a jar, then the resource file is accessible directly from the file system,
    //for which we should specify the resource folder specified in the Gradle file, relative path from the project root

    private ObjectProvider<Map<String, String>> config;

    // Parser
    private ContentProvider jmm;
    private String ast;
    private String astOpt;
    private String symbolTable;

    // OLLIR
    private ContentProvider ollir;
    private ContentProvider comparingOllir;
    private String ollirComparingCodeDescription;
    private String ollirThisCodeDescription;
    private ClassUnit ollirClass;
    private String ollirComparingClass;

    //Jasmin
    private ContentProvider jasmin;
    private ExecutionResult executionResult;
    private ContentProvider executionReport;

    //Logging
    private StreamProvider userLog;
    private StreamProvider reportsLog;
    private String ollirDescription;

    //Contains info regarding the test (Name, class,...)
    private TestInfo testInfo;
    //A textual description of the test, to be included in the report (may be null or empty)
    private String testDescription;

    private InfoHtml html;
    private final File failDir;
    private final File passDir;

    private boolean failed;
    private String finalHtmlEncondedUrl;

    private List<AssertionResult> assertionsPassed;

    /**
     * Create a new {@code CompilerHistory} instance.
     *
     * @param config configuration map (may be {@code null}) used by tests or reporters
     */
    public CompilerHistory(Map<String, String> config) {
        Objects.requireNonNull(config, "Config map cannot be null. Use an Collections.emptyMap() instead.");
        reset();
        this.setConfig(config);
        File baseDir = new File("build/reports/tests/test");
        this.failDir = createDir(baseDir, FAILED_DIR_NAME);

        this.passDir = createDir(baseDir, PASSED_DIR_NAME);

        this.html = new InfoHtml();
    }

    private static File createDir(File baseDir, String subDirName) {
        File dir = new File(baseDir, subDirName);
        if (!dir.exists()) {
            boolean created = dir.mkdirs();
            if (!created) {
                throw new RuntimeException("Unable to create directory for test reports: " + dir.getAbsolutePath());
            }
        }
        return dir;
    }


    /**
     * Reset stored artifacts and logs to an initial empty state.
     * Any previously captured data will be discarded.
     */
    public void reset() {
        this.jmm = null;
        this.ast = null;
        this.symbolTable = null;
        this.ollir = null;
        this.ollirDescription = null;
        this.jasmin = null;
        this.astOpt = null;
        this.comparingOllir = null;
        this.ollirComparingCodeDescription = null;
        this.ollirThisCodeDescription = "";
        this.ollirComparingClass = null;
        this.ollirClass = null;
        this.executionResult = null;
        this.executionReport = null;
        this.userLog = new StreamProvider("User Log", new ByteArrayOutputStream(), "log");
        this.reportsLog = new StreamProvider("Reports Log", new ByteArrayOutputStream(), "log");
        this.failed = false;
        this.finalHtmlEncondedUrl = null;
        this.assertionsPassed = new ArrayList<>();
    }


    /**
     * Build a debug information message that contains a link to a report and to resources/temporary file references
     * for stored artifacts.
     *
     * @param message  failure or context message
     * @param expected expected value (for the report)
     * @param actual   actual value (for the report)
     * @return formatted debug message suitable to append to test assertions or logs
     */
    public String buildDebugInfoMessage(String message, String expected, String actual) {
        String debugMessage = "";
        if (testDescription != null && !testDescription.isBlank()) {
            debugMessage += "\n - Description: " + testDescription;
        }
        try {
            debugMessage += "\n - See report at: " + buildHtmlFile(message, expected, actual);
        } catch (IOException e) {
            //won't be able to show the report as a web page.
        }
        debugMessage += "\n - Debugging info:\n" + debugToFiles();
        return debugMessage;
    }

    public String buildDebugInfoMessage(String message, String expected, String actual, Exception e) {
        message = buildDebugInfoMessage(message, expected, actual);
        message += "\n - Exception: " + e;
        return message;
    }

    public String buildHtmlFile(String message, String expected, String actual) throws IOException {
        if (finalHtmlEncondedUrl == null) {
            finalHtmlEncondedUrl = html.show(testInfo, this, failed ? failDir : passDir, message, failed, expected, actual);
        }
        return finalHtmlEncondedUrl;
    }


    /**
     * Alias for {@link #debugInfoTempFiles()} retained for backward compatibility.
     *
     * @return debug information referencing temporary or resource files
     */
    public String debugToFiles() {
        return debugInfoTempFiles();
    }

    /**
     * Produce a string containing intermediate step outputs (AST, symbol table, optimized AST)
     * if they are present.
     *
     * @return concatenated intermediate information or an empty string
     */
    public MapProvider<String> debugMidSteps() {
        return new MapProvider<>("Intermediate Information", intermediateInfo(), "log");
    }

    private void addIfExists(String description, String content, String extension, List<ContentProvider> list) {
        if (content != null) {
            list.add(new TextProvider(description, content, extension));
        }
    }

    private void addIfExists(String mainDescription, String originalDesc, String descriptionComp, String original, String revised, String extension, List<ContentProvider> list) {
        if (original != null) {
            if (revised != null) {
                list.add(new TextDiffProvider(mainDescription + ": " + originalDesc + " vs " + descriptionComp, original, revised, extension));
            } else {
                list.add(new TextProvider(mainDescription, original, extension));
            }
        }
    }

    public List<ContentProvider> midStepsAsProviders() {
        List<ContentProvider> providers = new ArrayList<>();
        addIfExists(this.config.getDescription(), this.config.getContent(), "log", providers);
        addIfExists("AST", "original", "transformed", this.ast, this.astOpt, "log", providers);
        addIfExists("Symbol Table", this.symbolTable, "log", providers);
        addIfExists("OLLIR Tree", "original", "transformed", this.ollirComparingClass, this.getOllirClassAsTree(), "java", providers);
        addIfExists("Assertions Passed", this.printAssertionsPassed(), "log", providers);
        return providers;
    }


    public Map<String, String> intermediateInfo() {
        var map = new OrderedHashMap<String, String>();
        if (!this.getCompilerConfig().isEmpty())
            map.put(this.config.getDescription(), this.config.getContent());
        if (this.ast != null)
            map.put("AST", this.ast);
        if (this.symbolTable != null)
            map.put("Symbol Table", this.symbolTable);
        if (this.astOpt != null && !Objects.equals(this.ast, this.astOpt))
            map.put("Transformed AST", this.astOpt);
        if (this.ollirComparingClass != null)
            map.put("Original OLLIR Tree", this.ollirComparingClass);
        if (this.ollirClass != null)
            map.put(this.ollirComparingClass != null ? "Transformed OLLIR Tree" : "OLLIR Tree", this.getOllirClassAsTree());
        if (!this.assertionsPassed.isEmpty())
            map.put("Assertions Passed", this.printAssertionsPassed());
        return map;
    }

    private String printAssertionsPassed() {
        return assertionsPassed.stream().map(AssertionResult::prettyPrint).collect(Collectors.joining("\n\n"));
    }

    /**
     * Build a human-readable reference to a file. If the provider is null, an empty string is returned.
     *
     * @param provider The content provider that will provide the file link and description
     * @return formatted single-line reference containing a file:// URL
     */
    public String referenceToFile(ContentProvider provider) {
        //if provider is null, don't do anything
        if (provider == null) {
            return "";
        }
        return provider.getDescription() + " " + (provider.isTempFile() ? "(temp)" : "") + ": " + provider.getFileLink() + System.lineSeparator();
    }

    /**
     * Build a concatenated string containing references (and possibly temporary files) for all
     * stored artifacts: JMM, OLLIR, Jasmin, execution reports and user logs.
     *
     * @return concatenated references and debug text suitable for inclusion in failure messages
     */
    public String debugInfoTempFiles() {

        return referenceToFile(jmm)
                +
                referenceToFile(comparingOllir)
                +
                referenceToFile(ollir)
                +
                referenceToFile(jasmin)
                +
                buildExecFiles()
                +
                buildMidStepFile()
                +
                buildReportsLogFile()
                +
                buildUserLogFile();
    }

    /**
     * Write the report log buffer to a temporary file if it is not blank.
     *
     * @return reference to the written log file or an empty string if log is blank
     */
    private String buildReportsLogFile() {
        var log = reportsLog.toString();
        return log.isBlank() ? "" :
                referenceToFile(reportsLog);
    }


    /**
     * Write the user log buffer to a temporary file if it is not blank.
     *
     * @return reference to the written log file or an empty string if log is blank
     */
    private String buildUserLogFile() {
        var log = userLog.toString();
        return log.isBlank() ? "" :
                referenceToFile(userLog);
    }

    /**
     * Build execution-related files and a summary report for the stored {@link ExecutionResult}.
     *
     * @return concatenated references and files related to execution result or empty string if none
     */
    private String buildExecFiles() {
        var exec = "";
        if (executionResult != null) {
            var workingDir = new TextProvider("Jasmin Working Directory", executionResult.getWorkingDir().getAbsolutePath(), "log");
            var stdoutLog = new TextProvider("Jasmin Output", executionResult.getFullOutput(), "log");
            exec = referenceToFile(workingDir)
                    + referenceToFile(executionReport)
                    + referenceToFile(stdoutLog);
        }
        return exec;
    }

    /**
     * Write intermediate step information to a temporary file if present.
     *
     * @return reference to the file containing intermediate information or an empty string
     */
    private String buildMidStepFile() {
        var mid = debugMidSteps();
        return mid.getContent().isBlank() ? "" : referenceToFile(mid);
    }

    /**
     * @return stored AST representation (may be null)
     */
    public String getAst() {
        return ast;
    }

    /**
     * @return stored symbol table (may be null)
     */
    public String getSymbolTable() {
        return symbolTable;
    }


//    /**
//     * @return current test name used when generating HTML reports (may be {@code null})
//     */
//    public String getCurrentTestName() {
//        return testInfo.getMethodName();
//    }

//    /**
//     * Set the current test name used to label generated reports.
//     *
//     * @param currentTestName human-readable test name
//     */
//    public void setCurrentTestName(String currentTestName) {
//        this.currentTestName = currentTestName;
//        this.setTestDescription(null); //reset description (for tests that doesn't set the description)
//    }

    public void setTestDescription(String testDescription) {
        this.testDescription = testDescription;
    }

    public String getTestDescription() {
        return testDescription;
    }

    /**
     * Replace the configuration map used by the history object.
     *
     * @param config new configuration map (may be {@code null})
     */
    public void setConfig(Map<String, String> config) {
        this.config = new ObjectProvider<>("Compiler Configuration", config, this::ArgsToString);
    }

    private String ArgsToString(Map<String, String> args) {
        if (args == null || args.isEmpty()) {
            return "No configuration parameters.";
        }
        StringBuilder sb = new StringBuilder();
        for (var entry : args.entrySet()) {
            sb.append(entry.getKey()).append(" = ").append(entry.getValue()).append("\n");
        }
        return sb.toString();
    }

    /**
     * @return {@code true} if a comparing OLLIR snippet has been set
     */
    public boolean hasComparingCode() {
        return this.comparingOllir != null;
    }

    /**
     * @return stored optimized AST (may be null)
     */
    public String getAstOpt() {
        return astOpt;
    }

    /**
     * @return description for the comparing OLLIR code (may be null)
     */
    public String getOllirComparingCodeDescription() {
        return ollirComparingCodeDescription;
    }

    /**
     * @return description for the current OLLIR snippet being tested (may be empty)
     */
    public String getOllirThisCodeDescription() {
        return ollirThisCodeDescription;
    }

    /**
     * Set comparing OLLIR snippets and descriptions used to produce side-by-side reports.
     *
     * @param comparingOllir            text of the comparing ollir snippet
     * @param comparingOllirDescription human-friendly description for comparing snippet
     * @param thisOllirDescription      description for the primary OLLIR snippet
     */
    public void setComparingOllir(String comparingOllir, String comparingOllirDescription, String thisOllirDescription, ClassUnit ollirComparingClass) {
        this.comparingOllir = new TextProvider(comparingOllirDescription, comparingOllir, "ollir");
        this.ollirComparingCodeDescription = comparingOllirDescription;
        this.ollirDescription = thisOllirDescription;
        this.ollirComparingClass = ollirClassAsTree(ollirComparingClass);
    }

    /**
     * @return stored execution result (may be {@code null})
     */
    public ExecutionResult getExecutionResult() {
        return executionResult;
    }

    public ContentProvider getExecutionReport() {
        if (executionReport == null) {
            if (executionResult != null) {
                var classPathList = "";
                var classpath = executionResult.getClasspath();
                if (classpath.isEmpty()) {
                    classPathList = "(unspecified)";
                } else {
                    if (classpath.size() == 1) {
                        classPathList = classpath.getFirst();
                    } else {
                        classPathList = "\n - " + String.join("\n - ", classpath);
                    }
                }
                var log = """
                        Working Directory: %s
                        Classpath: %s
                        Class Name: %s
                        Arguments: %s
                        Input: %s
                        Return Code: %d
                        """.formatted(
                        executionResult.getWorkingDir().getAbsolutePath(),
                        classPathList,
                        executionResult.getClassName(),
                        executionResult.getArgs().isEmpty() ? "(none)" : String.join(" ", executionResult.getArgs()),
                        executionResult.getInput() != null ? executionResult.getInput() : "(none)",
                        executionResult.getReturnCode());
                var execLog = new TextProvider("Jasmin Execution Report", log, "log");

            }
        }
        return executionReport;
    }

    /**
     * @return configuration map associated with this history object (may be {@code null})
     */
    public Map<String, String> getCompilerConfig() {
        return config.get();
    }

    public ContentProvider getConfigProvider() {
        return config;
    }

    /**
     * Append a message to the in-memory user log (no newline).
     *
     * @param message message to append
     */
    public void log(String message) {
        userLog.write(message);
    }

    /**
     * Append a message to the in-memory user log followed by a newline.
     *
     * @param message message to append
     */
    public void logln(String message) {
        userLog.writeln(message);
    }

    public void reportln(String message) {
        reportsLog.writeln(message);
    }

    public void report(String message) {
        reportsLog.write(message);
    }

    /**
     * @return current contents of the in-memory user log
     */
    public StreamProvider getUserLog() {
        return userLog;
    }


    /**
     * Set the stored AST textual representation.
     *
     * @param ast AST text to set
     */
    public void setAst(String ast) {
        this.ast = ast;
    }

    /**
     * Set the optimized AST textual representation.
     *
     * @param astOpt optimized AST text to set
     */
    public void setAstOpt(String astOpt) {
        this.astOpt = astOpt;
    }

    /**
     * Set the symbol table textual representation.
     *
     * @param symbolTable symbol table text to set
     */
    public void setSymbolTable(String symbolTable) {
        this.symbolTable = symbolTable;
    }


    /**
     * Store an execution result captured after running Jasmin-generated code.
     *
     * @param executionResult execution result to store
     */
    public void setExecutionResult(ExecutionResult executionResult) {
        this.executionResult = executionResult;
    }

    public ContentProvider getJmm() {
        return jmm;
    }

    public ContentProvider getComparingOllir() {
        return comparingOllir;
    }

    /**
     * Either returns a Simple Ollir provider or a Diff between "comparing" and "current" ollir
     *
     * @return
     */
    public ContentProvider getOllirCode() {
        if (comparingOllir == null) {
            return getOllir();
        }
        return new TextDiffProvider("OLLIR: " + getComparingOllir().getDescription() + " vs " + getOllir().getDescription(),
                getComparingOllir().getContent(), getOllir().getDescription(), "ollir");

    }

    public ContentProvider getOllir() {
        return ollir;
    }

    public ClassUnit getOllirClass() {
        return ollirClass;
    }

    public String getOllirClassAsTree() {
        return ollirClassAsTree(ollirClass);
    }


    private String ollirClassAsTree(ClassUnit ollirClass) {
        if (ollirClass == null) {
            return null;
        }
        var baos = new ByteArrayOutputStream();
        var printer = new PrintStream(baos, true);
        ollirClass.show(printer);
        return baos.toString();
    }

    public String getOllirComparingClassAsTree() {
        if (ollirComparingClass == null) {
            return null;
        }
        return ollirComparingClass;
    }

    public ContentProvider getJasmin() {
        return jasmin;
    }

    public ContentProvider getLogger() {
        return userLog;
    }

    public void setJmm(ContentProvider jmm) {
        this.jmm = jmm;
    }

    public void setOllir(ContentProvider ollir) {
        this.ollir = ollir;
        if (this.ollirDescription != null) {
            this.ollir.setDescription(this.ollirDescription);
        }
    }

    public void setOllirClass(ClassUnit ollirClass) {
        this.ollirClass = ollirClass;
    }

    public void setJasmin(ContentProvider jasmin) {
        this.jasmin = jasmin;
    }

    public void setTestInfo(TestInfo testInfo) {
        this.testInfo = testInfo;
    }

    public ContentProvider getReportLog() {
        return this.reportsLog;
    }

    public void failed() {
        this.failed = true;
    }

    public void passed() {
        this.failed = false;
    }

    public void addPassedAssertion(AssertionType type, String message, String expected, String actual) {
        assertionsPassed.add(AssertionResult.pass(type, message, expected, actual));
    }

}
