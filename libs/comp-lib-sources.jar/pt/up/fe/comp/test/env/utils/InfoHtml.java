package pt.up.fe.comp.test.env.utils;

import pt.up.fe.comp.test.env.providers.ContentProvider;
import pt.up.fe.comp.test.env.providers.MapProvider;
import pt.up.fe.comp.test.env.providers.TextDiffProvider;
import pt.up.fe.specs.util.SpecsIo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Base64;
import java.util.List;

/**
 * Helper that constructs an HTML report page from a {@link CompilerHistory} instance and writes it
 * to a temporary file. The generated page contains code snippets, execution reports and logs and
 * is intended to be shown to users when tests fail.
 *
 * <p>Public API:</p>
 * <ul>
 *     <li>{@link #show(String, CompilerHistory, String, String, String)} - create the HTML page and
 *     return a file:// URL pointing to it.</li>
 * </ul>
 */
public class InfoHtml {
    private static final String BASE_PATH = "templates/feedback/";

    public InfoHtml() {
    }

    private static final String[] colors = {"#FFFFFF", "#000000", "#444444", "#888888", "#BBBBBB"};
    private static final String DIFF_CLASS_NAME = "diff";
    private static final boolean USE_FULL_PAGE = true;
    private static final HighlightThemes DEFAULT_THEME = HighlightThemes.GITHUB_V2;

    private enum HighlightThemes {
        GITHUB_V2("github-v2"),
        ATELIER_SULPHURPOOL_LIGHT("atelier-sulphurpool-light");
        private final String theme;

        HighlightThemes(String fileName) {
            theme = BASE_PATH + fileName + ".css";
        }

        String getCssContent() {
            return SpecsIo.getResource(theme);
        }
    }

    private static String colorFor(int headerLevel) {
        if (headerLevel >= colors.length) {
            throw new IllegalArgumentException("Invalid header level. Maximum supported: " + colors.length);
        }
        return "style=\"color: " + colors[headerLevel] + "\"";
    }
//

    /**
     * Create an HTML report page for the provided test/context information and return a file://
     * URL referencing the generated temporary file.
     *
     * @param testInfo Information about the current test, used to generate html file, set the page title and description
     * @param history  compiler history containing code snippets, execution results and logs
     * @param message  descriptive message to include in the page (may contain newlines)
     * @param expected expected value displayed in the report (may be {@code null})
     * @param given    actual/given value displayed in the report (may be {@code null})
     * @return a {@code file://} URL pointing to the created temporary HTML file
     * @throws IOException if writing the temporary file or reading the HTML template fails
     */
    public String show(TestInfo testInfo, CompilerHistory history, File outputDir,
                       String message, boolean failed, String expected, String given) throws IOException {
        String html = buildHTML(testInfo.getMethodName(), history, message, failed, expected, given);
        var fileName = testInfo.getTestClassName() + "." + testInfo.getMethodName().replaceAll("[^a-zA-Z0-9]", "_") + ".html";
        var htmlFile = new File(outputDir, fileName);
        SpecsIo.write(htmlFile, html);
        return FileUtils.encodeUrl(htmlFile);
    }


    /**
     * Produce an HTML fragment containing the provided code wrapped in a preformatted block.
     * The method performs HTML escaping on the title and code content.
     *
     * @param title    title shown above the code block
     * @param code     raw code text to include in the block (may be {@code null} or empty)
     * @param language language identifier used for CSS/class hints (e.g. "java", "txt")
     * @return HTML snippet containing an H2 title and a PRE element with escaped code
     */
    private static String codeHtml(String title, String code, String language) {
        return codeHtml(title, code, language, 2);
    }

    private static String diffHtml(String title, TextDiffProvider provider, int headerLevel) {
        if (!provider.hasChanges()) {
            title = title + ": there are no changes!";
//            return codeHtml(title, provider.getContent(), provider.getExtension(), headerLevel);
        }
        var base64 = Base64.getEncoder().encodeToString(provider.getContent().getBytes());

        String escapedTitle = escapeHtml(title);
        return "<h" + headerLevel + " ${h" + headerLevel + "_color}>" + escapedTitle + "</h" + headerLevel + ">\n"
                + "<div class=\"codeblock\">\n"
                + "<label><input type=\"checkbox\" class=\"collapser\" targetClass=\"" + DIFF_CLASS_NAME + "\"/>Collapse</label></br></br>"
                + "<div class=\"%s\">%s</div>\n".formatted(DIFF_CLASS_NAME, base64)
                + "</div>";
    }


    private static String codeHtml(String title, String code, String language, int headerLevel) {
        String escapedCode = escapeHtml(code);
        String escapedTitle = escapeHtml(title);
        String header = "";
        if (headerLevel > 0) {
            header = "<h" + headerLevel + " ${h" + headerLevel + "_color}>" + escapedTitle + "</h" + headerLevel + ">\n";
        }
        return header
                + "<div class=\"codeblock\">\n"
                + "<label><input type=\"checkbox\" class=\"collapser\" targetClass=\"prettyprint\"/>Collapse</label></br>"
                + "<pre class=\"prettyprint lang-" + language + " linenums\" >"
                + escapedCode
                + "</pre>\n"
                + "</div>";
    }

    private static String codeHtml(String title, List<ContentProvider> provider) {
        if (provider == null)
            return "";
        String escapedTitle = escapeHtml(title);
        StringBuilder html = new StringBuilder("<h2 ${h2_color}>" + escapedTitle + "</h2>\n");
        int i = 1;
        for (var entry : provider) {
            if (entry instanceof TextDiffProvider tdp) {
                html.append(diffHtml((i++) + ". " + entry.getDescription(), tdp, 3));
            } else {
                html.append(codeHtml((i++) + ". " + entry.getDescription(), entry.getContent(), entry.getExtension(), 3));
            }
        }
        return html.toString();
    }

    private static String codeHtml(MapProvider<? extends Object> provider, String language) {
        if (provider == null)
            return "";
        String escapedTitle = escapeHtml(provider.getDescription());
        StringBuilder html = new StringBuilder("<h2 ${h2_color}>" + escapedTitle + "</h2>\n");
        var info = provider.getContentMap();
        int i = 1;
        for (var entry : info.entrySet()) {
            html.append(codeHtml((i++) + ". " + entry.getKey(), entry.getValue().toString(), language, 3));
        }
        return html.toString();
    }

    private static String codeHtml(ContentProvider provider, String language) {
        if (provider == null)
            return "";
        if (provider instanceof TextDiffProvider tdp) {
            return diffHtml(provider.getDescription(), tdp, 2);
        }
        return codeHtml(provider.getDescription(), provider.getContent(), language);
    }


    /**
     * Build the full HTML contents for the provided information, write it to a temporary file and
     * return the {@link Path} to that file.
     *
     * <p>The method reads an HTML template resource named {@code templates/feedback/report.html}
     * and replaces placeholders with the escaped title, message, expected/given values and the
     * assembled compiler information.</p>
     *
     * @param title    visible title for the page (used to create a filename and page title)
     * @param history  compiler history instance containing snippets and execution information
     * @param message  descriptive message to include in the page
     * @param expected expected value shown in the report
     * @param given    actual/given value shown in the report
     * @return path to the temporary HTML file created
     * @throws IOException if creating or writing the temporary file or reading the template fails
     */
    private static String buildHTML(String title, CompilerHistory history, String message, boolean failed, String expected, String given) throws IOException {
        String escapedTitle = escapeHtml(title);
        String description = escapeHtml(history.getTestDescription());
        StringBuilder compilerInfo = new StringBuilder();
        compilerInfo.append(codeHtml(history.getJmm(), "java"));

        compilerInfo.append(codeHtml(history.getOllir(), "ollir"));
//        if (history.hasComparingCode()) {
//            var comparing = new TextDiffProvider("OLLIR: "+ history.getComparingOllir())
//            compilerInfo.append(diffHtml("OLLIR", history.getComparingOllir(), history.getOllir(), "java"));
////            compilerInfo.append(codeHtml(history.getComparingOllir(), "java"));
////            compilerInfo.append(codeHtml(history.getOllir(), "java"));
//        } else {
//            compilerInfo.append(codeHtml(history.getOllir(), "java"));
//
//        }


        compilerInfo.append(codeHtml(history.getJasmin(), "java"));


        var execResult = history.getExecutionResult();

        if (execResult != null) {

            compilerInfo.append(codeHtml(history.getExecutionReport(), "log"));
            compilerInfo.append(codeHtml("Standard Output", execResult.getStdout(), "txt"));
            compilerInfo.append(
                    execResult.getStderr().isEmpty() ? "" : codeHtml("Standard Error", execResult.getStderr(), "txt"));
        }

//        var intermediateInfo = history.debugMidSteps();
//        compilerInfo.append(codeHtml(intermediateInfo, "log"));
        var intermediateInfo = history.midStepsAsProviders();
        compilerInfo.append(codeHtml("Intermediate Logs", intermediateInfo));
        if (!history.getReportLog().getContent().isBlank()) {
            compilerInfo.append(codeHtml(history.getReportLog(), "log"));
        }
        if (!history.getLogger().getContent().isBlank()) {
            compilerInfo.append(codeHtml(history.getLogger(), "log"));
        }

        String assertion = "";
        if (failed) {
            if (!expected.isBlank()) {
                var diff = new TextDiffProvider("Expected vs Given", expected, given, "log");
                assertion = diffHtml("Expected vs Given", diff, 3);
            } else {
                assertion = codeHtml("Given", given, "log", -1);
            }
//            assertion = """
//                    <strong>Expected</strong>
//                    <p>${expected}</p>
//                    <strong>Given</strong>
//                    <p>${given}</p>"""
//                    .replace("${expected}", escapeHtml(expected))
//                    .replace("${given}", escapeHtml(given));
        }

        var escapedMessage = escapeHtml(message).replace("\n", "<br>");

        var pretty_print_additional_css = USE_FULL_PAGE ? "" : "display: inline-block;";

        String html = SpecsIo.getResource(BASE_PATH + "report.html")
                .replace("${title}", escapedTitle)
                .replace("${description}", description.isEmpty() ? "" : "<h2 ${h2_color}>Description</h2><p>" + description + "</p>")
                .replace("${SYNTAX_HIGHLIGHT_THEME}", DEFAULT_THEME.getCssContent().replace("${PRETTY_PRINT_ADDITIONAL_CSS", pretty_print_additional_css))
                .replace("${message}", escapedMessage)
                .replace("${assertion}", assertion)
                .replace("${info}", compilerInfo.toString());
        for (int i = 1; i < colors.length; i++) {
            html = html.replace("${h" + i + "_color}", colorFor(i));
        }
        return html;
    }

    /**
     * Escape special HTML characters in a string to prevent injection and preserve formatting.
     *
     * @param s input string (may be {@code null})
     * @return escaped string safe for inclusion in HTML; returns an empty string if {@code s} is {@code null}
     */
    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;")
                .replace("\n", "<br>");
    }
}