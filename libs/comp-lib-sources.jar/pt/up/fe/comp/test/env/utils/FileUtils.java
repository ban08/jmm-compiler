package pt.up.fe.comp.test.env.utils;

import pt.up.fe.specs.lang.SpecsPlatforms;
import pt.up.fe.specs.util.SpecsIo;

import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

public class FileUtils {

    public static String encodeUrl(File file) {
        if(SpecsPlatforms.isWindows()) {
            return file.toURI().toString();
        }

        var filePath = SpecsIo.normalizePath(file.getAbsoluteFile());

        var finalUrl = Arrays.stream(filePath.split("/"))
                .map(s -> URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20"))
                .reduce((a, b) -> a + "/" + b)
                .orElse(filePath);
        var prefix = "file://";
        if (!finalUrl.startsWith("/"))
            prefix += "/";
        return prefix + finalUrl;
    }
}
