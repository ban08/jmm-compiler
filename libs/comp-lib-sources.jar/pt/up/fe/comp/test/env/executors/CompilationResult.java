package pt.up.fe.comp.test.env.executors;

import pt.up.fe.comp.jmm.jasmin.JasminResult;
import pt.up.fe.comp.test.env.CompilerAssertion;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public record CompilationResult(JasminResult jasmin, File outputDir, Class<?> clazz, CompilerAssertion assertion) {

    public CompilationResult(JasminResult jasmin, File outputDir, String qualifiedName, CompilerAssertion assertion) {
        this(jasmin, outputDir, qualifiedName, CompilationResult.class.getClassLoader(), assertion);
    }

    public CompilationResult(JasminResult jasmin, File outputDir, String qualifiedName, ClassLoader classLoader, CompilerAssertion assertion) {
        this(jasmin, outputDir, loadClass(outputDir, qualifiedName, classLoader, assertion), assertion);
    }

    private static Class<?> loadClass(File outputDir, String className, ClassLoader loader, CompilerAssertion assertion) {
        className = className.replace("/", ".");
        var jLoader = new JLoader(List.of(outputDir), loader);
        try {
            return jLoader.load(className);
        } catch (Throwable e) {
            assertion.exposeException(e, "load class " + className);
            return null;
        }
    }

    public Field getField(String fieldName) {
        try {
            return clazz.getDeclaredField(fieldName);
        } catch (Throwable e) {
            assertion.exposeException(e, "get field " + fieldName + " from class " + this.clazz.getName());
            return null;
        }
    }

    public <T> T getFieldValue(Object instance, String fieldName, Class<T> fieldType) {

        Field f = getField(fieldName);
        rank0:
        try {
            assert f != null;
            Object v = f.get(instance);
            if (v == null) {
                return null;
            }
            var value = f.get(instance);
            assertion.assertTrue("field type must match " + fieldType + " (actual: " + f.getType() + ")", fieldType.isAssignableFrom(value.getClass()));
            return fieldType.cast(value);
        } catch (Throwable e) {
            assertion.exposeException(e, "get field value " + fieldName + " from class " + this.clazz.getName());
            return null;
        }
    }

    public void setFieldValue(Object instance, String fieldName, Object value) {
        Field f = getField(fieldName);
        try {
            assert f != null;
            f.set(instance, value);
        } catch (Throwable e) {
            assertion.exposeException(e, "set field " + fieldName + " from class " + this.clazz.getName() + " with value " + value);
        }
    }

    public InvocationResult<Void> invoke(String methodName, Object... args) {
        return invoke(newInstance(), getJavaMethod(methodName), args);
    }

    public InvocationResult<Void> invoke(Method method, Object... args) {
        return invoke(newInstance(), method, args);
    }

    public InvocationResult<Void> invoke(Object instance, String methodName, Object... args) {
        return invoke(instance, getJavaMethod(methodName), Void.class, args);
    }

    public InvocationResult<Void> invoke(Object instance, Method method, Object... args) {
        return invoke(instance, method, Void.class, args);
    }

    public <T> InvocationResult<T> invoke(String methodName, Class<T> returnType, Object... args) {
        return invoke(newInstance(), getJavaMethod(methodName), returnType, args);
    }

    public <T> InvocationResult<T> invoke(Method method, Class<T> returnType, Object... args) {
        return invoke(newInstance(), method, returnType, args);
    }

    public <T> InvocationResult<T> invoke(Object instance, String methodName, Class<T> returnType, Object... args) {
        return invoke(instance, getJavaMethod(methodName), returnType, args);
    }

    public <T> InvocationResult<T> invoke(Object instance, Method method, Class<T> returnType, Object... args) {
        return invoke(instance, method, returnType, null, args);
    }


    public <T> InvocationResult<T> invoke(Object instance, String methodName, Class<T> returnType, String stdIn, Object... args) {
        var method = getJavaMethod(methodName);
        return invoke(instance, method, returnType, stdIn, args);
    }

    public <T> InvocationResult<T> invoke(Object instance, Method method, Class<T> returnType, String stdIn, Object... args) {
        var originalOut = System.out;
        originalOut.flush();
        var originalErr = System.err;
        originalErr.flush();
        var originalStdIn = System.in;
        var outBaos = new ByteArrayOutputStream();
        T resultValue = null;
        try {
            System.setOut(new PrintStream(outBaos));
            System.setErr(new PrintStream(outBaos));
            if (stdIn != null) {
                System.setIn(new ByteArrayInputStream(stdIn.getBytes()));
            }
            method.setAccessible(true);
            System.out.flush();
            System.err.flush();
            var ret = method.invoke(instance, args);
            if (ret != null) {
                assertion.assertTrue("Return value of type " + ret.getClass() + " should be assignable to " + returnType + " (same class, subclass or interface).", returnType.isAssignableFrom(ret.getClass()));
                resultValue = returnType.cast(ret);
            }
        } catch (Throwable e) {
            assertion.exposeException(e, "method '" + method.getName() + "' execution");
        } finally {
            System.setOut(originalOut);
            originalOut.flush();
            System.setErr(originalErr);
            originalErr.flush();
            System.setIn(originalStdIn);
        }
        return new InvocationResult<>(resultValue, instance, List.of(args), outBaos.toString(), this);
    }

    public InvocationResult<Void> interact(String methodName, String stdIn, Object... args) {
        return interact(newInstance(), methodName, stdIn, args);
    }

    public InvocationResult<Void> interact(Object instance, String methodName, String stdIn, Object... args) {
        return invoke(instance, methodName, Void.class, stdIn, args);
    }


    public <T> InvocationResult<T> interact(String methodName, Class<T> returnType, String stdIn, Object... args) {
        return invoke(newInstance(), methodName, returnType, stdIn, args);
    }


    public Object newInstance() {
        try {
            return clazz.getDeclaredConstructor().newInstance();
        } catch (Throwable e) {
            assertion.exposeException(e, "class '" + clazz.getName() + "' instantiation");
            //will not execute the return!
            return this;
        }
    }


    public Method getJavaMethod(String methodName) {
        var allMethods = clazz.getDeclaredMethods();//clazz.getMethods();
        var methodL = Arrays.stream(allMethods).filter(m -> m.getName().equals(methodName)).toList();
        assertion.assertEquals("One method named '" + methodName + "' should be found. Found " + methodL.size(), 1, methodL.size());
        return methodL.getFirst();
    }
}
