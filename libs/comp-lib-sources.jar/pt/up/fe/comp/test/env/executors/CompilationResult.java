package pt.up.fe.comp.test.env.executors;

import pt.up.fe.comp.jmm.jasmin.JasminResult;
import pt.up.fe.comp.test.env.CompilerAssertion;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

public record CompilationResult(JasminResult jasmin, File outputDir, Class<?> clazz, CompilerAssertion assertion) {

    public CompilationResult(JasminResult jasmin, File outputDir, Class<?> clazz, CompilerAssertion assertion) {
        this.jasmin = jasmin;
        this.outputDir = outputDir;
        this.clazz = clazz;
        this.assertion = assertion;
    }

    public CompilationResult(JasminResult jasmin, File outputDir, String qualifiedName, CompilerAssertion assertion) {
        this(jasmin, outputDir, qualifiedName, CompilationResult.class.getClassLoader(), assertion);
    }

    public CompilationResult(JasminResult jasmin, File outputDir, String qualifiedName, ClassLoader classLoader, CompilerAssertion assertion) {
        this(jasmin, outputDir, loadClass(outputDir, qualifiedName, classLoader, assertion), assertion);
    }

    private static Class<?> loadClass(File outputDir, String className, ClassLoader loader, CompilerAssertion assertion) {
        className = className.replace("/", ".");
        var jLoader = new JLoader(List.of(outputDir), loader);
        try {
            return jLoader.load(className);
        } catch (ClassNotFoundException e) {
            assertion.exposeException(e, "load class " + className);
            return null;
        }
    }

    public Field getField(String fieldName) {
        try {
            return clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            assertion.exposeException(e, "get field " + fieldName + " from class " + this.clazz.getName());
            return null;
        }
    }

    public <T> T getFieldValue(Object instance, String fieldName, Class<T> fieldType) {

        Field f = getField(fieldName);
        try {
            assert f != null;
            Object v = f.get(instance);
            if (v == null) {
                return null;
            }
            var value = f.get(instance);
            assertion.assertTrue("field type must match " + fieldType + " (actual: " + f.getType() + ")", fieldType.isAssignableFrom(value.getClass()));
            return fieldType.cast(value);
        } catch (IllegalAccessException e) {
            assertion.exposeException(e, "get field value " + fieldName + " from class " + this.clazz.getName());
            return null;
        }
    }

    public void setFieldValue(Object instance, String fieldName, Object value) {
        Field f = getField(fieldName);
        try {
            assert f != null;
            f.set(instance, value);
        } catch (IllegalAccessException e) {
            assertion.exposeException(e, "set field " + fieldName + " from class " + this.clazz.getName() + " with value " + value);
        }
    }

    public InvocationResult<Void> invoke(String methodName, Object... args) {
        return invoke(newInstance(), methodName, args);
    }

    public InvocationResult<Void> invoke(Object instance, String methodName, Object... args) {
        return invoke(instance, methodName, Void.class, args);
    }

    /**
     * Works with single methods, i.e., ignores method overloading and expects a single method named "methodName".
     *
     * @param methodName
     * @param returnType
     * @param args
     * @param <T>
     * @return
     */
    public <T> InvocationResult<T> invoke(String methodName, Class<T> returnType, Object... args) {
        return invoke(newInstance(), methodName, returnType, args);
    }

    public <T> InvocationResult<T> invoke(Object instance, String methodName, Class<T> returnType, Object... args) {
        try {
            var methodL = Arrays.stream(clazz.getMethods()).filter(m -> m.getName().equals(methodName)).toList();
            assertion.assertEquals("One method named '" + methodName + "' should be found. Found " + methodL.size(), 1, methodL.size());
            var method = methodL.getFirst();
            method.setAccessible(true);
            var ret = method.invoke(instance, args);
            T resultValue = null;
            if (ret != null) {
                assertion.assertTrue("Return value of type " + ret.getClass() + " should be assignable to " + returnType + " (same class, subclass or interface).", returnType.isAssignableFrom(ret.getClass()));
                resultValue = returnType.cast(ret);
            }
            return new InvocationResult<>(resultValue, instance, List.of(args), this);
        } catch (Exception e) {
            assertion.exposeException(e, "method '" + methodName + "' execution");
            return new InvocationResult<>(null, instance, List.of(args), this);
        }
    }

    public Object newInstance() {
        try {
            return clazz.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            assertion.exposeException(e, "class '" + clazz.getName() + "' instantiation");
            return null;
        }
    }
}
