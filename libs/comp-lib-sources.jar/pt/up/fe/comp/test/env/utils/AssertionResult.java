package pt.up.fe.comp.test.env.utils;

import java.util.Objects;

public record AssertionResult(AssertionType type, String assertion, String expected, String actual, boolean failed) {

    public static AssertionResult pass(AssertionType type, String assertion, String expected, String actual) {
        var message = normalizeMessage(assertion, expected, actual);
        return new AssertionResult(type, message, expected, actual, false);
    }

    private static String normalizeMessage(String assertion, String expected, String actual) {
        expected = expected == null ? "null" : expected;
        actual = actual == null ? "null" : actual;
        return assertion.replace("${expected}", expected).replace("${actual}", actual);
    }

    public static AssertionResult fail(AssertionType type, String assertion, String expected, String actual) {
        var message = normalizeMessage(assertion, expected, actual);
        return new AssertionResult(type, message, expected, actual, true);
    }


    @Override
    public String toString() {
        var message = "Assert " + type.name().toLowerCase().replace("_", " ") + " ";

        message += failed ? "failed" : "passed";
        message += ": " + assertion;
        if (!assertion.endsWith(".")) message += ".";
        if (!Objects.equals(expected, actual)) {
            message += " Expected: " + expected;
            message += ", Actual: " + actual;
        } else {
            message += " Result: " + expected;
        }
        return message;
    }

    public String prettyPrint() {
        var message = "Assert ";// + type.name().toLowerCase().replace("_", " ") + " ";

        message += failed ? "failed" : "passed";
        message += ": " + assertion;
        if (!assertion.endsWith(".")) message += ".";
        if (!Objects.equals(expected, actual)) {
            if (expected.contains("\n")) {
                message += "\n\tExpected:\n\t" + expected;
            } else {
                message += "\n\tExpected: " + expected;
            }
            if (actual.contains("\n")) {
                message += "\n\tActual:\n\t" + actual;
            } else {
                message += "\n\tActual:   " + actual;
            }
        } else {
            if (expected.contains("\n")) {
                message += "\n\tResult:\n\t" + expected;
            } else {
                message += "\n\tResult: " + expected;
            }
        }
        return message;
    }
}
