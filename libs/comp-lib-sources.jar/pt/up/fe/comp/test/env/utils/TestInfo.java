package pt.up.fe.comp.test.env.utils;

import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

public class TestInfo extends TestWatcher {

    private Description description;


    @Override
    protected void starting(org.junit.runner.Description description) {
        this.description = description;
    }

    public String getMethodName() {
        if (description == null) {
            return "Unknown Test Method";
        }
        return description.getMethodName();
    }

    public String getTestClassName() {
        if (description == null) {
            return "Unknown Test Class";
        }
        return description.getTestClass().getName();
    }

}
