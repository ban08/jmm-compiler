package pt.up.fe.comp.test.env.providers;

import pt.up.fe.specs.util.SpecsCheck;
import pt.up.fe.specs.util.SpecsIo;

import java.io.File;
import java.util.Map;

/**
 * Provides text content and a temporary file if a file reference is needed.
 */
public class MapProvider<T> extends ContentProvider {

    private File fileRef;
    private final Map<String, T> content;
    private final String extension;

    public MapProvider(String description, Map<String, T> content, String extension) {
        super(description);
        SpecsCheck.checkNotNull(content, () -> "Content of TextProvider cannot be null");
        this.content = content;
        this.extension = extension != null ? extension : "txt";
    }

    @Override
    public File getFile() {
        if (fileRef == null) {
            fileRef = createTempFile(extension);
            SpecsIo.write(fileRef, getContent());
        }
        return fileRef;
    }

    @Override
    public String getExtension() {
        return extension;
    }

    @Override
    public boolean isTempFile() {
        return true;
    }

    @Override
    public String getContent() {
        return content.entrySet().stream().map(
                entry -> "# " + entry.getKey() + ":\n" + entry.getValue() + "\n\n"
        ).reduce("", String::concat);
    }

    public Map<String, T> getContentMap() {
        return content;
    }
}
