package pt.up.fe.comp.test.env.utils;

public enum AssertionType {
    EQUALS,
    NOT_EQUALS,
    NOT_NULL,
    NULL,
    TRUE,
    FALSE,
}
