package pt.up.fe.comp.test.env.executors;

import pt.up.fe.comp.jmm.jasmin.JasminResult;
import pt.up.fe.specs.util.system.ProcessOutputAsString;

import java.io.File;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;

public record InvocationResult<T>(T returnValue, Object instance, List<Object> args, String outputText,
                                  CompilationResult compilation) {
}
