package pt.up.fe.comp.test.env.executors;

import pt.up.fe.comp.jmm.jasmin.JasminResult;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public record InvocationResult<T>(T returnValue, Object instance, List<Object> args, CompilationResult compilation) {
}
