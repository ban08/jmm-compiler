package pt.up.fe.comp.jmm.ollir;

import pt.up.fe.comp.jmm.analysis.JmmSemanticsResult;

/**
 * This Stage deals with transformations performed at the AST level and at the OLLIR level.
 */
public interface JmmOptimization {

    /**
     * Step 1: transform code at the AST level
     *
     * @param semanticsResult
     * @return
     */
    default JmmSemanticsResult transformAst(JmmSemanticsResult semanticsResult) {
        return semanticsResult;
    }

    /**
     * Step 2: convert the AST to the OLLIR format
     *
     * @param semanticsResult
     * @return
     */
    OllirResult toOllir(JmmSemanticsResult semanticsResult);

    /**
     * Step 3: transform code at the OLLIR level
     *
     * @param ollirResult
     * @return
     */
    default OllirResult transformOllir(OllirResult ollirResult) {
        return ollirResult;
    }

    default JmmSemanticsResult optimize(JmmSemanticsResult semanticsResult) {
        return transformAst(semanticsResult);
    }

    default OllirResult optimize(OllirResult ollirResult) {
        return transformOllir(ollirResult);
    }
}